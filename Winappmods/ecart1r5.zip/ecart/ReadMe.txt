#################################################################################
#################################################################################
##                  E - C A R T   M O D   2 0 0 3   v1.0           			   ##
##                                                                             ##
## This program is free software; you can redistribute it and/or               ##
## modify it under the terms of the GNU General Public License                 ##
## as published by the Free Software Foundation; either version 2              ##
## of the License, or (at your option) any later version.                      ##
##                                                                             ##
## This program is distributed in the hope that it will be useful,             ##
## but WITHOUT ANY WARRANTY; without even the implied warranty of              ##
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               ##
## GNU General Public License for more details.                                ##
##                                                                             ##
## You should have received a copy of the GNU General Public License           ##
## along with this program; if not, write to the Free Software                 ##
## Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. ##
##                                                                             ##
#################################################################################
##                                                                             ##
## The creditcardvalidator used in this MOD is based on CC-Verify script by    ##
## Spider (spider@servtech.com).											   ##
##                                                                             ##
## COPYRIGHT NOTICE FOR CREDITCARDVALIDATOR                                    ##
## Copyright 1996 Dave Paris (aka Spider)  All Rights Reserved.				   ##
## Re-Coded 2002 Henrik Kadfors (KWAMD)										   ##
##                                                                             ##
#################################################################################
#################################################################################


INSTALL NOTES:

1. 	Edit the settings.pl, moneyorder.nfo and welcome.nfo in an texteditor such as notepad.
	-Please be very careful when editing settings.pl since this file includes all the 
	settings for e-cart mod.
	-moneyorder.nfo includes the information that will be sent to the customer if he/she 
	uses moneyorder.
	-the welcome.nfo is the file that includes the first page html code, edit this so it
	fits in on your site (HTML code accepted).

2.	Connect to your server using an ftp-client such as CuteFTP or simular,
	browse to your mod folder (eg. "./cgi-bin/mods"). within your "mods" folder create
	an new folder and name it "ecart", set permision on the folder you just created to 777.
	
3.	Inside the "ecart" folder create the following folders and chmod 'em all to 777.
	"cat, data, lang and temp".
	
4.	Open the "data" folder you just created and create the following folders within it.
	"news", "priv" and "welc".
	
5.	Your map structure should now look like this

	./cgi-bin/mods/ecart
	./cgi-bin/mods/ecart/cat
	./cgi-bin/mods/ecart/data
	./cgi-bin/mods/ecart/data/news
	./cgi-bin/mods/ecart/data/priv
	./cgi-bin/mods/ecart/data/welc
	./cgi-bin/mods/ecart/lang
	./cgi-bin/mods/ecart/temp
	
6.	Browse back to the "./cgi-bin/mods/ecart" folder and upload the following files in ascii
	mode and chmod them 'em all to 755 .
	"index.cgi", "settings.pl", "upedit.cgi "and "upnew.cgi".
	
7.	Browse to the "/cgi-bin/mods/ecart/data/welc" folder and upload the following files in
	ascii mode and chmod them 'em all to 755.
	"moneyorder.nfo" and "welcome.nfo".
	
8.	Browse to the "/cgi-bin/mods/ecart/lang" folder and upload the following file in ascii 
	mode and chmod them it to 755.
	"eng.lng".
	
9.	Browse to your images folder (same folder where the WebAPP images are) (eq. "./images").

10. 	Create an folder within the images folder and name it "ecart" and set permision to 777.

11.	Upload the following files in binary mode to the "ecart" folder you just created.
	amex.gif, arrow.gif, buy.gif, checkout.gif, contshop.gif, discover.gif, editcart.gif,
	master.gif, paypal.gif, varukorg.gif and visa.gif
	
12.	execute the mod by typing "http://yourdomain.com/cgi-bin/mods/ecart/index.cgi" in your
	webbrowser.
	
IF THE CART NOT WORKING PLEASE CHECK THE PERMISIONS!

�2002-2003 Henrik Kadfors KWAMD