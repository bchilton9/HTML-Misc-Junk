#################################################################################
#################################################################################
##                  E - C A R T   M O D   2 0 0 3   v1.0           			   ##
##                                                                             ##
## This program is free software; you can redistribute it and/or               ##
## modify it under the terms of the GNU General Public License                 ##
## as published by the Free Software Foundation; either version 2              ##
## of the License, or (at your option) any later version.                      ##
##                                                                             ##
## This program is distributed in the hope that it will be useful,             ##
## but WITHOUT ANY WARRANTY; without even the implied warranty of              ##
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               ##
## GNU General Public License for more details.                                ##
##                                                                             ##
## You should have received a copy of the GNU General Public License           ##
## along with this program; if not, write to the Free Software                 ##
## Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. ##
#################################################################################
#################################################################################


# PATHES AND URL'S

# The path to the E-Cart folder (Editing should not be neccesary if installed in
# ./cgi-bin/mods/ecart)
$moddir = "$scriptdir/mods/ecart";

# The URL to the E-Cart folder (Editing should not be neccesary if installed in
# ./cgi-bin/mods/ecart)
$modurl = "$scripturl/mods/ecart";

# The path to the E-Cart image folder (Editing should not be neccesary if installed in
# ./images/ecart)
$cartimagesdir = "$imagesdir/ecart";

# The URL to the E-Cart image folder (Editing should not be neccesary if installed in
# ./images/ecart)
$cartimagesurl = "$imagesurl/ecart";

# The path to the E-Cart category folder (Editing should not be neccesary if installed in
# ./cgi-bin/mods/ecart/cat)
$catdir = "$scriptdir/mods/ecart/cat";

# The path to the E-Cart data folder (Editing should not be neccesary if installed in
# ./cgi-bin/mods/ecart/data)
$moddatadir = "$scriptdir/mods/ecart/data";

# The path to the E-Cart personal messages folder (Editing should not be neccesary if installed in
# ./cgi-bin/mods/ecart/data/welc)
$modwelcdir = "$scriptdir/mods/ecart/data/welc";

# The path to the E-Cart news folder (Editing should not be neccesary if installed in
# ./cgi-bin/mods/ecart/data/news)
$modnewsdir = "$scriptdir/mods/ecart/data/news";

# The path to the E-Cart temp folder (Editing should not be neccesary if installed in
# ./cgi-bin/mods/ecart/temp)
$modtempdir = "$scriptdir/mods/ecart/temp";


# LANGUAGE

# The name of the language file
$langfilename = "eng.lng";


# COMPANY SETTINGS

# The name of your company
$ec_companyname = "Your Company LTD";

# The E-mailaddress to where the orders will be sent 
$ec_companymail = 'your@e-mail.com';


# PRICES ETC.

# The currency used on your site
$valuta = '$';

# if you want to show the price before the currency set this to "norm" (ie. 19USD),
# if you want to show the currency before the price set this to "rev" (ie. $19).
# (norm / rev)
$shopwprice = "rev";

# Delivery Fee
$deliverycost = "5";

# If the costumers order for more than this value they will not have to pay for the delivery
$deliveryfree = "100";


# BOXES

# Show the last added items on the first page? (yes / no)
$show_latest_add = "yes";

# How many new items would you like to show on the first page?
$firstant = "8";

# How many new items with images would you like to show on the first page?
$firstantpic = "3";

# Show the last added items on the category page? (yes / no)
$show_latest_add_cat = "yes";

# How many new items would you like to show on the category page?
$firstant_cat = "8";

# How many new items with images would you like to show on the category page?
$firstantpic_cat = "3";

# How many signs of the item name would you like to show in the news box?
# Recomended 25 (All signs above this will be replaced with "...")
$cutdownsigns = "25";

# Would you like to show the searchbox on the first page? (yes / no)
$showsearchfirst = "yes";

# Would you like to show the searchbox on the category page? (yes / no)
$showsearchcat = "yes";

# Would you like to show the category menu on the first page? (yes / no)
$showcategorymenufirst = "yes";

# Would you like to show the category menu on the category page? (yes / no)
$showcategorymenucat = "no";

# Would you like to show the category menu on the searchresult page? (yes / no)
$showcategorymenusearch = "no";

# Would you like to show the "We Accept" box? (yes / no)
$showweaccept = "yes";


# COLOR SETTINGS

# The Color of the stripe 1
$stripcolor = "#959595";

# The Color of the stripe 2, 4, 6, ...
$stripcolor1 = "#CCCCCC";

# The Color of the stripe 3, 5, 7, ...
$stripcolor2 = "#DDDDDD";

# The text color on the "My Cart" footer
$mycartfootcolor = "black";

# The text color on the "Category" footer
$catcartfootcolor = "black";

# Color on the prices
$pricecolor = "red";


# PAYMENT SETTINGS

# What payment methods would you like to accept (normal / paypal)
$betalningssatt = "normal";

# If above line is setted to "paypal" edit this to your paypal account name
$pp_company = 'your@paypalcompany.com';

# If payment method is set to "normal" please edit the following lines

# Accept COD? (yes / no)
$accept_cod = "yes";

# Accept pay in advance?  (yes / no)
$accept_pia = "yes";

# Accept Moneyorder (yes / no)
$accept_moneyorder = "yes";

# Accept payments with credit cards?
$accept_cccard = "yes";

# Accept payment by Master Card?  (yes / no)
$accept_master = "yes";

# Accept payment by Visa?  (yes / no)
$accept_visa = "yes";

# Accept payment by American Express?  (yes / no)
$accept_amex = "yes";

# Accept payment by Discover?  (yes / no)
$accept_discover = "yes";



# REQUIRED FIELDS (On the Ordering Page)

# First Name (yes / no)
$firstnamereq = "yes";

# Last Name (yes / no)
$lastnamereq = "yes";

# Street Address (yes / no)
$streetaddreq = "yes";

# ZIP (yes / no)
$zipreq = "yes";

# TOWN / CITY (yes / no)
$towneq = "yes";

# COUNTRY (yes / no)
$countryreq = "yes";

# Phone Home (yes / no)
$phonehomereq = "yes";

# Phone Work (yes / no)
$phoneworkreq = "no";

# Cell Phone (yes / no)
$phonecellreq = "no";

# E-mailaddress (yes / no)
$emailreq = "yes";


# RECEIPT 

# Send receipt to costumer via email?  (yes / no)
$sendreceipt = "yes";


# CC DECRYPTER

# Set an personal password for the password decrypter
$cc_passw = "ChangeMe";


# ADMIN ACCESS

# You can allow all your aministrators to access the admin area 
# Set this to "rest" if you don't want any other admins to have access to the cart settings
# else set it to "allow" (rest / allow)
$adminaccess = "rest";


# OTHER SETTINGS

# Show the extended message box on the checkout page? (yes / no)
$showleavemessage = "yes";

# Show how many items there are in the category in the category menu? (yes / no)
$showmenuitem = "yes";

# After how many days would you like the customers cart to be automaticly empted
$expdays = "2";