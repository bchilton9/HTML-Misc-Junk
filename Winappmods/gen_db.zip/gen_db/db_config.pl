# URL to gen_db directory
$db_path = "http://127.0.0.1/cgi-bin/mods/gen_db";
# URL to gen_db Admin directory
$db_admin_path = "http://127.0.0.1/cgi-bin/mods/gen_db/admin";
# Full Path to gen_db storage directory
$db_info_path = "web/cgi-bin/db/gen_db";
# Full Path to record storage directory
$record_info_path = "web/cgi-bin/db/gen_db/records";
# Full Path to gen_db directory
$full_db_path = "web/cgi-bin/mods/gen_db";