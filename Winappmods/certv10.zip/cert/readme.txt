1. First thing you need to do is go to your MY PROFILE link in the webapp members menu.

2. Click view/print your membership certificate.

3. there you should get the error page that new members will get if you use the default
   for webapp. The default setting that i am talking about is when a person signs up their status
   is set to be blank. The error message tells them to send a im to the admin or mod to get their
   status updated. It also gives them a link to to click on to go and send an im. 

4. ok that was just to show you the error page and what it looks like. Now what you need to do is 
   go to your mod manager and click on the admin link there to go and set up everything. This is the
   place where you can change the look or the status of the mod.

5. when in the admin area scroll down to the status area. There you will need to fill in all the
   status that is in the status admin are in webapp in the exact order from top to bottom.

6. You can click test output that will show you that it saving what you wrote. If you do not see what
   you wrote then there is something wrong with it. It shoudl refelct what you typed in there.
   keep in mind you will see all the other code in with that page so you will have to read to see
   what you typed.

7. No go and edit your profile and update your status if have not already to reflect what you want
   admins to be. Like on my site i have a full admin status and restricted admin status. Remember on
   the above #6 that means caps and spaces if they are in there for the name of each status.

8. Now you can edit all the pages or click save and go and view the staus page that is 
   in there for default.

9. This uses language files.... 

10. go and read the faq and tiops page....