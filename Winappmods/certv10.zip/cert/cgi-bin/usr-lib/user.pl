##############
sub myprofile {
##############

	$navbar = "$btn{'014'} $msg{'305'}$memsettings[1]";
	print_top();

	$about = "$memsettings[16]";
	$about =~ s/\&\&/<br>\n/g;

	print qq~<table cellpadding="3" cellspacing="3" width="100%" border="0"><tr>
	<td colspan="2" class="texttitle">$memsettings[1], $msg{'163'}</td>
	</tr>
	<tr>
	<td colspan="2" class="whocat">$msg{'586'}</td>
	</tr>
	<tr>
	<td colspan="2" class="whocat">$msg{'342'}<a href="$pageurl/$cgi?action=im" class="whomenu">$mnum</a>$msg{'343'}</td>
	</tr>
	</table>
	<table cellpadding="3" cellspacing="3" width="100%" border="0"><tr>
	<td width="20%" align="center">$memberpic</td>
	<td width="80%" valign="top">
	<table cellpadding="2" cellspacing="2" border="0"><tr>
	<td class="forumwindow3" width="25%">$msg{'013'}</td>
	<td class="forumwindow1" width="75%" nowrap>$memsettings[1]</td>
	</tr><tr>
	<td class="forumwindow3" width="25%">$msg{'650'}</td>
	<td class="forumwindow1" width="75%" nowrap>$memsettings[22]</td>
	</tr><tr>
	<td class="forumwindow3" width="25%">$msg{'651'}</td>
	<td class="forumwindow1" width="75%" nowrap>$memsettings[17]</td>
	</tr><tr>
	<td class="forumwindow3" width="25%">$msg{'652'}</td>
	<td class="forumwindow1" width="75%" nowrap>$memsettings[19]</td>
	</tr><tr>
	<td class="forumwindow3" width="25%">$msg{'653'}</td>
	<td class="forumwindow1" width="75%" nowrap>$memsettings[21]</td>
	</tr><tr>
	<td class="forumwindow3" width="25%">$msg{'654'}</td>
	<td class="forumwindow1" width="75%" width="75%" nowrap>$memsettings[20]</td>
	</tr><tr>
	<td class="forumwindow3" width="25%">$msg{'014'}</td>
	<td class="forumwindow1" width="75%" nowrap><a href="$memsettings[4]" target="_blank">$memsettings[3]</a></td>
	</tr>
        <tr><td colspan="2" class="forumwindow3" align="center" width="100%"><a href="$mods_url/cert/welcome.cgi">View/Print Your Membership Certificate</a></td></tr>
	</table></td>  </tr></table>
	<table cellpadding="3" cellspacing="3" width="100%" border="0"><tr>
	<td width="100%" valign="top">
	<table cellpadding="3" cellspacing="3" width="100%" border="0"><tr>
	<td class="forumwindow3" valign="top" width="25%">$msg{'655'}</td>
	<td class="forumwindow1" valign="top" width="75%">$about</font></td></tr><tr>
	<td class="forumwindow3" valign="top" width="25%">$msg{'656'}</td>
	<td class="forumwindow1" valign="top" width="75%">$memsettings[18]</td></tr><tr>
	</tr></table></td>  </tr></table>
	<table cellpadding="3" cellspacing="3" width="100%" border="0"><tr>
	<td class="forumwindow1" width="25%">$msg{'024'}&nbsp;$memsettings[7]</td>
	<td class="forumwindow1" width="25%">$msg{'178'}&nbsp;$memsettings[14]</td>
	<td class="forumwindow1" width="25%">$msg{'021'}&nbsp;$memsettings[6]</td>
	<td class="forumwindow1" width="25%">$msg{'022'}&nbsp;$memsettings[11]</td>
	</tr><tr>
	<td class="forumwindow3" align="center" width="25%"><a href="$pageurl/$cgi?action=viewprofile&username=$username">$nav{'017'}</a></td>
	<td class="forumwindow3" align="center" width="25%"><a href="$pageurl/$cgi?action=editprofile2&username=$username">$nav{'161'}</a></td>
	<td class="forumwindow3" colspan="2" align="center" width="50%"><a href="$pageurl/$cgi?action=logout">$nav{'034'}</a></td>
	</tr></table><br>~;

if ($umessageid ne "") {
	imview();
}

 	print qq~<div align="center"><table cellpadding="3" cellspacing="3" width="100%" border="0"><tr>
	<td align="center" class="forumwindow3"><a href="$cgi?action=imsend">$nav{'029'}</a></td>
	<td colspan="2" align="center" class="forumwindow3"><a href="$cgi?action=im">$nav{'102'}</a></td>
	<td align="center" class="forumwindow3"><a href="$cgi?action=imremove&amp;id=all">$msg{'576'}</a></td>
	</tr></table>
	<table width="99%" bgcolor="#000000" border="0" cellspacing="1" cellpadding="2"><tr>
	<td class="imtitle" width="10%"><b>$msg{'182'}</b></td>
	<td class="imtitle" width="20%"><b>$msg{'214'}:</b></td>
	<td class="imtitle" width="60%"><b>$msg{'037'}</b></td>
	<td class="imtitle" width="10%"><b>$msg{'208'}:</b></td>
	</tr>~;

if (@imessages == 0) {
		print qq~<tr>
		<td colspan="4" class="imwindow1">$msg{'050'}</td>
		</tr>~;
}
	$second = "imwindow2";
	sort {$b[5] <=> $a[5]} @immessages;
	for ($a = 0; $a < @imessages; $a++) {
		if ($second eq "imwindow1") { $second="imwindow2"; }
		else { $second="imwindow1"; }

		($musername[$a], $msub[$a], $mdate[$a], $mmessage[$a], $messageid[$a], $mviewed[$a]) = split(/\|/, $imessages[$a]);

                if ($messageid[$a] < 100) { $messageid[$a] = $a; }
		$subject = "$msub[$a]";
		if ($subject eq "") { $subject="---"; }

		$mmessage[$a] =~ s/\n//g;
		$mmessage[$a] =~ s/\r//g;
		$message="$mmessage[$a]";
		$name = "$mname[$a]";
		$mail = "$memset[2]";
		$mdate = "$mdate[$a]";
		$ip = "$mip[$a]";
		$postinfo = "";
		$signature = "";
		$viewd = "";
		$icq = "";
		$star = "";
		$newim = "";
		$imnav = "oldimlink";

if ($mviewed[$a] eq "" && $umessageid ne $messageid[$a]) {
	$newim = qq~<img src="$imagesurl/forum/new.gif" border="0" alt="$msg{'543'}">&nbsp;~; $imnav = "newimlink";
}
elsif ($umessageid eq $messageid[$a]) {
	$second = "imselected";
}

display_date($mdate); $mdate = $user_display_date;

if ($musername[$a] eq "$anonuser") {
print qq~<td class="$second" width="10%"><b>$msg{'668'}</b></td>~;
} else {print qq~<td class="$second" width="10%"><a href="$cgi?action=imsend&to=$musername[$a]" class="$imnav">$musername[$a]</a></td>~;
}
print qq~
<td class="$second" width="20%">$mdate</td>
<td class="$second" width="60%"><a href="$cgi?action=im&amp;from=$musername[$a]&amp;messageid=$messageid[$a]" class="$imnav">$newim$msub[$a]</td>~;

if ($musername[$a] eq "$anonuser") {
print qq~<td class="$second" width="10%"><center><a href="$cgi?action=imremove&id=$messageid[$a]"><img src="$imagesurl/forum/delete.gif" alt="$msg{'058'}" border="0"></a></center></td>~;
} else {print qq~<td class="$second" width="10%"><center><a href="$cgi?action=imsend&to=$musername[$a]&num=$messageid[$a]"><img src="$imagesurl/forum/modify.gif" alt="$msg{'057'}" border="0"></a>&nbsp;&nbsp;<a href="$cgi?action=imremove&id=$messageid[$a]"><img src="$imagesurl/forum/delete.gif" alt="$msg{'058'}" border="0"></a></center></td>~;
}
print qq~</tr>~;
}

if ($username eq "admin") {
print qq~<tr>
<td colspan="4" class="imtitle"><b>$msg{'561'}</b></td>
<tr>
<td colspan="4" class="imwindow1"><a href="$cgi?action=siteim">$msg{'562'}</a><br>
<a href="$cgi?action=adminim">$msg{'595'}</a><br>
<a href="$cgi?action=modim">$msg{'594'}</a></td>
</tr>~;
}

if ($username ne "admin" && $settings[7] eq "$root") {
print qq~<tr>
<td colspan="4" class="imtitle"><b>$msg{'561'}</b></td>
<tr>
<td colspan="4" class="imwindow1"><a href="$cgi?action=adminim">$msg{'595'}</a><br>
<a href="$cgi?action=modim">$msg{'594'}</a></td>
</tr>~;
}

if ($username ne "admin" && $settings[7] ne "$root" && $settings[7] eq "$boardmoderator") {
print qq~<tr>
<td colspan="4" class="imtitle"><b>$msg{'596'}</b></td>
<tr>
<td colspan="4" class="imwindow1"><a href="$cgi?action=modim">$msg{'594'}</a></td>
</tr>~;
}

 print qq~</table></div><br>~;

print_bottom();
}
1; # return true







