package WPLab::TemplateManipulation;

################################################################################
#                                                                              #
# Version        :  1.2                                                        #
# Last Modified  :  17 Dec 2002                                                #
# Copyright      :  UPDN Network Sdn Bhd www.upoint.net/cgiscripts.updn        #
# Descrption     :  Helpdesk XP                                                #
#                                                                              #
################################################################################

require 5.004;

BEGIN { use Exporter ();
        use vars     qw ( $VERSION @ISA @EXPORT @EXPORT_OK %EXPORT_TAGS );

        $VERSION     = "0.53";

        @ISA         = qw ( Exporter );              
        @EXPORT      = qw ( &get_template );
        %EXPORT_TAGS = ( );     
        @EXPORT_OK   = qw ( &get_template );
      }

use vars @EXPORT_OK;
use strict;

sub Version
    { $mod::VERSION;
    }

sub new
    { my ( $proto, %arg ) = @_;
      my $class = ref ( $proto ) || $proto;
      my $self  = {};

      while ( my ( $key, $val ) = each %arg )
            { $self->{$key} = $val;
            }

      bless ( $self, $class );
      $self->load ( $self->{_file} ) if ( $self->{_file} );

      return $self;
    }

sub load
    { my ( $self, $file ) = @_;
      my ( $IncludeFilePath, $IncludeFileContent );

      $self->{_file} = $file;
      if ( $self->{_file} )
         { if ( -e $self->{_file} )
              { $self->{_file} = $self->{_file} }
           elsif ( -e $self->{_default_folder}.$self->{_file} )
              { $self->{_file} = $self->{_default_folder}.$self->{_file} }
           elsif ( -e $self->{_default_folder}."/".$self->{_file} )
              { $self->{_file} = $self->{_default_folder}."/".$self->{_file} }
           else
              { $self->{_status} = "Error of template loading: ".lc ( $! );
                return 0;
              }

           open ( TEMPLATE, $self->{_file} );
           $self->{_content} = join ( "", <TEMPLATE> );
           close ( TEMPLATE );
           $self->{_content_length} = length ( $self->{_content} );
           $self->{_values} = [];
           $self->{_codes} = [];
           $self->{_files} = [];
           $self->{_code_part} = [];
           $self->{_snippets} = {};
           $self->{_html} = "";

           @{ $self->{_files} } = ( $self->{_content} =~ m{ \[TMPL-FILE:(.+)\] }xg );
           for ( @{ $self->{_files} } )
               { if ( -e $_ )
                    { $IncludeFilePath = $_ }
                 elsif ( -e $self->{_default_folder}.$_ )
                    { $IncludeFilePath = $self->{_default_folder}.$_ }
                 elsif ( -e $self->{_default_folder}."/".$_ )
                    { $IncludeFilePath = $self->{_default_folder}."/".$_ }

                 open ( IFH, $IncludeFilePath );
                 $IncludeFileContent = join ( "", <IFH> );
                 close ( IFH );

                 $_ = quotemeta ( $_ );

                 $self->{_content} =~ s/\[TMPL-FILE\:$_]/$IncludeFileContent/xisg;
               }

           @{ $self->{_values} } = ( $self->{_content} =~ m{ \[TMPL-VALUE:([\w\.]+)\] }xg );
           @{ $self->{_codes} } = ( $self->{_content} =~ m{ \[TMPL-CODE:([\w\.]+)\] }xg );
           @{ $self->{_code_part} } = ( $self->{_content} =~ m{ \[\+TMPL-CODE:([\w\.]+)\](.+?)\[\-TMPL-CODE:\1\] }xgs );
           if ( $self->{_content} =~ /\[\+TMPL-CODE/s )
              { ( $self->{_html} ) = $self->{_content} =~ /^(.+?)\[\+TMPL-CODE/s;
              }
           else
              { $self->{_html} = $self->{_content};
              }

           my ( @tmpArray ) = ( $self->{_content} =~ m{ \[TMPL-CASE:([\w\.]+): }xg );
           for ( @tmpArray )
               { $_ = lc ( $_ );
                 $self->{_cases}{$_}{isCompleted} = 0;
                 @{ $self->{_cases}{$_}{values} } = split ( /\|/, ( $self->{_content} =~ m{ \[TMPL-CASE:$_:(.*?)\] }xgi )[0] );
               }
           undef ( @tmpArray );

           for ( my $counter = 0; $counter <= $#{$self->{_code_part}}; $counter++ )
               { my $snippet_name = lc ( ${$self->{_code_part}}[$counter] );
                 $counter++;
                 
                 $self->{_snippets}->{$snippet_name}->{code} = ${$self->{_code_part}}[$counter];
                 ( $self->{_snippets}->{$snippet_name}->{nodata}->{code} ) = $self->{_snippets}->{$snippet_name}->{code} =~ /\[\+NODATA\](.+?)\[\-NODATA\]/s;
                 ( $self->{_snippets}->{$snippet_name}->{data}->{code} )   = $self->{_snippets}->{$snippet_name}->{code} =~ /\[\+DATA\](.+?)\[\-DATA\]/s;

                 $self->{_snippets}->{$snippet_name}->{nodata}->{completed} = 0;
                 $self->{_snippets}->{$snippet_name}->{data}->{completed} = 0;
                 $self->{_snippets}->{$snippet_name}->{code} =~ s/\[\+NODATA\].+?\[\-NODATA\]/\[NODATA\]/s if $self->{_snippets}->{$snippet_name}->{nodata}->{code};
                 $self->{_snippets}->{$snippet_name}->{code} =~ s/\[\+DATA\].+?\[\-DATA\]/\[DATA\]/s if $self->{_snippets}->{$snippet_name}->{data}->{code};

                 @{$self->{_snippets}->{$snippet_name}->{data}->{include}} = ( $self->{_snippets}->{$snippet_name}->{data}->{code} =~ m{ \[INCLUDE:(\w+)\] }xg );

                 if ( ( $self->{_snippets}->{$snippet_name}->{data}->{loop}->{code} ) = $self->{_snippets}->{$snippet_name}->{data}->{code} =~ /\[\+LOOP\](.+?)\[\-LOOP\]/xis )
                    { $self->{_snippets}->{$snippet_name}->{data}->{code} =~ s/\[\+LOOP\].+?\[\-LOOP\]/\[LOOP\]/xis;
                      $self->{_snippets}->{$snippet_name}->{data}->{loop}->{completed} = 0;
                      ( $self->{_snippets}->{$snippet_name}->{data}->{loop}->{odd} )  = $self->{_snippets}->{$snippet_name}->{data}->{loop}->{code} =~ /\[\+ODD\](.+?)\[\-ODD\]/s;
                      ( $self->{_snippets}->{$snippet_name}->{data}->{loop}->{even} ) = $self->{_snippets}->{$snippet_name}->{data}->{loop}->{code} =~ /\[\+EVEN\](.+?)\[\-EVEN\]/s;
                      ( $self->{_snippets}->{$snippet_name}->{data}->{loop}->{both} ) = $self->{_snippets}->{$snippet_name}->{data}->{loop}->{code} =~ /\[\+BOTH\](.+?)\[\-BOTH\]/s;
                      if ( $self->{_snippets}->{$snippet_name}->{data}->{loop}->{both} )
                         { undef ( $self->{_snippets}->{$snippet_name}->{data}->{loop}->{odd} );
                           undef ( $self->{_snippets}->{$snippet_name}->{data}->{loop}->{even} );
                           $self->{_snippets}->{$snippet_name}->{data}->{loop}->{code} =~ s/\[\+BOTH\].+?\[\-BOTH\]/\[DATA\]/xis;
                           $self->{_snippets}->{$snippet_name}->{data}->{loop}->{code} =~ s/\[\+ODD\].+?\[\-ODD\]//xis;
                           $self->{_snippets}->{$snippet_name}->{data}->{loop}->{code} =~ s/\[\+EVEN\].+?\[\-EVEN\]//xis;

                           my ( @tmpArray ) = ( $self->{_snippets}->{$snippet_name}->{data}->{loop}->{"both"} =~ m{ \[TMPL-CASE:([\w\.]+): }xg );
                           for ( @tmpArray )
                               { $_ = lc ( $_ );
                                 $self->{"case"}->{$snippet_name}->{"both"}->{$_}->{"isCompleted"} = 0;
                                 @{ $self->{"case"}->{$snippet_name}->{"both"}->{$_}->{"values"} } = split ( /\|/, ( $self->{_snippets}->{$snippet_name}->{data}->{loop}->{both} =~ m{ \[TMPL-CASE:$_:(.*?)\] }xgi )[0] );
                               }
                           undef ( @tmpArray );
                         }
                      elsif ( $self->{_snippets}->{$snippet_name}->{data}->{loop}->{odd} && $self->{_snippets}->{$snippet_name}->{data}->{loop}->{even} )
                         { undef ( $self->{_snippets}->{$snippet_name}->{data}->{loop}->{both} );
                           $self->{_snippets}->{$snippet_name}->{data}->{loop}->{code} =~ s/\[\+ODD\].+?\[\-ODD\]/\[DATA\]/xis;
                           $self->{_snippets}->{$snippet_name}->{data}->{loop}->{code} =~ s/\[\+BOTH\].+?\[\-BOTH\]//xis;
                           $self->{_snippets}->{$snippet_name}->{data}->{loop}->{code} =~ s/\[\+EVEN\].+?\[\-EVEN\]//xis;
                         }
                      else
                         { undef ( $self->{_snippets}->{$snippet_name}->{data}->{loop}->{code} );
                           $self->{_snippets}->{$snippet_name}->{data}->{code} =~ s/\[LOOP\]//xis;
                         }
                    }
               }
           return 1;
         }
      else
         { return 0;
         }
    }

sub debug
    { my $self = shift;
      return $self->{_debug};
    }

sub status
    { my $self = shift;
      return $self->{_status};
    }

sub print
    { my $self = shift;

      foreach my $snippet_name ( keys %{ $self->{_snippets} } ) 
                               { my $_not_complete = 0;
                                              
                                 foreach ( @{ $self->{_snippets}->{$snippet_name}->{data}->{include} } )
                                         { $_ = lc ( $_ );
                                           if ( $self->{_snippets}->{$_}->{data}->{completed} )
                                              { $self->{_snippets}->{$_}->{nodata}->{code} = ""; 
                                              }
                                           else
                                              { $self->{_snippets}->{$_}->{data}->{code} = "";
                                                $self->{_snippets}->{$snippet_name}->{data}->{code} = "";
                                                $_not_complete = 1;
                                              }
                                         }

                                 if ( $#{ $self->{_snippets}->{$snippet_name}->{data}->{include} } >= 0 && !$_not_complete )
                                    { $self->{_snippets}->{$snippet_name}->{nodata}->{code} = "";
                                    }

                                 if ( !$self->{_snippets}->{$_}->{data}->{completed} )
                                    { $self->snippet ( _name => $snippet_name,
                                                       _nodata => ()
                                                     ); 
                                    }
                               }

      foreach my $snippet_name ( keys %{ $self->{_snippets} } ) 
                               { $self->{_snippets}->{$snippet_name}->{code} =~ s/\[DATA\]/$self->{_snippets}->{$snippet_name}->{data}->{code}/xi;
                                 $self->{_snippets}->{$snippet_name}->{code} =~ s/\[NODATA\]/$self->{_snippets}->{$snippet_name}->{nodata}->{code}/xi;
                               }

      foreach my $snippet_name ( keys %{ $self->{_snippets} } ) 
                               { foreach ( @{ $self->{_snippets}->{$snippet_name}->{data}->{include} } )
                                         { $_ = lc ( $_ );
                                           $self->{_snippets}->{$snippet_name}->{code} =~ s/\[INCLUDE:$_\]/$self->{_snippets}->{$_}->{code}/xisg;
                                         }
                               }

      foreach ( keys %{ $self->{_snippets} } ) 
              { $self->{_html} =~ s/\[TMPL-CODE:$_\]/$self->{_snippets}->{$_}->{code}/gxi;
              }

      foreach ( keys %{ $self->{_cases} } ) 
              { if ( !$self->{_cases}->{$_}->{isCompleted} )
                   { $self->{_html} =~ s/\[TMPL-CASE:$_:.*?\]/$self->{_cases}->{$_}->{values}->[0]/xi;
                     $self->{_cases}->{$_}->{isCompleted} = 1;
                   }
              }

      return $self->{_html};
    }

sub html
    { my $self = shift;
      return $self->{_html};
    }

sub values
    { my ( $self, %arg ) = @_;
      while ( my ( $key, $value ) = each %arg )
            { $key = lc ( $key );
              $self->{_html} =~ s/\[TMPL-VALUE:$key\]/$value/xisg;
              if ( $self->{_cases}->{$key} && !$self->{_cases}->{$key}->{isCompleted} )
                 { $value = 0 if ( $value && ( not $value =~ /^\d+$/ ) );
                   $self->{_html} =~ s/\[TMPL-CASE:$key:.*?\]/$self->{_cases}->{$key}->{values}->[$value]/xi;
                   $self->{_cases}->{$key}->{isCompleted} = 1;
                 }
            }
    }

sub snippet
    { my ( $self, %arg ) = @_;
      my ( $snippet_name, $_nodata_found, $_data_found, $_values_found, $_loop_found );
      my ( $max, $_loop_data, $tWhere );

      foreach my $key ( keys %arg ) 
                      { $snippet_name = $arg{$key} if ( $key =~ /_name/ );
                        $_nodata_found = 1 if ( $key =~ /_nodata/ );
                        $_data_found = 1 if ( $key =~ /_data/ );
                        $_values_found = 1 if ( $key =~ /_values/ );
                        $_loop_found = 1 if ( $key =~ /_loop/ );
                      }                   

      if ( $snippet_name )
         { $snippet_name = lc ( $snippet_name );
           if ( $_nodata_found && $self->{_snippets}->{$snippet_name}->{nodata}->{code} )
              { $self->{_snippets}->{$snippet_name}->{data}->{code} = "";
                while ( my ( $key, $value ) = each %{ $arg{_nodata} } )
                      { $self->{_snippets}->{$snippet_name}->{nodata}->{code} =~ s/\[TMPL-VALUE:$key\]/$value/xsi;
                      }
              }
           if ( $_data_found && $self->{_snippets}->{$snippet_name}->{data}->{code} )
              { $self->{_snippets}->{$snippet_name}->{nodata}->{code} = "";
                $self->{_snippets}->{$snippet_name}->{data}->{completed} = 1;
                while ( my ( $key, $value ) = each %{ $arg{_data} } )
                      { $self->{_snippets}->{$snippet_name}->{data}->{code} =~ s/\[TMPL-VALUE:$key\]/$value/xsi;
                      }
              }
           if ( $_values_found )
              { while ( my ( $key, $value ) = each %{ $arg{_values} } )
                      { $self->{_snippets}->{$snippet_name}->{code} =~ s/\[TMPL-VALUE:$key\]/$value/xsig;
                      }
              }

           if ( $_loop_found && $self->{_snippets}->{$snippet_name}->{data}->{loop}->{code} )
              { $max = -1;
                if ( $arg{_max} )
                   { $max = $#{ $arg{_loop}{$arg{_max}} };
                   }
                else
                   { foreach ( keys %{ $arg{_loop} } )
                             { $max = $#{ $arg{_loop}{$_} } if ( $max < $#{ $arg{_loop}{$_} } );
                             }
                   }
                for my $ae ( 0 .. $max )
                           { if ( $self->{_snippets}->{$snippet_name}->{data}->{loop}->{both} )
                                { $tWhere = "both" }
                             elsif ( $self->{_snippets}->{$snippet_name}->{data}->{loop}->{odd} && $ae % 2 )
                                { $tWhere = "odd" }
                             elsif ( $self->{_snippets}->{$snippet_name}->{data}->{loop}->{even} && not $ae % 2 )
                                { $tWhere = "even" }

                             $_ = $self->{_snippets}->{$snippet_name}->{data}->{loop}->{$tWhere};

                             while ( my ( $key, $value ) = each %{ $arg{_loop} } )
                                   { s/\[TMPL-VALUE:$key\]/$arg{_loop}{$key}[$ae]/gisx;

                                     if ( $self->{"case"}->{$snippet_name}->{$tWhere}->{lc($key)} )
                                        { $value = sprintf ( "%d", $arg{_loop}{$key}[$ae] );
                                          $value = 0 if ( $value > $#{ $self->{"case"}->{$snippet_name}->{$tWhere}->{lc($key)}->{"values"} } );
                                          s/\[TMPL-CASE:$key:.*?\]/$self->{"case"}->{$snippet_name}->{$tWhere}->{lc($key)}->{"values"}[$value]/xig;
                                          $self->{"case"}->{$snippet_name}->{$tWhere}->{lc($key)}->{"isCompleted"} = 1;
                                        }
                                   }

                             for my $key ( keys %{ $self->{"case"}->{$snippet_name}->{$tWhere} } ) 
                                         { if ( !$self->{"case"}->{$snippet_name}->{$tWhere}->{lc($key)}->{"isCompleted"} )
                                              { s/\[TMPL-CASE:$key:.*?\]/$self->{"case"}->{$snippet_name}->{$tWhere}->{lc($key)}->{"values"}[0]/xig;
                                              }
                                           $self->{"case"}->{$snippet_name}->{$tWhere}->{lc($key)}->{"isCompleted"} = 0;
                                         }

                             $_loop_data .= $_;
                           }

                $self->{_snippets}->{$snippet_name}->{data}->{loop}->{code} =~ s/\[DATA\]/$_loop_data/xis;
                $self->{_snippets}->{$snippet_name}->{data}->{code} =~ s/\[LOOP\]/$self->{_snippets}->{$snippet_name}->{data}->{loop}->{code}/xis;
                $self->{_snippets}->{$snippet_name}->{data}->{completed} = 1;
                $self->{_snippets}->{$snippet_name}->{nodata}->{code} = "";
              }
         }
      else
         {
         }
    }
