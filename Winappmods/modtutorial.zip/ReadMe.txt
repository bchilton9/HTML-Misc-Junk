How to make a Mod.

So, you have installed WebAPP and you're pretty pleased with yourself, but you think to yourself,

"I want a guestbook for my site!"

Ok then. You have a look at the WebAPP site to see if there is a Guestbook Mod available.
If there isn't, or you don't like the one(s) on offer, you may want to write your own.

To make your guestbook fit in with the rest of your site, it is best to write a Mod!

Here is how you can do this.

1. Edit the path to Perl in both tutorial/tutorial.cgi and tutorial/admin/admin.cgi.

2. Upload the entire tutorial folder to your cgi-bin/mods folder in ASCII mode.

3. CHMOD both .cgi files 755.

4. Run Mod Manager and then click on the link for the Tutorial Admin page and have a look.

5. Point your browser to http://www.yoursite.com/cgi-bin/mods/tutorial/tutorial.cgi and have a look.

6. If all looks OK, then you have made a start! Now, I have placed comments in both .cgi files to mark where you should edit these files to make your own mod.

Well, that should have given you a start!

If you have made a wonderful Mod, then please share it with us!
