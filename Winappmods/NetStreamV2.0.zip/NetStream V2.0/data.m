YorinFM|video/x-ms-asf|http://media.rtl.nl/yorinfm/on_air/yorin.asx
Radio3FM|video/x-ms-asf|http://www.omroep.nl/radio3/live20.asx
Skyradio|video/x-ms-asf|http://www.skyradio.nl/player/skyradio.asx
Hotradio|video/x-ms-asf|http://www.hotradio.nl/sound/stream/livestream.asx
NoordzeeFM|video/x-ms-asf|mms://hollywood.win2k.vuurwerk.nl/noordzee
RadioNRG|video/x-ms-asf|http://www.radionrg.com/listenlive.asx
CapitalFM|video/x-ms-asf|http://www.radio-now.co.uk/l/capitalfmlo.asx
BBCRadio1|audio/x-pn-realaudio|http://www.bbc.co.uk/radio1/realaudio/media/r1live.rpm
