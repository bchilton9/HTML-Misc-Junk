This Little Journal Mod by bantychick is a modified version of the
bethink journal version 0.90 as written and released under
the GPL by Matt Skidmore of fox@woozle.org. It was both written
and modified for the intended use of on online diary or weblog.
The original author requests to be notified of changes made to
the script by those who may wish to develop it further.

The index.cgi file displays the journal and takes care of getting
the data to and from the end user. The author suggested setting
the permissions of this file to 755 (rwxr-xr-x).

The journal.cfg file is the configuration file specific to the
Little Journal Mod. Be sure to change the $admpass and $prvpass
passwords so no unauthorized persons may add entries or view
private entries. The journal.cfg file also lists filenames and
paths for data used by the program. It is suggested to chmod
this file to 600 if possible to keep your passwords private.

The $hedfile variable references the header, which is the HTML
sent to the browser before entries are processed. This file
contains variables $ent25, $ent50, $ent100, and $entall, which
are used to simplify things for the end user who wants to see 
more than the default 25 entries. Chmod this file 644 or 600.

The $entfile variable references the file that contains all
your journal entries. The security of this file is important,
so chmod to 600 if possible. Care should be taken if modifying
this entries file manually:

%&%			#a seperator before and after each entry
Y			#privacy flag either Y or N
6:8:2001:Friday		#date month:day:year:name of the day seperated by :
2:37:PM			#time hour:minute:ampm seperated by :
journal entry text	#entry text can be more than one line
whatever you write	#and can contain html tags if desired
%&%			#end of entry seperator
%&%			#this would be the start of another entry

The $frmfile variable references the format file that controls
the display of the entries. This is an HTML file that contains
the variables for what is displayed in the journal:

$outhour	displays entry hour value
$outmin		displays entry minute value
$ampm		displays entry ampm value
$extra		displays midnight or noon, repectively
$outmonth	displays entry month value
$outday		displays entry day value
$outyear	displays entry year value
$nameday	displays the name of the day
$entry		displays the entry
$prvflag	displays "Yes" or "No" indicating a private entry

The $endfile variable references the file that contains the
closing HTML displayed at the bottom of the journal page. You
can include any links, copyrights, etc. here.

The $prvalue variable references the password for viewing
private entries.

INSTALL:

Just set your passwords and file paths in journal.cfg, upload
all files and folders to your WebAPP mods folder, and and it
should work as long as your WebAPP is on a standard setup.
It has been tested on a Windows server.

All of the datafiles except the configuration files can be
modified through the admin interface in ModManager or via
the admin link that shows up when you are logged in as admin.
Using this feature can be somewhat bandwidth or time intensive,
depending on the size of your journal, as it loads and then
sends the entire file. Be sure to give it plenty of time when
you click the submit button to make changes.

