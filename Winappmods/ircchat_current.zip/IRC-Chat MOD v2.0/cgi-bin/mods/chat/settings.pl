##################################################################################
##################################################################################
##              I R C - C h a t  M O D   v2.01	(For WebApp Only)				##
##______________________________________________________________________________##
##																				##
##	Copyright � GBG Softwares 2002-2003											##
##	http://www.yazaport.com/kadfors												##
##	Henrik Kadfors (gbgsoft@telia.com)											##
##______________________________________________________________________________##
##																				##
## File: settings.pl															##
## Last Modified: 2003-03-30													##
##______________________________________________________________________________##
##																				##
## This program is free software; you can redistribute it and/or				##
## modify it under the terms of the GNU General Public License					##
## as published by the Free Software Foundation; either version 2				##
## of the License, or (at your option) any later version.						##
##																				##
## This program is distributed in the hope that it will be useful,				##
## but WITHOUT ANY WARRANTY; without even the implied warranty of				##
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the				##
## GNU General Public License for more details.									##
##																				##
## You should have received a copy of the GNU General Public License			##
## along with this program; if not, write to the Free Software					##
## Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.	##
##################################################################################
##################################################################################


##############################################
# The following variables have to be edited! #
##############################################

# The Url to the JPilot jIRC applet (Do not edit if you installed the applet where we
# recomended in the ReadMe file).
$jircurl = "$baseurl/chat";

# Who should be able to use the chat?
# all = All, reguser = Registered Users, admin = Administrators,
$allowwho = "all";

# Server to connect to, if you want to use multiple servers please separate them with comas
# (eg. $jircserver = "server1,server2,server3";). If you're using multiple servers you also need to
# change $DisplayConfigServer = "false"; to $DisplayConfigServer = "true";
# (List over availible servers can be found at http://www.mirc.co.uk/servers.html).
$jircserver = "mesra-e.kl.my.dal.net";
$DisplayConfigServer = "false";

# Port (most IRCd servers accept connections to ports between 6660 and 6670).
$jircport = "6667";

# Channels (Rooms) , 
# if you want to use multiple rooms
# please separate the rooms with comas (ie. $jircchannel = "Room1,Room2,Room3,Room4"; )
# If you chose to have multiple rooms you will also have to change $DirectStart = "true";
# to $DirectStart = "false"; to prevent the chat to be automaticly started.
$jircchannel = "GBGSoft";
$DirectStart = "true";

# License Key (Order from http://www.jpilot.com/java/irc/register.html), 
# This will register your jIRC applet
$LicenseKey = "";


#############################################################
# The following variables do NOT have to be edited,         #
# but you can do this if you want to change the layout etc. #
#############################################################

# Size of the chat applet
$width = "500";
$height = "250";

# Name settings
$RealName = "GBGSoft";
$UserName = "gbgsoft\@telia.com";

# Colors and fonts
$jircbgcol = "959595";
$jirctxtcol = "black";
$TextScreenColor = "white";
$ListTextColor = "pink";
$TextFontName = "Arial";
$TextFontSize = "12";
$LogoBgColor = "white";
$BorderVsp = "3";
$FGColor = "black";
$TitleBackgroundColor = "black";
$TitleForegroundColor = "white";
$InputTextColor = "pink";
$InputScreenColor = "white";

# Ignore
$IgnoreLevel = "3";

# Display options (true or false)
$DisplayConfigRealName = "false";
$DisplayConfigPort = "false";
$DisplayConfigMisc = "false";

# More Settings
$MessageCol = "80";
$AllowURL = "true";
$AllowIdentd = "true";
$isLimitedServers = "true";
$isLimitedChannels = "true";
$ConfigNickOnly = "true";
$NickNChannelOnly = "true";