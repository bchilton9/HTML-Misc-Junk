##################################################################################
##################################################################################
##              I R C - C h a t  M O D   v2.01	(For WebApp Only)				##
##______________________________________________________________________________##
##																				##
##	Copyright � GBG Softwares 2002-2003											##
##	http://www.yazaport.com/kadfors												##
##	Henrik Kadfors (gbgsoft@telia.com)											##
##______________________________________________________________________________##
##																				##
## File: ReadMe.txt																##
## Last Modified: 2003-03-30													##
##______________________________________________________________________________##
##																				##
## This program is free software; you can redistribute it and/or				##
## modify it under the terms of the GNU General Public License					##
## as published by the Free Software Foundation; either version 2				##
## of the License, or (at your option) any later version.						##
##																				##
## This program is distributed in the hope that it will be useful,				##
## but WITHOUT ANY WARRANTY; without even the implied warranty of				##
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the				##
## GNU General Public License for more details.									##
##																				##
## You should have received a copy of the GNU General Public License			##
## along with this program; if not, write to the Free Software					##
## Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.	##
##################################################################################
##################################################################################


Install Notes.

1. Edit the first line in the index.pl in an texteditor to point to the perl on your server
   (eg. #!/usr/bin/perl -w).
   
2. Edit the settings.pl to fit your wishes.
   
3. Create an folder inside the mods dir on your server and name it chat.
   (eg. ./cgi-bin/mods/chat).
   
4. Set permission on the folder "chat" to 755.

5. Upload the "index.cgi and settings.pl" to the folder "chat" in ascii mode.

6. Set permissions on "index.cgi and settings.pl" to 755

7. Create an folder in your http dir called chat
   (eg. ./www/chat)
   
8. Upload the files "biggrin.gif", "frown.gif", "IRClogo.gif", "jirc_mss.cab", "jirc_nss.cab"
   "jirc_pure.zip", "popup.js", "smile.gif", "sound_join.au", "sound_no.au", "sound_ohyea.au"
   "sound_yahoo.au", "sound_yes.au" and "tounge.gif" to the folder created in the previous step.

9. Execute your mod by typing the URL to it (eq. http://www.yourdomain.com/cgi-bin/mods/chat/index.cgi

Thats It!


FAQ:
Q - This MOD should be free so why do it ask me to register?
A - The MOD is absolutely 100% free but the jIRC applet is not. jIRC is not made by us,
	it's an program that can be found at www.jpilot.com.
	The version of jIRC included with this MOD is an full functional evolution copy.
	So if you find this MOD useful you can register it at:
	http://www.jpilot.com/java/irc/register.html

Copyright � GBG Softwares 2002-2003


############################################################################################
Information from JPilot

About JPilot's jIRC ( Version 2.6.0 )
--------------------
jIRC applet is an IRC client on the web.
jIRC connect your web site visitors to any IRC server around the world. You
can pick one of more than hundreds freely available IRC servers or you can
set up your own server.
jIRC is highly configurable to fit your web site look and feel. You can even
create your own login screen and set up different color and font size, etc..

The applet is signed with Thawte's Netscape object signing certificate, and
Microsoft Authenticode certificate, please grant the requested permission
when the pop up window appear when first load the the applet.

JPilot jIRC is shareware, this download package is for evaluation 
purpose only.

If you find it useful, and want to continue use it, please regester it at
http://www.jpilot.com/java/irc/register.html .
Unregistered applet will receive "Unregistered copy" wordings on the chat
screen during chat session.

Registration fee is one time charge of $U.S49.99 per web site domain.