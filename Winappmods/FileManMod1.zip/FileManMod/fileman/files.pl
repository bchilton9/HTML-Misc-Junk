######################################################################
# Subroutine fileproperties prints a form in a small window showing
# details about the selected file
#
sub fileproperties {

	$properties = "";
	$filename = $input{"filename"};

	@fileinfo = stat("$fm_fileDir$dir$filename");

    $properties .= "<tr><td align='right'>$LANG{'filename'}</td><td>".$filename."</td></tr>\n";
    $properties .= "<tr><td align='right'>$LANG{'filepath'}</td><td>/".$dir."</td></tr>\n";
    $properties .= "<tr><td align='right'>$LANG{'permissions'}</td><td>".sprintf "%04o\n", $fileinfo[2] & 07777."</td></tr>\n";
    $properties .= "<tr><td align='right'>$LANG{'filesize'}</td><td>".formatFileSize($fileinfo[7],"bytes")."</td></tr>\n";
    $properties .= "<tr><td align='right'>$LANG{'lastaccessed'}</td><td>".formatDate(localtime ($fileinfo[8]))."</td></tr>\n";
    $properties .= "<tr><td align='right'>$LANG{'lastmodified'}</td><td>".formatDate(localtime ($fileinfo[9]))."</td></tr>\n";

	$html = HTMLTemplate("fileproperties.html");
	$html =~ s|\%properties\%|$properties|g;

	print "Content-type: text/html\n\n";
	print $html;

} # End fileproperties


######################################################################
# Subroutine uploadfile prints a form in a small window allowing
# the selected file to be uploaded
#
sub uploadfile {

	$uploadLimit = formatFileSize($fm_userUploadLimit,"bytes");

	$html = HTMLTemplate("fileupload.html");
	$html =~ s|\%uploadLimit\%|$uploadLimit|g;

	print "Content-type: text/html\n\n";
	print $html;

} # End uploadfile


##########################################################################
# Subroutine uploadfile2 reads the file data from the local hard
# drive and saves the data to the server.
#
sub uploadfile2 {

	$filename = $input{"filename"};

	if (blank($filename)) {
		smallerror(">$filename< $LANG{'file_needfiletoupload'}");
	}

	$filetype = $query->uploadInfo($filename)->{'Content-Type'};

    # strip path information from the filenmame
	$newfile  = $filename;
	$newfile  =~ s/.*[\/\\](.*)/$1/;

	# make sure the filename is valid
	checkfilename("$fm_fileDir$dir",$newfile);

	# upload the file
	$fileSize  = 0; # in bytes
	$spaceUsed = traversesize($fm_fileDir);  # in bytes
    open(UPLOADFILE,">$fm_fileDir$dir$newfile") or smallerror("$LANG{'file_cantcreate'}");
	while(<$filename>)
	{
		print UPLOADFILE;
		$fileSize += length;

		# check if we have exceeded the single file upload limit
		# this is a redundant check to ensure we are protected against
		# Denial of Service attacks - CGI.pm is the primary handler
		# of this validation via the CGI::POST_MAX setting.
  		if ($fileSize > $fm_userUploadLimit)
		{
			close(UPLOADFILE);

			# Delete the portion of the file that has been saved
			unlink("$fm_fileDir$dir$newfile");

			$errormsg = "$LANG{'file_toolarge'}";
			$errormsg .= "$LANG{'file_mustbelessthan'} ".formatFileSize($fm_userUploadLimit,"bytes");
			smallerror($errormsg);
		}

		# check if we have exceeded this users storage limit
		if (($fileSize + $spaceUsed) > $fm_userQuota)
		{
			close(UPLOADFILE);

			# Delete the file
			#
			unlink("$fm_fileDir$dir$newfile");

			$errormsg = "$LANG{'file_toolarge'}";
			$errormsg .= "$LANG{'file_wouldexceedquota'} ".formatFileSize($fm_userQuota,"bytes");
			smallerror($errormsg);
		}
	}
    close(UPLOADFILE);

    if ($fm_serverOS eq "unix") {
      `chmod 0777 $fm_fileDir$dir$newfile'}`;
    }

	# Print a HTML page that closes the window
 	closePopup("$LANG{'file_finisheduploading'}");

}  # End uploadfile2


######################################################################
# Subroutine movefile prints a form in a small window allowing the
# user to select the destination directory for a file move
#
sub movefile {

	$name = $input{'name'};
	$name =~ s/\.\.//g;
	$name =~ s/\/\///g;

	$movedir = $input{'movedir'};
	$newdir = $input{'newdir'};

	if ($newdir ne "") {
		if ($newdir =~ /\.\./) {
			$movedir =~ s/[\w\s]+\/$//;
		} else {
			$movedir .= $newdir . "/";
		}
	}

	# encode spaces in the urls
	$move_url = $movedir;
	$move_url =~ s/ /\%20/g;

	$dir_url = $dir;
	$dir_url =~ s/ /\%20/g;

	$name_url = $name;
	$name_url =~ s/ /\%20/g;


    # Get directory listing
	opendir(MYDIR, "$fm_fileDir$movedir")
	or smallerror("$LANG{'thedirectory'} $movedir $LANG{'cantopen'}");
	while($filename = readdir(MYDIR)) {
		if ($filename ne ".") {
			if (-d "$fm_fileDir$movedir$filename") {
				push @directories, $filename;
			}
		}
	}
	closedir(MYDIR);
	@directories = sort(@directories);

	$folders = "";
	foreach $item(@directories) {
		if (!($item eq ".." and $movedir eq "")) {
			$item_url = $item;
			$item_url =~ s/ /\%20/g;

			$folders .= qq^
				<li>
		            <a href="$fm_scriptUrl?action=movefile&sid=$sid&dir=$dir_url&newdir=$item_url&name=$name_url&movedir=$move_url">
			^;
			if ($item eq "..") {
				$folders .= "<img src=\"$fm_imagesUrl/folderup1level.gif\" border=\"0\" alt=\"$LANG{'uponelevel'}\"></a>\n";
			} else {
		        $folders .= "$item</a>\n";
			}
			$folders .= "</li>\n";
		}
	}

	$html = HTMLTemplate("filemove.html");
	$html =~ s|\%name\%|$name|g;
	$html =~ s|\%movedir\%|$movedir|g;
	$html =~ s|\%folders\%|$folders|g;

	print "Content-type: text/html\n\n";
	print $html;

} # End movefile


######################################################################
# Subroutine movefile moves the selected file from the working folder
# to the destination folder
#

sub movefile2 {

	$name = $input{'name'};
	$name =~ s/\.\.//g;
	$dir2 = $input{'dir2'};
	$dir2 =~ s/\.\.//g;

	checkfilename("$fm_fileDir$dir2",$name);

	open(SOURCE, "$fm_fileDir$dir$name")
	or smallerror("$LANG{'thesourcefile'} $name $LANG{'file_cantfindnotmoved'}");

	open(DESTINATION, ">$fm_fileDir$dir2$name")
	or smallerror("$LANG{'thedestinationfile'} $name $LANG{'file_cantopennotmoved'}. ");

	while (<SOURCE>) {
		print DESTINATION;
	}

	close(SOURCE);
	close(DESTINATION);

	unlink("$fm_fileDir$dir$name")
	or smallerror("$LANG{'thefile'} $name $LANG{'file_cantfindnotdeleted'}");

	# Print a HTML page that closes the window
	closePopup("$LANG{'file_finishedmoving'}");

} # End movefile2


######################################################################
# Subroutine copyfile prints a form in a small window allowing the
# user to select the destination directory for a file copy
#
sub copyfile {

	$name = $input{'name'};
	$name =~ s/\.\.//g;
	$name =~ s/\/\///g;

	$copydir = $input{'copydir'};
	$newdir = $input{'newdir'};

	if ($newdir ne "")	{
		if ($newdir =~ /\.\./)		{
			$copydir =~ s/[\w\s]+\/$//;
		} else {
			$copydir .= $newdir . "/";
		}
	}

	$copy_url = $copydir;
	$copy_url =~ s/ /\%20/g;

	$dir_url = $dir;
	$dir_url =~ s/ /\%20/g;

	$name_url = $name;
	$name_url =~ s/ /\%20/g;


    # Get directory listing
	opendir(MYDIR, "$fm_fileDir$copydir")
	or smallerror("$LANG{'thedirectory'} $copydir $LANG{'cantopen'}");
	while($filename = readdir(MYDIR)) {
		if ($filename ne ".") {
			if (-d "$fm_fileDir$copydir$filename") {
				push @directories, $filename;
			}
		}
	}
	closedir(MYDIR);
	@directories = sort(@directories);

	$folders = "";
	foreach $item(@directories)
	{
		$item_url = $item;
		$item_url =~ s/ /\%20/g;

		if (!($item eq ".." and $copydir eq "")) {
			$folders .= qq^
					<li>
		                <a href="$fm_scriptUrl?action=copyfile&sid=$sid&dir=$dir_url&newdir=$item_url&name=$name_url&copydir=$copy_url">
			^;
			if ($item eq "..") {
				$folders .= "<img src=\"$fm_imagesUrl/folderup1level.gif\" border=\"0\" alt=\"$LANG{'uponelevel'}\"></a>\n";
			} else {
		        $folders .= "$item</a>\n";
			}
			$folders .= "</li>\n";
		}
	}

	$html = HTMLTemplate("filecopy.html");
	$html =~ s|\%name\%|$name|g;
	$html =~ s|\%copydir\%|$copydir|g;
	$html =~ s|\%folders\%|$folders|g;

	print "Content-type: text/html\n\n";
	print $html;

} # End copyfile


######################################################################
# Subroutine copyfile2 copies the selected file from the working
# folder to the destination folder
#
sub copyfile2 {

	$name = $input{'name'};
	$name =~ s/\.\.//g;
	$dir2 = $input{'dir2'};
	$dir2 =~ s/\.\.//g;

	checkfilename("$fm_fileDir$dir2",$name);

	open(SOURCE, "$fm_fileDir$dir$name")
	or smallerror("$LANG{'thesourcefile'} $name $LANG{'file_cantfindnotcopied'}");

	open(DESTINATION, ">$fm_fileDir$dir2$name")
	or smallerror("$LANG{'thedestinationfile'} $name $LANG{'file_cantopennotcopied'}");

	$fileSize = 0; # in bytes
	$spaceUsed = traversesize($fm_fileDir); # in bytes
 	while ( <SOURCE> )	{
 		print DESTINATION;
		$fileSize += length;

		# check if we have exceeded this users storage limit
		if (($fileSize + $spaceUsed) > $fm_userQuota)
		{
			close(UPLOADFILE);

			# Delete the file
			#
			unlink("$fm_fileDir$dir2$name");

			$errormsg = "$LANG{'file_toolarge'}";
			$errormsg .= "$LANG{'file_wouldexceedquota'} ".formatFileSize($fm_userQuota,"bytes");
			smallerror($errormsg);
		}
	}

	close(SOURCE);
	close(DESTINATION);

	# Print a HTML page that closes the window
	closePopup("$LANG{'file_finishedcopying'}");

} # End copyfile2



######################################################################
# Subroutine renamefile prints a form in a small window allowing
# the selected file to be renamed
#
sub renamefile {

	$name = $input{'name'};
	$name =~ s/\.\.//g;
	$name =~ s/\/\///g;

	$html = HTMLTemplate("filerename.html");
	$html =~ s|\%name\%|$name|g;

	print "Content-type: text/html\n\n";
	print $html;

} # End renamefile


######################################################################
# Subroutine renamefile2 changes the name of a given file
#
sub renamefile2 {

	$oldname = $input{'oldname'};
	$newname = $input{'newname'};

	$newname =~ s/\.\.//g;
	$oldname =~ s/\.\.//g;
	$oldname =~ s/\///g;

	# Check the input file names
	if (blank($oldname)) {
		smallerror("$LANG{'file_needfiletorename'}");
	}

	checkfilename("$fm_fileDir$dir",$newname);

	rename ("$fm_fileDir$dir$oldname", "$fm_fileDir$dir$newname")
	or smallerror("$LANG{'thefile'} $oldname $LANG{'file_cantrename'}");

	# Print a HTML page that closes the window
	closePopup("$LANG{'file_finishedrenaming'}");

} # End renamefile2


######################################################################
# Subroutine deletefile removes the selected file from the server
#
sub deletefile {

	$name = $input{'name'};
	$name =~ s/\.\.//g;

	unlink("$fm_fileDir$dir$name")
	or error("$LANG{'thefile'} $name $LANG{'file_cantfindnotdeleted'}");

	ShowExplorer();

} # End deletefile


######################################################################
# Subroutine deleteallfiles asks the user if they are sure they want to
# delete all the files in a folder before continuing
#
sub deleteallfiles {

	$html = HTMLTemplate("filedeleteall.html");

	print $html;

} # End deleteallfiles


######################################################################
# Subroutine deleteallfiles2 removes all of the files from a specified
# folder on the server.
#
sub deleteallfiles2 {

	# Remove .. from input
	$dir =~ s/\.\.//g;

    # Get directory listing
	opendir(MYDIR, "$fm_fileDir$dir")
	or error("$LANG{'thedirectory'} $dir $LANG{'cantopen'}");
	local $_;		# <- VERY IMPORTANT

	while($filename = readdir(MYDIR)) {
		if (($filename !~ /^\./) && !(-d "$fm_fileDir$dir$filename")) {
			unlink("$fm_fileDir$dir$filename")
			or error("$LANG{'thefile'} $filename $LANG{'file_cantdelete'}");
		}
	}
	closedir(MYDIR);

	ShowExplorer();

} # End deleteallfiles2


##########################################################################
# Subroutine downloadfile sends the file to the user via the browser.  The
# browser will bring up a "save as" window during this process
#
sub downloadfile {

	$name = $input{"name"};
	$name =~ s/\.\.//g;  	#remove ..
	$name =~ s/\/\//\//g;  #replace // with /

	# strip directory information from file name
	$newfile = $name;
	$newfile  =~ s/.*[\/\\](.*)/$1/;

	print "Content-Type: application/x-unknown \n";
	print "Content-Disposition: inline; filename=$newfile\n\n";

	open(DOWNLOAD, "$fm_fileDir$name")
 	or error("$fm_fileDir$fname $LANG{'cantopen'}");

 	while (<DOWNLOAD>) {
		print;
	}
	close(DOWNLOAD);

} # End downloadfile


######################################################################
# Subroutine findfile produces a screen for the user to enter data
# for a new search.
#
sub findfile {

	$html = HTMLTemplate("filefind.html");

    print "Content-type: text/html\n\n";
	print $html;

} # End findfile


######################################################################
# Subroutine closefind writes a simple HTML page to close the FIND
# window
#
sub closefind {

	$searchstring = $input{'searchstring'};
	$searchstring =~ s/ /\%20/g;
	$dir_url = $dir;
	$dir_url =~ s/ /\%20/g;

	# Print a HTML page that closes the window
	closePopup("$LANG{'finishedsearching'}",$dir_url, $searchstring);

} # End closefind


######################################################################
# Subroutine findfile2 locates all the files mathing the user's search
# string and produces a page of links to the files / folders
#
sub findfile2 {

	my ($results) = "";

	$searchstring = $input{'searchstring'};

	# Cope with spaces when writing URLs
	$dir_url = $dir;
	$dir_url =~ s/ /\%20/g;

	# Find the files
	$list = traversefind($fm_fileDir, $searchstring);

	if ($list ne "") {
		@filelist = split(/::/, $list);

		$i = 1;
		while($item = $filelist[$i]) {
			$i++;

			$file = $item;
			$file =~ s/^$fm_fileDir//;

			$dir = $file;
			if (-d $item) {
				$dir .= "/";
			} else {
				$dir =~ s/[\w\.\-\+\s:]+$//;
			}

			# Cope with spaces when writing URLs
			$my_url = $dir;
			$my_url =~ s/ /\%20/g;


			# Work out what type of file it is!
			$imagetype = fileIcon($item);

			$results .= qq~
				<tr><td><img src="$imagetype" alt="File type" border="0">
				<a href="$fm_scriptUrl?action=main&dir=$my_url">
				$file</a>
				</tr></td>
			~;
		}
	} else {
		#If no files or folders were found
		$results .= "<tr><td>$LANG{'nomatches'}</td></tr>"
	}

	$html = HTMLTemplate("filefindresults.html");

	$html =~ s|\%dir_url\%|$dir_url|g;
	$html =~ s|\%results\%|$results|g;

	print $html;

} # End findfile2


#####################################################################
# Subroutine checkfilename verifies that a file name can be used.
#
sub checkfilename {
	my ($path,$filename) = @_;
	my ($check);

	# make sure we have a name for the file
	if (blank($filename)) {
		if ($action eq "renamefile2") {
			smallerror("$LANG{'file_newnamerequired'}");
		}
	}

	# make sure a file doesn't already exist with this name
	if (-e "$path$filename") {
		smallerror("$LANG{'file_alreadyexists'}")
	}

	# Check name for special characters  ,.+-*/\:;()[]{}'"?$%^&
	$check = $filename;
 	if ($check =~ /(\,|\+|\-|\*|\/|\\|\:|\;|\(|\)|\[|\]|\{|\}|\'|\"|\?|\!|\@|\#|\$|\%|\^|\&)/) {
		smallerror("$LANG{'file_nospecchar'}<BR><BR> Found: >$&<");
	}

} # end checkfilename


1;
