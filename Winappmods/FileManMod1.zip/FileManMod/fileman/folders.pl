######################################################################
# Subroutine newfolder prints a form in a small window allowing the
# creation of a new directory within the current working directory
#
sub newfolder {

	$html = HTMLTemplate("foldernew.html");

	print "Content-type: text/html\n\n";
	print $html;

} # end newfolder


######################################################################
# Subroutine newfolder2 creates a folder within the user's current
# active folder
#
sub newfolder2 {

	$foldername = $input{'foldername'};

	# make sure the folder name is valid
	checkfoldername("$fm_fileDir$dir/",$foldername);

	# Make the new folder
	mkdir("$fm_fileDir$dir/$foldername", 0777) or smallerror("$LANG{'fldr_cantcreate'}");

	# Print a HTML page that closes the window
	closePopup("$LANG{'fldr_finishedcreating'}");

} # end newfolder2


######################################################################
# Subroutine renamefolder prints a form in a small window allowing
# the current folder to be renamed
#
sub renamefolder {

	# Strip directory information from file name
	$oldname = $dir;
	$oldname =~ /[\w\.\-\+\s:]+\/$/;
	if ($& ne "")
	{
		$oldname = $&;
		$oldname =~ s/\///g;
	}

	$html = HTMLTemplate("folderrename.html");
	$html =~ s|\%oldname\%|$oldname|g;

	print "Content-type: text/html\n\n";
	print $html;

} # End renamefolder


######################################################################
# Subroutine renamefolder2 changes the name of a given folder
#
sub renamefolder2 {

	$newname = $input{'newname'};
	$newname =~ s/\.\.//g;


	# Strip directory information from file name
	$oldname = $dir;
	$oldname =~ /[\w\.\-\+\s:]+\/$/;
	if ($& ne "") {
		$oldname = $&;
		$oldname =~ s/\///g;
	}

	$remaindir = $dir;
	$remaindir =~ s/\/$//;
	$remaindir =~ s/$oldname$//;

	$dir_url = "$remaindir$newname/";
	$dir_url =~ s/ /\%20/g;

	# make sure the folder name is valid
	checkfoldername("$fm_fileDir$remaindir",$newname);

	# Rename the folder
	rename ("$fm_fileDir$remaindir$oldname", "$fm_fileDir$remaindir$newname")
	or smallerror("$LANG{'thefile'} $oldname $LANG{'fldr_cantrename'}");

	$dir    = "";

	# Print a HTML page that closes the window
	closePopup("$LANG{'fldr_finishedrenaming'}","$remaindir$newname");

} # End renamefolder2


######################################################################
# Subroutine deletefolder removes the selected folder from the server
#
sub deletefolder {

	$name = $input{'name'};
	$name =~ s/\.\.//g;
	$name =~ s/\/\//\//g;

	# delete the folder
	rmdir("$fm_fileDir$dir$name")
	or error("$LANG{'thedirectory'} $name $LANG{'fldr_cantdelete'}");

	ShowExplorer();

} # End deletefolder

######################################################################
# Subroutine checkfoldername verifies that a folder name can be used.
#
sub checkfoldername {
	my ($path,$foldername) = @_;
	my ($check);

	# make sure we have a name for the folder
	if (blank($foldername)) {
		smallerror("$LANG{'fldr_namerequired'}");
	}

	# make sure a folder doesn't already exist with this name
	if (-e "$path$foldername") {
		smallerror("$LANG{'fldr_alreadyexists'}");
	}

	# Check name for special characters - replace bad characters with _
	$check = $foldername;
 	if ($check =~ /(\,|\+|\-|\*|\/|\\|\:|\;|\(|\)|\[|\]|\{|\}|\'|\"|\?|\!|\@|\#|\$|\%|\^|\&)/) {
		smallerror("$LANG{'fldr_nospecchar'}<BR><BR> Found: $&");
	}

} # end checkfoldername

1;