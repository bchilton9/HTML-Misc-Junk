######################################################################
# Subroutine insensitive defines the sort order for a case-insensitive
# sort function
#

sub insensitive {

	$a_lc = lc($a);
	$b_lc = lc($b);

	$retval = $a_lc cmp $b_lc;

	$retval;

} # End subroutine insensitive

######################################################################
# Subroutine dirsize returns the total of the file sizes in a
# specified directory
#

sub dirsize {

	# Get directory name
	#
    my($directory)=@_;
	my $size = 0;
	my $filename = "";

        # Get directory listing
	#
	opendir(MYDIR, "$directory");
	while($filename = readdir(MYDIR)) {
		if (!(-d "$directory$filename")) {
			$size += -s "$directory$filename";
		}
	}
	closedir(MYDIR);

	return $size;

} # End sub dirsize

######################################################################
# Subroutine traversesize goes through all of the sub-directories
# of the specified directory and finds the total size of the files
# in each directory
#

sub traversesize {

	# Get directory name
	#
    my ($directory)=@_;
	my ($size, $filename);
	local *MYDIR;

        # Get directory listing
	#
	opendir(MYDIR, "$directory")
	or error("Can not open $directory!");
	local $_;		# <- VERY IMPORTANT

	while($filename = readdir(MYDIR)) {
		if ($filename !~ /^\./) {
			if (-d "$directory$filename") {
				$size += traversesize("$directory$filename/");
			} else {
				$size += -s "$directory$filename";
			}
		}
	}
	closedir(MYDIR);

	if ($size eq "") {
		$size = "0";
	}
	return $size;

} # End sub traversesize

###################################################################
# Subroutine 'blank' checks to see if an input is blank
#

sub blank {
        my($parm)=@_;
        if ($parm =~ /\w+/x) {
                return 0;
        } else {
                return 1;
        } # End if

} # End subroutine blank

######################################################################
# Subroutine traversefind goes through all of the sub-directories
# of the specified directory and finds the total size of the files
# in each directory
#

sub traversefind {

	# Get directory name
	#
    my ($directory, $searchstring)=@_;
	my ($list, $filename);
	local *MYDIR;

    # Get directory listing
	opendir(MYDIR, "$directory")
	or error("Can not open $directory!");
	local $_;		# <- VERY IMPORTANT

	while($filename = readdir(MYDIR))	{
		if ($filename !~ /^\./)	{
			if (-d "$directory$filename") {
				$list .= traversefind("$directory$filename/", $searchstring);
			}
			if ($filename =~ /$searchstring/i) {
				$list .= "::$directory$filename";
			}
		}
	}
	closedir(MYDIR);

	return $list;

} # End sub traversefind

sub formatDate {
	my (@date) = @_;

	@Weekdays = ('Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday');
	@Months = ('January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December');
	@Now = @date;
	$Month = $Months[$Now[4]];
	$Weekday = $Weekdays[$Now[6]];
	$Hour = $Now[2];
	if ($Hour > 12) {
		$Hour = $Hour - 12;
		$AMPM = "PM";
	} else {
		$Hour = 12 if $Hour == 0;
		$AMPM ="AM";
	}
	$Minute = $Now[1];
	$Minute = "0$Minute" if $Minute < 10;
	$Year = $Now[5]+1900;

	return "$Weekday, $Month $Now[3], $Year $Hour:$Minute $AMPM";

}

sub formatFileSize {
	my ($filesize, $units) = @_;

	if ($units eq "GB") {
		if ($filesize >= 1) {
			$formattedSize  = $filesize;
			$formattedUnits = " GB";
		} elsif ($filesize >= (1/1024)) {
			$formattedSize  = $filesize * 1024;
			$formattedUnits = " MB";
		} elsif ($filesize >= (1/(1024*1024))) {
			$formattedSize  = $filesize * 1024 * 1024;
			$formattedUnits = " Kb";
		} else {
			$formattedSize  = $filesize * 1024 * 1024 * 1024;
			$formattedUnits = " bytes";
		}
	} elsif ($units eq "MB") {
		if ($filesize >= 1024) {
			$formattedSize  = $filesize / 1024;
			$formattedUnits = " GB";
		} elsif ($filesize >= 1) {
			$formattedSize  = $filesize;
			$formattedUnits = " MB";
		} elsif ($filesize >= (1/1024)) {
			$formattedSize  = $filesize * 1024;
			$formattedUnits = " Kb";
		} else {
			$formattedSize  = $filesize * 1024 * 1024;
			$formattedUnits = " bytes";
		}
	} elsif ($units eq "KB") {
		if ($filesize >= (1024 * 1024)) {
			$formattedSize  = $filesize / (1024 * 1024);
			$formattedUnits = " GB";
		} elsif ($filesize >= 1024) {
			$formattedSize  = $filesize / 1024;
			$formattedUnits = " MB";
		} elsif ($filesize >= 1) {
			$formattedSize  = $filesize;
			$formattedUnits = " Kb";
		} else {
			$formattedSize  = $filesize * 1024;
			$formattedUnits = " bytes";
		}
	} else {
		#assume we received bytes.
		if ($filesize >= 1024 * 1024 * 1024) {
			$formattedSize  = $filesize / (1024 * 1024 * 1024);
			$formattedUnits = " GB";
		} elsif ($filesize >= 1024 * 1024) {
			$formattedSize  = $filesize / (1024 * 1024);
			$formattedUnits = " MB";
		} elsif ($filesize >= 1024) {
			$formattedSize  = $filesize / 1024;
			$formattedUnits = " Kb";
		} else {
			$formattedSize  = $filesize;
			$formattedUnits = " bytes";
		}
	}

	if ($formattedUnits eq " GB") {
		$formattedSize = sprintf("%.2f",$formattedSize);
	} elsif ($formattedUnits eq " MB") {
		$formattedSize = sprintf("%.1f",$formattedSize);
	} else {
		$formattedSize = sprintf("%.0f",$formattedSize);
	}

	return $formattedSize . $formattedUnits;

} # End formatFileSize

sub convertFileSize {
	my ($filesize, $fromUnits, $toUnits) = @_;

	if ($fromUnits eq "GB") {
		if ($toUnits eq "GB") {
			$formattedSize  = $filesize;
		} elsif ($toUnits eq "MB") {
			$formattedSize  = $filesize * 1024;
		} elsif ($toUnits eq "KB") {
			$formattedSize  = $filesize * 1024 * 1024;
		} else {
			$formattedSize  = $filesize * 1024 * 1024 * 1024;
		}
	} elsif ($fromUnits eq "MB") {
		if ($toUnits eq "GB") {
			$formattedSize  = $filesize / 1024;
		} elsif ($toUnits eq "MB") {
			$formattedSize  = $filesize;
		} elsif ($toUnits eq "KB") {
			$formattedSize  = $filesize * 1024;
		} else {
			$formattedSize  = $filesize * 1024 * 1024;
		}
	} elsif ($fromUnits eq "KB") {
		if ($toUnits eq "GB") {
			$formattedSize  = $filesize / (1024 * 1024);
		} elsif ($toUnits eq "MB") {
			$formattedSize  = $filesize / 1024;
		} elsif ($toUnits eq "KB") {
			$formattedSize  = $filesize;
		} else {
			$formattedSize  = $filesize * 1024;
		}
	} else {
		#assume we are converting from bytes.
		if ($toUnits eq "GB") {
			$formattedSize  = $filesize / (1024 * 1024 * 1024);
		} elsif ($toUnits eq "MB") {
			$formattedSize  = $filesize / (1024 * 1024);
		} elsif ($toUnits eq "KB") {
			$formattedSize  = $filesize / 1024;
		} else {
			$formattedSize  = $filesize;
		}
	}

	if ($formattedUnits eq " GB") {
		$formattedSize = sprintf("%.2f",$formattedSize);
	} elsif ($formattedUnits eq " MB") {
		$formattedSize = sprintf("%.1f",$formattedSize);
	} else {
		$formattedSize = sprintf("%.0f",$formattedSize);
	}

	return $formattedSize . ' ' . $toUnits;

} # End convertFileSize

sub fileIcon {
	my ($name) = @_;
	my ($imagetype);

	if (-d $name) {
		$imagetype = "$fm_imagesUrl/icon-fldr.gif";
	} elsif ($name =~ /\.jpg|\.jpeg|\.gif/i) {
		$imagetype = "$fm_imagesUrl/icon-img.gif";
	} elsif ($name =~ /\.exe|\.com/i) {
		$imagetype = "$fm_imagesUrl/icon-exe.gif";
	} elsif ($name =~ /\.htm/i) {
		$imagetype = "$fm_imagesUrl/icon-html.gif";
	} elsif ($name =~ /\.doc|\.dot/i) {
		$imagetype = "$fm_imagesUrl/icon-doc.gif";
	} elsif ($name =~ /\.xl/i) {
		$imagetype = "$fm_imagesUrl/icon-xl.gif";
	} elsif ($name =~ /\.txt|\.log/i) {
		$imagetype = "$fm_imagesUrl/icon-txt.gif";
	} elsif ($name =~ /\.pdf/i) {
		$imagetype = "$fm_imagesUrl/icon-pdf.gif";
	} elsif ($name =~ /\.zip/i) {
		$imagetype = "$fm_imagesUrl/icon-zip.gif";
	} else {
		$imagetype = "$fm_imagesUrl/icon-none.gif";
	}

	return $imagetype;

} #End fileIcon

sub HTMLTemplate {

	my ($template_filename) = @_;
	my ($html_output);

	open (TEMPLATE, "$fm_templateDir/$template_filename") || smallerror("Cannot open file $template_filename: $!");
	while (<TEMPLATE>) {
		$html_output .= $_;
	}
	close (TEMPLATE);

	$html_output =~ s|\%fm_imagesUrl\%|$fm_imagesUrl|g;
	$html_output =~ s|\%fm_scriptUrl\%|$fm_scriptUrl|g;
	$html_output =~ s|\%fm_adminScriptUrl\%|$fm_adminScriptUrl|g;
	$html_output =~ s|\%fm_systemName\%|$fm_systemName|g;
	$html_output =~ s|\%dir\%|$dir|g;

	$html_output =~ s|\%fm_popupWindowBGStyle\%|$fm_popupWindowBGStyle|g;
	$html_output =~ s|\%fm_popupWindowStyle\%|$fm_popupWindowStyle|g;
	$html_output =~ s|\%fm_popupTitlebarStyle\%|$fm_popupTitlebarStyle|g;

	$html_output =~ s|\%fm_windowStyle\%|$fm_windowStyle|g;
	$html_output =~ s|\%fm_titlebarStyle\%|$fm_titlebarStyle|g;
	$html_output =~ s|\%fm_menubarStyle\%|$fm_menubarStyle|g;
	$html_output =~ s|\%fm_currentFolderStyle\%|$fm_currentFolderStyle|g;
	$html_output =~ s|\%fm_folderAreaStyle\%|$fm_folderAreaStyle|g;
	$html_output =~ s|\%fm_fileAreaStyle\%|$fm_fileAreaStyle|g;
	$html_output =~ s|\%fm_fileEntryStyle\%|$fm_fileEntryStyle|g;
	$html_output =~ s|\%fm_userSettingsAreaStyle\%|$fm_userSettingsAreaStyle|g;
	$html_output =~ s|\%fm_userSettingsEntryStyle\%|$fm_userSettingsEntryStyle|g;
	$html_output =~ s|\%fm_statusbarStyle\%|$fm_statusbarStyle|g;

	$html_output;

}

sub closePopup {
	my ($title,$newdir,$searchstring) = @_;
	my ($action);

	if ($newdir) {$dirinfo = "&newdir=$newdir";}
	if ($searchstring) {
		$action = "findfile2";
	} else {
		$action = "main";
	}

	print "Content-type: text/html\n\n";

	print qq~
	<html>
		<head>
			<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
			<title>$title</title>
		</head>
		<body
			onload="window.opener.location='$fm_scriptUrl?action=$action&dir=$dir$dirinfo&searchstring=$searchstring';window.close()">"
		</body>
	</html>
	~;

}

###################################################################
# Subroutine 'error' prints a simple HTML page for the user when an
# error has occurred.  The subroutine displays the input message for
# the user and goes back so that the user can try again
#
sub error{
    my($parm)=@_;

    # Script prints error message and waits for the specified time
    # before going back to the data entry screen.  The time is
    # specified in milliseconds (5000 = 5 sec)

	$html = HTMLTemplate("error.html");
	$html =~ s|\%parm\%|$parm|g;

    print_top();
	print $html;
    print_bottom();

    exit;

} # End error


###################################################################
# Subroutine 'smallerror' prints a simple small HTML page for the user
# when an error has occurred.  The subroutine displays the input message for
# the user and a "Close window" button
#
sub smallerror{
    my($parm)=@_;

    $html = HTMLTemplate("smallerror.html");
	$html =~ s|\%parm\%|$parm|g;

    print "Content-type: text/html\n\n";
	print $html;

    exit;

} # End smallerror

1;
