# _____________________________________________________________________________
sub ShowExplorer {
	# Clean up input parameters
	$newdir = $input{'newdir'};
	if ($newdir ne "")	{
		if ($newdir =~ /\.\./)	{
			$dir =~ s/[\w\s\.\-\+]+\/$//;
		} else {
			$dir .= $newdir . "/";
		}
	}

	# Cope with spaces when writing URLs
	$dir_url = $dir;
	$dir_url =~ s/ /\%20/g;

	#-------------------------------------------
	# Retrieve information to build the screen
	#-------------------------------------------
    # Get directory listing
    if (!(-e $fm_fileDir)) {
		mkdir ("$fm_fileDir", 0777)
		or error("Can not create file directory.");
	}

	opendir(MYDIR, "$fm_fileDir$dir")
	or &error("$LANG{'thedirectory'} $dir $LANG{'cantopen'}");
	while($filename = readdir(MYDIR)) {
		if ($filename !~ /^\.$/) {
			if (-d "$fm_fileDir$dir$filename") {
				push @directories, $filename;
			} else {
				push @files, $filename;
			}
		}
	}
	closedir(MYDIR);
	@directories = sort insensitive (@directories);
	@files		 = sort insensitive (@files);


	# Get directory and total file space used
	$dirsize   = formatFileSize(dirsize("$fm_fileDir$dir"),"bytes");
	$totalsize = formatFileSize(traversesize("$fm_fileDir"),"bytes");
	$quotasize = formatFileSize($fm_userQuota,"bytes");

	# get client IP address
	$ip_address = $ENV{'REMOTE_ADDR'};

	# build rename button (disable for root)
	if (! blank($dir))	{
		$rename_folder = qq^
			<a href="#"
			onClick="var renamewin=window.open('$fm_scriptUrl?action=renamefolder&dir=$dir_url','rename','height=200,width=380,status');renamewin.creator=self;renamewin.focus()"
	        onmouseover="status='$LANG{'renamefolder'}';return true"
	        onmouseout="status=' '"><IMG SRC="$fm_imagesUrl/folderrename.gif" BORDER=0 align="middle" ALT="$LANG{'renamefolder'}"></a>
		^;
	} else {
		$rename_folder = qq^
			<IMG SRC="$fm_imagesUrl/folderrename-no.gif" BORDER=0 align="middle" ALT="$LANG{'cantrenamehome'}">
		^;
	}

	if ($username eq "admin") {
		$admin_options = qq^
			<a href="$fm_adminScriptUrl?fmCOMMAND=SETTINGS"
			onmouseover="status='$fm_systemName $LANG{'generalsettings'}';return true"
	        onmouseout="status=' '"><IMG SRC="$fm_imagesUrl/adminsettings.gif" BORDER=0 align="middle" ALT="$fm_systemName $LANG{'generalsettings'}"></a>
			<a href="$fm_adminScriptUrl?fmCOMMAND=USERS"
			onmouseover="status='$fm_systemName $LANG{'users'}';return true"
	        onmouseout="status=' '"><IMG SRC="$fm_imagesUrl/adminusers.gif" BORDER=0 align="middle" ALT="$fm_systemName $LANG{'users'}"></a>
			<img border="0" src="$fm_imagesUrl/separator.gif" align="middle">
		^;
	}

	# build HTML for folder area
	$folders = "";
	foreach $name(@directories)
	{
		if (!($name eq ".." and $dir eq ""))
		{
			$name_url = $name;
			$name_url =~ s/ /\%20/g;
			$folders .= qq^
				<table border=0 cellspacing=0 cellpadding=2 width="145">
				 <tr>
				  <td valign="top">
			^;
			if ($name eq "..") {
				$folders .= qq^
		           	<a href="$fm_scriptUrl?action=main&dir=$dir_url&newdir=$name_url"
		           	onmouseover="status='$LANG{'uponelevel'}';return true" onmouseout="status=' '">
					<img src=\"$fm_imagesUrl/folderup1level.gif\" alt=\"$LANG{'uponelevel'}\" border=\"0\"></a></td>
			^;
			} else {
				$folders .= qq^
				   	<img src="$fm_imagesUrl/folder.gif">
		           	<a href="$fm_scriptUrl?action=main&dir=$dir_url&newdir=$name_url"
		           	onmouseover="status='$LANG{'changefolderto'} $name';return true" onmouseout="status=' '">
					$name
					</a>
					</td>
					<td valign="top" width="15">
					<a href="$fm_scriptUrl?action=deletefolder&dir=$dir_url&name=$name_url"
			                onmouseover="status='$LANG{'removefolder'} &quot;$name&quot;';return true" onmouseout="status=' '">
					<img src="$fm_imagesUrl/folderdelete.gif" alt="$LANG{'removefolder'} &quot;$name&quot;" border="0">
					</a>
					</td>
			^;
			}

			$folders .= "</tr></table>";
		}
	}

	# build HTML for file area
	$files = "";
	foreach $name(@files)
	{
		$name_url = $name;
		$name_url =~ s/ /\%20/g;


		# Truncate the name to 17 characters max.
		#
		if ($name =~ /^[\w\.\-\+\s:]{18}/) {
			$name =~ /^[\w\.\-\+\s:]{15}/;
			$shortname = $& . "..";
		} else {
			$shortname = $name;
		}


		#
		# Work out what type of file it is!
		#
		$imagetype = fileIcon($name);

		$fileURL = "root/".$dir_url.$name_url;
		$files .= qq^
			<tr><td  style="$fm_fileEntryStyle">
				<img src="$imagetype">
				<a href="$fm_scriptUrl?action=downloadfile&dir=$dir_url&name=$dir_url$name_url">$shortname</a>
			</td>
			<td  style="$fm_fileEntryStyle">
				<a href="#"
					onClick="var infowin=window.open('$fm_scriptUrl?action=fileproperties&dir=$dir_url&filename=$name_url','properties','height=220,width=380');infowin.creator=self;infowin.focus()"
	                onmouseover="status='$name $LANG{'properties'}';return true" onmouseout="status=' '"><img src="$fm_imagesUrl/fileinfo.gif" border="0" alt="$name $LANG{'properties'}"></a>
				<a href="#"
					onClick="var renamewin=window.open('$fm_scriptUrl?action=renamefile&dir=$dir_url&name=$name_url','rename','height=200,width=380');renamewin.creator=self;renamewin.focus()"
	                onmouseover="status='$LANG{'renamefile'} $name';return true" onmouseout="status=' '"><img src="$fm_imagesUrl/filerename.gif" border="0" alt="$LANG{'renamefile'} $name"></a>
				<a href="#"
					onClick="var movewin=window.open('$fm_scriptUrl?action=movefile&dir=$dir_url&name=$name_url','move','height=300,width=380,scrollbars');movewin.creator=self;movewin.focus()"
	                onmouseover="status='$LANG{'movefile'} $name';return true" onmouseout="status=' '"><img src="$fm_imagesUrl/filemove.gif" border="0" alt="$LANG{'movefile'} $name"></a>
				<a href="#"
					onClick="var copywin=window.open('$fm_scriptUrl?action=copyfile&dir=$dir_url&name=$name_url','copy','height=300,width=380,scrollbars');copywin.creator=self;copywin.focus()"
	                onmouseover="status='$LANG{'copyfile'} $name';return true" onmouseout="status=' '"><img src="$fm_imagesUrl/filecopy.gif" border="0" alt="$LANG{'copyfile'} $name"></a>
				<a href="#"
					onClick="this.href='javascript:del(\\'$name_url\\')'"
	                STYLE="cursor: hand"
	                onmouseover="status='$LANG{'deletefile'} $name';return true" onmouseout="status=' '"><img src="$fm_imagesUrl/filedelete.gif" border="0" alt="$LANG{'deletefile'} $name"></a>
			</td>
			<td align="left" style="$fm_fileEntryStyle">
		^;
		@fileinfo = stat("$fm_fileDir$dir$name");
		$size = formatFileSize(int($fileinfo[7]),"bytes");
		$files .= qq^
				$size</td><td align="left" style="$fm_fileEntryStyle">
		^;
		$lastmod = localtime($fileinfo[9]);
		@items = split(' ', $lastmod);
		$month	= $items[1];
		$day	= $items[2];
		$time	= $items[3];
		$year	= $items[4];
		$year =~ s/^..//;
		$lastmod = "$time $day $month $year";
		$files .=  ("$lastmod</font></td></tr>\n");

	} # End foreach $file

	# Display a delete all button if there are any files
	#
	$delallbtn = "";
	$count = @files;
	if ($count > 0)
	{
		$delallbtn = qq^
			<p align="right">
			<form method="post" action="$fm_scriptUrl">
				<input type="hidden" name="action" value="deleteallfiles">
				<input type="hidden" name="dir" value="$dir_url">
				<input type="submit" value="$LANG{'deleteallfiles'}" name="deleteall" style="font-size: 8pt">
			</FORM>
			</p>
		^;
	}

    # Start printing the project menu
    #
	$html = HTMLTemplate("explorer.html");
	$html =~ s|\%webappHome\%|$baseurl|g;
	$html =~ s|\%dir_url\%|$dir_url|g;
	$html =~ s|\%username\%|$username|g;
	$html =~ s|\%ip_address\%|$ip_address|g;
	$html =~ s|\%quotaSize\%|$quotasize|g;
	$html =~ s|\%totalSize\%|$totalsize|g;
	$html =~ s|\%dirSize\%|$dirsize|g;
	$html =~ s|\%rename_folder\%|$rename_folder|g;
	$html =~ s|\%admin_options\%|$admin_options|g;
	$html =~ s|\%folders\%|$folders|g;
	$html =~ s|\%files\%|$files|g;
	$html =~ s|\%delallbtn\%|$delallbtn|g;

	print $html;
}

1;
