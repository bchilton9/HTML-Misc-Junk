$mm_scriptUrl   	= "$scripturl/mods/menuman";
$mm_scriptDir   	= "$scriptdir/mods/menuman";
$mm_dataDir     	= "$mm_scriptDir/data";

1;