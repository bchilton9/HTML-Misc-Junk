#########################################
####  Web-app installation instructions 
####      bigmike@bigmikesmedia.com
#########################################
  
Installation is pretty straight forward just follow these simple steps.
I've got this working on both 0.9.7 and 0.9.8

 1) Modify the URL and path settings in tagbox.cgi,tagbox.cfg and the plugin.txt.

 2) Put both the "tagbox.cgi" file and the "tagbox.cfg" file in your Web-app cgi-bin.

 3) Cut and paste the plugin from the plugin.txt file into your plugin.pl file where
    you want it to show up.

 3) Put the smiley images folder in your Web-app images folder.

 4) Put the tagbox.html file in your root html directory.

 5) chmod the files accordingly.
    
     tagbox.html  777
     tagbox.cgi   755
     
That should be it!

Note: I know this can be trimmed down a bit but I'm not coder and can't figure it out.
      I'm sure one of the great Web-app coders can easily modify this so that all you 
      need is the pluin, the html page and the graphics.

    **  The tagbox.cgi is the original script with the authors copyright intact.

