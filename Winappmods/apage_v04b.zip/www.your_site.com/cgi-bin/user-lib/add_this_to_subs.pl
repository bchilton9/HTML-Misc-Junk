#----------------------------------------------------------#
#              Start of htmlArea 4 WebAPP 
#
# Description: 
#   Allows enhanced htmlArea across site that use WeAPP.
# Modified for WebAPP by Weston Lemos 
# Last Modified May 13, 2003 
#----------------------------------------------------------#
sub htmlAreaInsert {
###------------------------------------------------------###
### IMOPTANT NOTE: Make sure the variables below are set ###
### correctly according to your site's setup.  If you    ###
### followed the standard setup locations, this should   ###
### already be set correctly.                            ###
###------------------------------------------------------###
$HAimagesURL  = "$imagesurl/apage/icons/htmlarea";         #- This is the URL (http://...) to where htmlarea's images are. 
$HApopupsURL  = "$baseurl/htmlarea/popups";                #- This is the URL (http://...) to where htmlarea's popup pages are. Note: this NEEDS to be right below the dir with the main .js files.
$HAVAR        = "$basedir/htmlarea";                       #- This is the FULL Path to where the main htmlArea .js files are. 
###------------------------------------------------------###
################### End of Configuration ###################
###------------------------------------------------------###

$HAm = "@_[0]";

open(FILE, "$HAVAR/htmlarea.js") || error("$HAVAR/htmlarea.js");   
lock(FILE); 
@lines1 = <FILE>; 
unlock(FILE); 
close(FILE); 

open(FILE, "$HAVAR/htmlarea-lang-en.js") || error("$HAVAR/htmlarea-lang-en.js");   
lock(FILE); 
@lines2 = <FILE>; 
unlock(FILE); 
close(FILE); 

open(FILE, "$HAVAR/dialog.js") || error("$HAVAR/dialog.js");   
lock(FILE); 
@lines3 = <FILE>; 
unlock(FILE); 
close(FILE); 

open(FILE, "$HAVAR/htmlarea.css") || error("$HAVAR/htmlarea.css");   
lock(FILE); 
@lines4 = <FILE>; 
unlock(FILE); 
close(FILE); 

$htmlarealines .= "<script type=\"text\/javascript\">\n";
foreach $line (@lines1) { $htmlarealines .= "$line\n"; }
$htmlarealines .= "</script>\n";
$htmlarealines .= "<script type=\"text\/javascript\">\n";
foreach $line (@lines2) { $htmlarealines .= "$line\n"; }
$htmlarealines .= "</script>\n";
$htmlarealines .= "<script type=\"text\/javascript\">\n";
foreach $line (@lines3) { $htmlarealines .= "$line\n"; }
$htmlarealines .= "</script>\n";
$htmlarealines .= "<style type=\"text\/css\">\n";
foreach $line (@lines4) { $htmlarealines .= "$line\n"; }
$htmlarealines .= "</style>\n";

print qq~

$htmlarealines

<script type="text/javascript">
var editor = null;
function initEditor() {
var cfg = new HTMLArea.Config(); 
cfg.editorURL = ""; 
cfg.imgURL = "$HAimagesURL/";
cfg.popupURL = "$HApopupsURL/";

var editor = new HTMLArea("$HAm", cfg); 
  editor.generate();
}
</script>
<body onload="initEditor()">
~;
} #close sub htmlAreaInsert
###------------------------------------------------------###
##################### End of htmlArea ######################
###------------------------------------------------------###

# Make sure your user-lib/subs.pl ends with a 1; and has its permissions set to 755 #
1;
