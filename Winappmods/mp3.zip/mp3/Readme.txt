###############################################################################
License
###############################################################################

This Mod may be freely distributed or modified under the terms of the GNU 
General Public License. However, if you improve and/or redistribute it, please 
notify me so I know how the script is being used and/or improved!

###############################################################################

################################################################################
Overview
################################################################################
This is a modified version of the User Gallery. It was designed to allow you to 
maintain an mp3 jukebox on your site. Files are uploaded and then when the link
is clicked, it downloads to a temp folder and begins playing.
################################################################################
Pre-Installation/Upgrade Warning!
################################################################################

mp3 Jukebox v1.5 uses routines unique to WebAPP v0.9.8 and is thus not compatable
with pre v0.9.8 versions of the WebAPP system. Please upgrade your site to v0.9.8
before installing or upgrading User Gallery.

################################################################################
Installation
################################################################################

First, you should unzip mp3.zip to your computer as there is some editing that you need to do!

Next, edit the path to perl in index.cgi, ugupload.cgi, and admin.cgi.

Once you have done this, you can save all the scripts, and upload the usergallery folder to your
mods directory in ASCII mode except the gfx folder which should be uploaded in BINARY mode
(see note below regarding graphics in your cgi-bin).

CHMOD all the .cgi files 755 (see also ugconvert.cgi below).Copy the music.gif file
from the images folder to your images directory.

Copy the mp3 folder within the images directory to your images directory. It should
then look something like this...

images/mp3
images/mp3/gfx
images/mp3/pending

CHMOD these folders 777 (you may have to CHMOD the images folder 777 too, it depends on your server!)

################################################################################