# URL to gen_db directory
$teamanager_path = "http://127.0.0.1/cgi-bin/mods/teamanager";

# Full Path to gen_db directory
$full_teamanager_path = "web/cgi-bin/mods/teamanager";

# URL to images directory
$images_path = "http://127.0.0.1/cgi-bin/mods/teamanager/images";

# URL to gen_db Admin directory
$teamanager_admin_path = "http://127.0.0.1/cgi-bin/mods/teamanager/admin";

# Full Path to gen_db storage directory
$teamanager_db_path = "web/cgi-bin/db/teamanager";

# URL to main webapp index.cgi
$webappURL = "http://127.0.0.1/cgi-bin/index.cgi";

# Full Path to team record storage directory
$record_path = "web/cgi-bin/db/teamanager/records";