##################################################################################
##################################################################################
##              G U E S T B O O K  P R O  v3.0	(For WebApp Only)				##
##______________________________________________________________________________##
##																				##
##	Copyright � GBG Softwares 2002-2003											##
##	http://www.yazaport.com/kadfors												##
##	Henrik Kadfors (gbgsoft@telia.com)											##
##______________________________________________________________________________##
##																				##
## File: settings.pl															##
## Last Modified: 2003-03-30													##
##______________________________________________________________________________##
##																				##
## This program is free software; you can redistribute it and/or				##
## modify it under the terms of the GNU General Public License					##
## as published by the Free Software Foundation; either version 2				##
## of the License, or (at your option) any later version.						##
##																				##
## This program is distributed in the hope that it will be useful,				##
## but WITHOUT ANY WARRANTY; without even the implied warranty of				##
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the				##
## GNU General Public License for more details.									##
##																				##
## You should have received a copy of the GNU General Public License			##
## along with this program; if not, write to the Free Software					##
## Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.	##
##################################################################################
##################################################################################

# Main Settings

# Pathes And Url's
$modpath = "$scriptdir/mods/guestbook";
$modurl = "$scripturl/mods/guestbook";
$guestimageurl = "$imagesurl/guestbook";
$moddatadir = "$scriptdir/mods/guestbook/db/entries";
$modwelcomedir = "$scriptdir/mods/guestbook/db/welcome";
$modlangdir = "$scriptdir/mods/guestbook/languages";
$adminurl = "$scripturl/mods/guestbook/admin";
$templatesdir = "$scriptdir/mods/guestbook/themes";
$mainscript = "index.cgi";
$secscript = "guestbook.cgi";
$adminscript = "admin.cgi";
$wmessscript = "welcomemsg.db";

# Languages And Themes
$guestlanguagename = "english";
$guesttemplate = "standard";

#Administrator Access
$adminaccess = "2";

# Access Settings
$guestallow = "1";

# Time Settings
$tidsformat = "us2";
$datumformat = "eu2";
$tidjust = "+";
$tidjust1 = "0";
$timesepatator = ":";
$timesepatatortva = ":";
$datesepatator1 = ", ";
$datesepatator2 = " ";
$arformat = "";
$timedateorder = "1";
$timedateseparator = " - ";

# Spam Protection
$spamprot = "y";
$spamnr = "25";
$urlspam = "y";
$gestautoban = "n";

# Word Censor
$censurprot = "y";

# Ip-Logging
$iplogg = "2";

# E-mail Notification
$emailnotifi = "n";

# Thankyou E-mail
$thankyoumail = "n";

# Private Messages
$privmess = "y";

# On / Offline Indicator
$onlinechecker = "y";
$onlinecheckwho = "all";

###########################################

# Layout

# Main Settings
$visaantal = "5";
$omvant = "Yes";
$showpic = "y";
$bordersize1 = "1";
$bordercolor1 = "#336699";

# Welcomemessagebox
$backcolor1 = "#DEE7EF";
$fontcolor1 = "#003399";
$fontsize1 = "2";

# Postbox
$smiliesar = "y";
$smiliesar2 = "y";
$visafalt2 = "y";
$visafalt3 = "y";
$visafalt4 = "y";
$visafalt5 = "y";
$visafalt6 = "n";
$visafalt7 = "n";
$tillatifyllnad = "y";
$backcolor2 = "#EFF7FF";
$fontcolor2 = "#003399";
$fontsize2 = "2";

# Messagebox
$guestiploggning = "i";
$guestinstim = "y";
$guesthemsidaicon = "y";
$guesteposticon = "y";
$guesticqicon = "y";
$guestaimicon = "n";
$guestyahooicon = "n";
$guestprofileicon = "y";
$hidepic4guest = "n";
$backcolor3 = "#DEE7EF";
$fontcolor3 = "#003399";
$fontsize3 = "2";
$showsmileicon = "y";
$backcolor4 = "#EFF7FF";
$fontcolor4 = "#000000";
$fontsize4 = "2";
$allowpopup = "all";
$backcolor10 = "#DEE7EF";
$fontcolor10 = "#003399";
$fontsize10 = "2";
$fontface10 = "Arial, Helvetica, sans-serif";


# Searchbox
$showsearchbox = "Yes";
$backcolor5 = "#DEE7EF";
$fontcolor5 = "#003399";
$fontsize5 = "2";

# Footer
$showfoottxt = "y";
$showfootimges = "y";
$showfootpages = "y";
$fotstil = "img";
$backcolor6 = "#EFF7FF";
$fontcolor6 = "#003399";
$fontsize6 = "2";

# Admin Footer
$backcolor7 = "#DEE7EF";
$fontcolor7 = "#003399";
$fontsize7 = "2";

# Add Admin Comment
$backcolor8 = "#EFF7FF";
$fontcolor8 = "#003399";
$fontsize8 = "2";

# Edit Message
$backcolor9 = "#EFF7FF";
$fontcolor9 = "#003399";
$fontsize9 = "2";