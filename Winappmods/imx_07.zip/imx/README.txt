IMX 


IMX  0.7  :  A redesigned IM Plug-in for web-app.  
With sent Folder, and Saved Folder and now new the ability to add folders of your own.  
IM posting with UBBC tags capabilities and message icons and now a quicklist contact.  
IMX has an image upload function and a preview before sending the IM.  

using the progress bar to give you a storage limit look, but no server quota is used, only useful to notify users to clean up a bit.  
The way that it notifies users are as follow, at 20% it writes underneath the storage limit bar a written message, 
next at 0% the user's name is written in a log where only the admin can see when the user was warned and what folder, 
the admin has then an option to send that user and IM when looking at the log, 
also an option to delete the user from the log otherwise they get notified again.  
More hidden features included, thanks for using this plug-in.

 
version history: 

0.1 - redesigned the im plug-in, adding 2 folders.
0.2 - added storage limit bar.
0.3 - redesigned the whole thing, added graphics.
0.4 - added message icons.
0.5 - added contacts, merge the buddylist to the imx.
0.6 - folder utility fixed, storage limit bar color.
0.7 - imx preview, redesigned the storage limit bar, using themes.

instructions:

Get a hold of your index.cgi file, back it up, create a new line, paste this in:



elsif ($action eq "addfolder") {require "$scriptdir/user-lib/instantmessage.pl"; addfolder();}
elsif ($action eq "deletefolder") {require "$scriptdir/user-lib/instantmessage.pl"; deletefolder();}
elsif ($action eq "folder") {require "$scriptdir/user-lib/instantmessage.pl"; folder();}
elsif ($action eq "messagefolder") { require "$scriptdir/user-lib/instantmessage.pl"; foldermessages();}
elsif ($action eq "im4") { require "$scriptdir/user-lib/instantmessage.pl"; foldermessages();}

elsif ($action eq "contacts") { require "$scriptdir/user-lib/instantmessage.pl"; contact();}
elsif ($action eq "addcontact") { require "$scriptdir/user-lib/instantmessage.pl"; addcontact();}
elsif ($action eq "addcontact2") { require "$scriptdir/user-lib/instantmessage.pl"; addcontact2();}
elsif ($action eq "editcontact") { require "$scriptdir/user-lib/instantmessage.pl"; editcontact();}
elsif ($action eq "deletecontact") { require "$scriptdir/user-lib/instantmessage.pl"; deletecontact();}

elsif ($action eq "im") { require "$sourcedir/instantmessage.pl"; imindex(); }
elsif ($action eq "deletefromylog") { require "$scriptdir/user-lib/instantmessage.pl"; deletefromylog(); }
elsif ($action eq "userimindex") { require "$scriptdir/user-lib/instantmessage.pl"; userimindex(); }
elsif ($action eq "userimindex2") { require "$scriptdir/user-lib/instantmessage.pl"; userimindex2(); }
elsif ($action eq "userimindex3") { require "$scriptdir/user-lib/instantmessage.pl"; userimindex3(); }
elsif ($action eq "userimindex4") { require "$scriptdir/user-lib/instantmessage.pl"; userimindex4(); }
elsif ($action eq "messageadmin") { require "$scriptdir/user-lib/instantmessage.pl"; messageadmin(); }
elsif ($action eq "messageadmin2") { require "$scriptdir/user-lib/instantmessage.pl"; messageadmin2();}
elsif ($action eq "messageadmin3") { require "$scriptdir/user-lib/instantmessage.pl"; messageadmin3();}
elsif ($action eq "messageadmin4") { require "$scriptdir/user-lib/instantmessage.pl"; messageadmin4();}
elsif ($action eq "im2") { require "$scriptdir/user-lib/instantmessage.pl"; imfolder(); }
elsif ($action eq "im3") { require "$scriptdir/user-lib/instantmessage.pl"; imsaved();}
elsif ($action eq "imfolder") { require "$scriptdir/user-lib/instantmessage.pl"; imfolder(); }
elsif ($action eq "saveim") { require "$scriptdir/user-lib/instantmessage.pl"; imsaved(); }
elsif ($action eq "moveim") { require "$scriptdir/user-lib/instantmessage.pl"; moveim(); }
elsif ($action eq "moveim2") { require "$scriptdir/user-lib/instantmessage.pl"; moveim2(); }
elsif ($action eq "moveim3") { require "$scriptdir/user-lib/instantmessage.pl"; moveim3(); }
elsif ($action eq "moveim4") { require "$scriptdir/user-lib/instantmessage.pl"; moveim4(); }
elsif ($action eq "imremove") { require "$sourcedir/instantmessage.pl"; imremove(); }
elsif ($action eq "myuserremove") { require "$scriptdir/user-lib/instantmessage.pl"; myuserremove(); }
elsif ($action eq "myuserremove2") { require "$scriptdir/user-lib/instantmessage.pl"; myuserremove2(); }
elsif ($action eq "myuserremove3") { require "$scriptdir/user-lib/instantmessage.pl"; myuserremove3(); }
elsif ($action eq "imremove2") { require "$scriptdir/user-lib/instantmessage.pl"; imremove2(); }
elsif ($action eq "imremove3") { require "$scriptdir/user-lib/instantmessage.pl"; imremove3(); }
elsif ($action eq "imremove4") { require "$scriptdir/user-lib/instantmessage.pl"; imremove4(); }
elsif ($action eq "imremove5") { require "$scriptdir/user-lib/instantmessage.pl"; imremove5(); }
elsif ($action eq "imsend") { require "$sourcedir/instantmessage.pl"; impost(); }
elsif ($action eq "imsend2") { require "$sourcedir/instantmessage.pl"; impost2(); }
elsif ($action eq "siteim") { require "$sourcedir/instantmessage.pl"; siteim(); }
elsif ($action eq "siteim2") { require "$sourcedir/instantmessage.pl"; siteim2(); }
elsif ($action eq "adminim") { require "$sourcedir/instantmessage.pl"; adminim(); }
elsif ($action eq "adminim2") { require "$sourcedir/instantmessage.pl"; adminim2(); }
elsif ($action eq "modim") { require "$sourcedir/instantmessage.pl"; modim(); }
elsif ($action eq "modim2") { require "$sourcedir/instantmessage.pl"; modim2(); }


save and upload in ascii mode.

Next, 
get a hold of your lang file, paste this tags in:  (change them to what you feel comfortable, but using the same concept, e.g. My Inbox to IMX Inbox ... etc.)
$imx{'001'} = "My Inbox";
$imx{'002'} = "Storage Limit"; 
$imx{'003'} = "Available"; 
$imx{'004'} = "Max Messages"; 
$imx{'005'} = "Sent";
$imx{'006'} = "Saved"; 
$imx{'007'} = "Close Message"; 
$imx{'008'} = "Sent Messages"; 
$imx{'009'} = "Copy of"; 
$imx{'010'} = "My Saved Messages"; 
$imx{'011'} = "Your Folder is getting full"; 
$imx{'012'} = "If it reaches 0% the admin will be notified and will delete your old message.  To avoid this, delete unwanted and old messages.  Thanks.";
$imx{'013'} = "Your Folder is Full"; 
$imx{'014'} = "A New Private Message"; 
$imx{'015'} = "logout"; 
$imx{'016'} = "register"; 
$imx{'017'} = "Message Icon"; 
$imx{'018'} = "Small"; 
$imx{'019'} = "Normal"; 
$imx{'020'} = "Medium"; 
$imx{'021'} = "Large"; 
$imx{'022'} = "Extra Large"; 
$imx{'023'} = "QUOTE";
$imx{'024'} = "Keep a copy of this message in my sent folder?";
$imx{'025'} = "You have no sent messages";
$imx{'026'} = "You have no saved messages";
$imx{'027'} = "Message of"; 
$imx{'028'} = "has been saved. <Br> Return to ";
$imx{'029'} = "Anonymous";
$imx{'030'} = "You have set";
$imx{'031'} = "as the max number";
$imx{'032'} = "Inbox Folder";
$imx{'033'} = "Sent Folder";
$imx{'034'} = "Saved Folder";
$imx{'035'} = "Max Message";
$imx{'036'} = "Save IM Folder";
$imx{'037'} = "Type in a number";
$imx{'038'} = "Type in a number to change it.  Or <a href=$cgi?action=im>Leave it like that?</a>";
$imx{'039'} = "*Recommended no more than 100";
$imx{'040'} = "Set Changes";
$imx{'041'} = "Save";
$imx{'042'} = "IM-Groups";
$imx{'043'} = "Online";
$imx{'044'} = "Offline";
$imx{'045'} = "Contacts";
$imx{'046'} = "Write";
$imx{'047'} = "Online";
$imx{'048'} = "Has been modified";
$imx{'049'} = "cannot be the similar to the ";
$imx{'050'} = "Add Contact";
$imx{'051'} = "Folders";
$imx{'052'} = "Max Folders";
$imx{'053'} = "Note: If folder is deleted, all messages in that folder will be deleted.";
$imx{'054'} = "Send a background carbon copy to another user, leave it blank if not used.";
$imx{'055'} = "Color";
$imx{'056'} = "Style";
$imx{'057'} = "Size";
$imx{'058'} = "New Message(s)";
$imx{'059'} = "Go to: ";


upload your lang file in ascii mode.



Next, upload instantmessage.pl file in your user-lib folder.  
Make sure you user a browser that supports javascript and that is is on.
Only admin can see admin tools.  

Please read any imx additions included in the zip file.  Thanks.



