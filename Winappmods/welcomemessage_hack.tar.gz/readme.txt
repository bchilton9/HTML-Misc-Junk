##################################################
######   Big Mike's Welcome Message Hack    ######
######              5-15-03                 ######
######     bigmike@bigmikesmedia.com        ######
################################################## 

This hack will add the ability to display a different welcome message depending on
wether your visitor is a guest or a member. The nice feature of this hack (aside from
diplaying different welcome messages) is that it's all done through your admin screen
just like your already used to.

Installation:

1. Drop the included welcomemsg2.txt file into your db folder and chmod 666.  /cgi-bin/db/welcomemsg2.txt

2. Drop the included admin.pl file into your cgi-lib folder after you back up your original and chmod 755.
   *Note: if your using my centerblock hack you have to uncomment lines 153 and 154. Look for my comments.

3. Last but not least copy the sub print_main included in the subs.pl file to your subs.pl file in your
   user-lib folder. If you already have a sub print_main there you'll need to modify it. Look about half
   way down for my comments. All you have to do is add a '2' to welcomemsg.txt making it welcomemsg2.txt,
   again you'll see my comments.

Enjoy!

Mike



