################
sub print_main {
################
		if ($username ne "$anonuser") {

		open(FILE, "$memberdir/$username.pref") || error("$err{'010'}");
		lock(FILE);
		chomp(@preferences = <FILE>);
		unlock(FILE);
		close(FILE);

		if ($preferences[3] == 1 || $preferences[3] eq "" ) {

	open(FILE, "$datadir/welcomemsg.txt");
	lock(FILE);
	chomp(@lines = <FILE>);
	unlock(FILE);
	close(FILE);

	$welcometitle = showhtml("$lines[0]");
	$welcomebody = showhtml("$lines[1]");

	$welcome = qq~<table border="0" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td><p class="texttitle">$welcometitle</p>
$welcomebody<br>
</td>
</tr>
</table>
~;
	}
	}

if ($username eq "$anonuser") {
open(FILE, "$datadir/welcomemsg2.txt");## Modified for bogmike's welcome message hack, add the '2' after welcomemsg
	lock(FILE);
	chomp(@lines = <FILE>);
	unlock(FILE);
	close(FILE);

	$welcometitle = showhtml("$lines[0]");
	$welcomebody = showhtml("$lines[1]");


	$welcome = qq~<table border="0" cellpadding="0" cellspacing="0" width="100%">
<tr>
<td><p class="texttitle">$welcometitle</p>
$welcomebody<br>
</td>
</tr>
</table>
~;
}

	require "$sourcedir/topics.pl";
	viewnews();

	exit;
}

 
1; # return true


