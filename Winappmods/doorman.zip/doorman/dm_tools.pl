##############
sub access1{
##############

}

##############
sub access2{
##############


}

##############
sub access3{
##############


}

##############
sub access4{
##############


}

##############
sub access5{
##############


}

##############
sub access6{
##############



}


##############
sub access7{
##############



}

##############
sub access8{
##############


}

##############
sub makefolders{
##############
require "$mods_dir/doorman/admin/dm_config.dat";

##### Is it says..making fodlers!  Most of them are not yet in function #####
unless (-e("$dm_hacks_dir")) {
	mkdir("$dm_hacks_dir",0777);
	chmod(0777,"$dm_hacks_dir");
	
}  
unless (-e("$dm_floods_dir")) {
	mkdir("$dm_floods_dir",0777);
	chmod(0777,"$dm_floods_dir");
}  

unless (-e("$dm_default_ban_dir")) {
	mkdir("$dm_default_ban_dir",0777);
	chmod(0777,"$dm_default_ban_dir");
	
}  
unless (-e("$dm_lang_dir")) {
	mkdir("$dm_lang_dir",0777);
	chmod(0777,"$dm_lang_dir");
	
}  

unless (-e("$dm_chmod_dir")) {
	mkdir("$dm_chmod_dir",0777);
	chmod(0777,"$dm_chmod_dir");
	
}  
unless (-e("$dm_backup_dir")) {
	mkdir("$dm_backup_dir",0777);
	chmod(0777,"$dm_backup_dir");
	
}  
unless (-e("$dm_reset_dir")) {
	mkdir("$dm_reset_dir",0777);
	chmod(0777,"$dm_reset_dir");
	
}  
unless (-e("$dm_bans_dir")) {
	mkdir("$dm_bans_dir",0777);
	chmod(0777,"$dm_bans_dir");
	
}  
unless (-e("$dm_logs_dir")) {
	mkdir("$dm_logs_dir",0777);
	chmod(0777,"$dm_logs_dir");
	
}  

}




#################
sub hackattempt{
#################
if ($username eq $anonuser) { error("$err{'002'}"); } #### Giving a first warning... yellow card!

}

require "$mods_dir/doorman/admin/dm_config.dat";


##### creating a special folder and files for our victim hahahaha ######
if ($username eq $anonuser){
unless (-e("$dm_hacks_dir")) {
	mkdir("$dm_hacks_dir",0777);
	chmod(0777,"$dm_hacks_dir");
	
}  
unless (-e("$dm_bruteforce_dir")) {
	mkdir("$dm_bruteforce_dir",0777);
	chmod(0777,"$dm_bruteforce_dir");	
}
unless (-e("$dm_bf_hacker_dir")) {
	mkdir("$dm_bf_hacker_dir",0777);
	chmod(0777,"$dm_bf_hacker_dir");	
}
unless (-e("$dm_bf_hack_list_dir")) {
	mkdir("$dm_bf_hack_list_dir",0777);
	chmod(0777,"$dm_bf_hack_list_dir");	
}

unless (-e("$dm_bf_hack_data_table")) { 
	open (FILE, "<$dm_bf_hack_data_template"); 
		lock(FILE);
		chomp (@tab = <FILE>);
		unlock(FILE);
	close (FILE);

	open(FILE, ">$dm_bf_hack_data_table"); 
		lock(FILE);
		foreach $line (@tab) { print FILE "$line"; }  ### Sure no need to use a template
		print FILE "\n";                              ### here but it can't hurt...for
		unlock(FILE);                                 ### for future developments.
	close(FILE);
}
######  COUNTING HACK ATTEMPTS ######
	open(CNT, "<$dm_bf_hack_data_table");
		lock(CNT);
		$hacks = <CNT>;
		unlock(CNT);
	close(CNT);
	$hacks++;
	open(CNT, ">$dm_bf_hack_data_table");
		lock(CNT);
		print CNT "$hacks";
		unlock(CNT);
	close(CNT);

#######   As requested by Ditto.. letting admin deciding nr of allowed floods  #####
open(ACCESSCONF, "$dm_admin_dir/config.dat"); 
	lock(ACCESSCONF); 
	chomp(@config = <ACCESSCONF>); 
	unlock(ACCESSCONF); 
close(ACCESSCONF); 
	if ($config[0] == "" || $config[0] == "0") { $hacksconf = 4; }
	else { $hacksconf = $config[0]; }
#######         End of Ditto fix            ####

require "$sourcedir/stats.pl"; 
parse_log(); 

if ($hacks eq "$hacksconf") { 
  open (MAIL, "|$mailprogram -t");
	print MAIL "To: $compemail\n";  #change this to *your email address!#
	print MAIL "From: $compemail ($username)\n";
	print MAIL "Subject: ***Hack Attempt!***\n\n";
	print MAIL "$realname
	           
	           Username:  $input{'username'}            
	           Attempted password:  $input{'passwrd'}
	           Date:  $date
	           Operating system:  $user_agent 
	           IP:  $ENV{REMOTE_ADDR}
	     
	      is trying to password bruteforce hack in to the site! 
	      Or is either blind or severly senile! Whatever his issue is
	      he is banned now! If you wish to unban him click here:
	      $scripturl/index.cgi?action=admin&op=editbanip\n";
	
	      
	      print MAIL " Your site is at: $scripturl\n\n";
	close (MAIL);

#################### Now lets ban the hacker! yuhooo! :) ##########
    open (FILE , ">>$datadir/banned/banned_ip.txt") || error("$err{'001'} $datadir/banned/banned_ip.txt");
    lock(FILE);
    print FILE "$ENV{REMOTE_ADDR}\n";
    unlock (FILE);
    close (FILE); 
################### DONE! ############	

	}

}

###################
sub deletehacklog{
###################
require "$mods_dir/doorman/admin/dm_config.dat";

if ($username ne $anonuser){
	
  open(ACCESSCONF, "$dm_admin_dir/config.dat"); 
	lock(ACCESSCONF); 
	chomp(@config = <ACCESSCONF>); 
	unlock(ACCESSCONF); 
  close(ACCESSCONF); 
	
}

if ($config[3] eq "no" || $config[3] eq " "){ 
  
	unlink("$dm_bf_hack_data_table");
	rmdir ("$dm_bf_hack_list_dir");
	rmdir ("$dm_bf_hacker_dir");
}

 print qq~Removing Folders and Files...<br>~;
 print qq~$inf{'024'}<br>~;
    
 
}	


###################
sub justarrived{
###################
#### This sub is not in use *yet* if it bothers you, you can delete it :)  ####### 	

open (MAIL, "|$mailprogram -t");
	print MAIL "To: $compemail\n";  #change this to *your email address!#
	print MAIL "From: $compemail($username)\n";
	print MAIL "Subject: ***Just Arrived!***\n\n";
	print MAIL "$realname
	            $username
	            $time
	            $email
	            $date
	            $ENV{REMOTE_ADDR}
	     
	     I have just arrived! shhh...:)\n";
	print MAIL "$scripturl\n\n";
	close (MAIL);

}


################# 
sub reset_floods { 
################# 
require "$mods_dir/doorman/admin/dm_config.dat";
open(ACCESSCONF, "$dm_admin_dir/config.dat"); 
	lock(ACCESSCONF); 
	chomp(@config = <ACCESSCONF>); 
	unlock(ACCESSCONF); 
close(ACCESSCONF); 
	if ($config[4] eq "" || $config[4] eq "no") { 

opendir(DIR,"$dm_fo_floods_dir") || die "Can't open the current directory\n";
@files = grep /\.cnt$/, readdir(DIR); 
closedir DIR; 

foreach $file (@files) { 
unlink ("$dm_fo_floods_dir/$file") or die $!; 
#print qq~</big>Deleted:<br>$file<br></b>~;
} 
}
}
#################
sub floodattempt{
#################
require "$mods_dir/doorman/admin/dm_config.dat";


##### creating a special folder and files for our flooder :) ######


unless (-e("$dm_fo_floods_dir")) {
	mkdir("$dm_fo_floods_dir",0777);
	chmod(0777,"$dm_fo_floods_dir");
}  

unless (-e("$dm_fo_flooder_file")) { 
	open (FILE, "<$dm_forum_flood_template"); 
		lock(FILE);
		chomp (@tab = <FILE>);
		unlock(FILE);
	close (FILE);

	open(FILE, ">$dm_fo_flooder_file"); 
		lock(FILE);
		foreach $line (@tab) { print FILE "$line"; }  ### Sure no need to use a template
		print FILE "\n";                              ### here but it can't hurt...for
		unlock(FILE);                                 ### future developments.
	close(FILE);
}
######  COUNTING FLOOD ATTEMPTS ######
	open(CNT, "<$dm_fo_flooder_file");
		lock(CNT);
		$floods = <CNT>;
		unlock(CNT);
	close(CNT);
	$floods++;
	open(CNT, ">$dm_fo_flooder_file");
		lock(CNT);
		print CNT "$floods";
		unlock(CNT);
	close(CNT);

require "$sourcedir/stats.pl"; #### Checking flooder's OS
parse_log(); 



#######   As requested by Ditto.. letting admin deciding nr of allowed floods  #####
open(ACCESSCONF, "$dm_admin_dir/config.dat"); 
	lock(ACCESSCONF); 
	chomp(@config = <ACCESSCONF>); 
	unlock(ACCESSCONF); 
close(ACCESSCONF); 
	if ($config[1] == "" || $config[1] == "0") { $floodsconf = 4; }
	else { $floodsconf = $config[1]; }
#######   End of Ditto fix ########
    

if ($floods eq "$floodsconf") { 
  open (MAIL, "|$mailprogram -t");
	print MAIL "To: $compemail\n";  #change this to *your email address!#
	print MAIL "From: $compemail\n";
	print MAIL "Subject: ***$username Flood Attempts!***\n\n";
	print MAIL "$realname
	                    
	           Username: $username
	           Flooded Subject:  $input{'subject'}
	           Date:  $date
	           Operating system:  $user_agent 
	           IP:  $ENV{REMOTE_ADDR}
	     
	      $username  is flooding your forum! 
	      Or is either blind or severly senile! Whatever his issue is
	      he is banned now! 
	      
	      If you wish to unban him click here:
	      $scripturl/index.cgi?action=admin&op=editbanip
	      
	      Sharlock, if you got banned yourself! you should clean the 
	      ban file here: $scripturl/db/banned/banned_ip.txt
	
	      Your flooded forum site is at: $scripturl/\index.cgi?action=forum\&board=$currentboard\n\n";
	close (MAIL);
	
	  open (MAIL, "|$mailprogram -t");
	print MAIL "To: $input{'email'}\n";  #change this to *your email address!#
	print MAIL "From: $compemail\n";
	print MAIL "Subject: *** Your Flood Attempts!***\n\n";
	print MAIL "$realname
	           
	           Username:  $input{'username'}            
	           Flooded Subject:  $input{'subject'}
	           Date:  $date
	           Operating system:  $user_agent 
	           IP:  $ENV{REMOTE_ADDR}
	     
	           You have been flooding our forum at our site
	           at: $scripturl/\index.cgi?action=forum\&board=$currentboard
	           You are now being banned for these inappropriate actions.
	           If you need any more information, please contact us at: $compemail\n\n";
	close (MAIL);

#################### Now lets ban the flooder! yuhooo! :) ##########
    open (FILE , ">>$datadir/banned/banned_ip.txt") || error("$err{'001'} $datadir/banned/banned_ip.txt");
    lock(FILE);
    print FILE "$ENV{REMOTE_ADDR}\n";
    unlock (FILE);
    close (FILE); 

################### Ciao baby! telling user what he did wrong, and what to do now :) ############	
error("<hr><br><b>$username</b> Flooding is <b>not allowed</b> at our website! You are now being banned at our website! If you wish to have your ban removed, take contact with us at: <a href=mailto:$compemail>$compemail</a><br><center><br><b> Have a nice day! </b></center><br><hr>"); 
}
	
################### DONE! ############	
}

1; # return true

