----------------------------------------------------------------------------------
Script: Doorman Beta for web-APP (www.web-app.org)
By: On :)  redirect@online.no
Function: a script for dealing with essential security issues for web-app 0.9.9
Date: 20.08.03
Version: no version yet... its only a beta script created on a couple of good 
         Heiniken beers :)
----------------------------------------------------------------------------------

Issues covered up to date:
 

1.) Forum Flood Protection: preventing registered user from flooding the forum. Admin
    can set the maximum allowed posts per min (default is 3 per min). Upon triggering the 
    Protection, user would be notified in the site for being banned, both him and
    the admin would be sent en instant email concerning that. 
    
2.) Bruteforce Hacking Attempts Protection: 
    a common hacking technique for crypt pwd files. The protection is triggered upon
    number of pwd trials targeted at registered user per IP, the number can be changed by
    the admin (default is 4 pwd trails per hour). Site admin would be sent an email with 
    complete log of the "hacking event" including hacker's details. 
    Hacker is banned instantly. 

3.) Records: Doorman lets you keep realtime records in format of a log (emailed to you),
    updating your statslog with a "banned" information, and most important with folders
    and cnt file, these folders and files are an effective legal document (better than
    written logs, as they are time stamped directly by the server and actually can not
    be deleted in many cases... so beware of that!).
        
4.) Other subs in the file: "justarrived", "justleft" and "access1-8" are still under
    developmets, you can delete these subs if they really annoy you..  :)
   
5.) Other techniqual issues: still working on developing a standard Protection ban sub 
    that could easily be adapted to mods and other scripts, however because the script
    is using mainly (if not only!) global expressions it is very easy to simply add a 
    line calling for the protection subs and changing few parameters to have these subs 
    also protecting other web-app scripts and mods (please let me know if you need help 
    with that!).

6.) Future features: as you can see, the script creates several other folders like: logs,
    lang, reset, bans, backup and more (check your cgi-bin/mods/doors/  folder. These are all
    functions that are still under development.
    
-------------
Instructions:
-------------

1.) Upload the entire folder to your mods folder, normally located at cgi-bin/mods/
    So you get this: cgi-bin/mods/doorman
    chmod of both folders to 777
    chmod of doorman.cgi and dm_tools.pl  to 755
    chmod of all dat files to 777 (there should be 3 of them there..I think :)

2.) /cgi-lib/user.pl look for: "sub login2" add just under the title this line: 
    require "$mods_dir/doorman/dm_tools.pl"; ### Doorman Hack Protection
    
    Scroll approx. 20 lines down and look for:
    if ($settings[0] ne $passwrd){ error("$err{'002'}"); } 
    
    replace it with:
    
#############  Doorman Hack Protection  ##############
    if ($settings[0] ne $passwrd) { hackattempt(); }
########################################################    

    Scroll further down at the *same* sub and look for:  
    print_main();
    
    Its hould appear at two spots, add under each one of them this:
    
#############  Doorman Hack Protection  ##############
    deletehacklog();
########################################################  

3.) /cgi-lib/forum_post.pl  look for: "sub post2" add this line just under the title:
    
    require "$mods_dir/doorman/dm_tools.pl"; ### Doorman Flood Protection  
    Scroll to nearly the end of the sub, approx 20 lines before the end and look for:
    
	  if ($input{'followto'} ne "") { $thread = "$followto"; }
	  else { $thread = "$postnum"; }

	  And simply add this line just above it:
	
#############  Doorman Floods Protection  ####################
		floodattempt(); 
##############################################################
 
4.) To make life easy... add a link in your sub member_panel after the link to siteadmin:
    Add this line to theme.pl  file:

#############  Doorman Hack Protection  ######################    
if ($username eq "admin") {
print qq~<tr>
<td class="cat"><img src="$themesurl/$usertheme/images/dot.gif" >
&nbsp;<a href="$scripturl/mods/doorman/doorman.cgi" class="menu">Doorman Admin</a></td>
</tr>
~;
}
##############################################################  
Or simply ...memorize the link to this script :)    

5.) Click on the link to your http://www.yourdomain.com/mods/doorman/doorman.cgi or use
    the new link in your member panel menue And the program will install itself! 
    It would create its own folders and files.
    		
    Change default numbers for triggering events as you wish and reset flood records
    and ban records whenever you feeli like. 
    
    If you have suggestions, complaints... or other security issues inwhich you think 
    need further attention please contact me at either: www.web-app.org (look for On) 
    or send me an email at:redirect@online.no (place at the subject: "web-app-Doorman")
    
    Ops... and before I forget, if you managed to get yourself banned Don't worry...
    There are instructions in the emails you get!