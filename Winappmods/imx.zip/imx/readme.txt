IMX  :  A redesigned IM feature of Web-App with a sent folder and saved folder, a redesigned im posting with now message icons.  This new plugin has an admin option to set a limit on this 3 folders, IM index, Sent Folder and the Saved Folder.  The limit can be seen using a progress bar hacked to make it work by notifying user as well as the admin about their limits.  No actual server configuration or limit is used, its only for notifying.  At less than 10% it gives the user a written notice underneath the limit bar suggesting to delete or move or save old or unwanted ims.  at 0% it sends a notice to the admin, a known bug about this is that it sends it everytime the user visits that folder that is full.  It is up to the admin to delete the user's old messages or to send the user a im suggesting this, the limiting and the notifying will probably help by reminding users to clean up a bit.  

instructions:

Get a hold of your index.cgi file, back it up, after the first elsif statement or after the imindex() statement to keep all IM together create a new line paste this in:

elsif ($action eq "messageadmin") { require "$scriptdir/user-lib/instantmessage.pl"; messageadmin(); }
elsif ($action eq "messageadmin2") { require "$scriptdir/user-lib/instantmessage.pl"; messageadmin2();}
elsif ($action eq "messageadmin3") { require "$scriptdir/user-lib/instantmessage.pl"; messageadmin3();}
elsif ($action eq "messageadmin4") { require "$scriptdir/user-lib/instantmessage.pl"; messageadmin4();}
elsif ($action eq "im2") { require "$scriptdir/user-lib/instantmessage.pl"; imfolder(); }
elsif ($action eq "im3") { require "$scriptdir/user-lib/instantmessage.pl"; imsaved();}
elsif ($action eq "imfolder") { require "$scriptdir/user-lib/instantmessage.pl"; imfolder(); }
elsif ($action eq "saveim") { require "$scriptdir/user-lib/instantmessage.pl"; imsaved(); }
elsif ($action eq "moveim") { require "$scriptdir/user-lib/instantmessage.pl"; moveim(); }
elsif ($action eq "imremove") { require "$sourcedir/instantmessage.pl"; imremove(); }
elsif ($action eq "imremove2") { require "$scriptdir/user-lib/instantmessage.pl"; imremove2(); }
elsif ($action eq "imremove3") { require "$scriptdir/user-lib/instantmessage.pl"; imremove3(); }

save and upload in ascii mode.

Next, 
get a hold of your lang file, paste this tags in:

$imx{'001'} = "My Inbox";
$imx{'002'} = "Storage Limit"; 
$imx{'003'} = "Available"; 
$imx{'004'} = "Max Messages"; 
$imx{'005'} = "Sent";
$imx{'006'} = "Saved"; 
$imx{'007'} = "Close Message"; 
$imx{'008'} = "Sent Messages"; 
$imx{'009'} = "Copy of"; 
$imx{'010'} = "My Saved Messages"; 
$imx{'011'} = "Your Folder is getting full"; 
$imx{'012'} = "If it reaches 0% the admin will be notified and will delete your old message.  To avoid this, delete unwanted and old messages.  Thanks.";
$imx{'013'} = "sent folder is too full"; 
$imx{'014'} = "A New Private Message"; 
$imx{'015'} = "logout"; 
$imx{'016'} = "register"; 
$imx{'017'} = "Message Icon"; 
$imx{'018'} = "Small"; 
$imx{'019'} = "Normal"; 
$imx{'020'} = "Medium"; 
$imx{'021'} = "Large"; 
$imx{'022'} = "Extra Large"; 
$imx{'023'} = "QUOTE";
$imx{'024'} = "Keep a copy of this message in my sent folder?";


upload your lang file in ascii mode.
upload the instantmessage.pl file in your user-lib folder.
in your user-lib folder, backup your sub.pl file, upload if needed or if you already have one in there, paste the following text:
############
sub doubbc {
############

	$message =~ s~\[font=(.+?)\]~<font face="$1">~isg;
     	$message =~ s~\[\/font\]~</font>~isg;

      	$message =~ s~\[size=(.+?)\]~<font size="$1">~isg;
    	$message =~ s~\[\/size\]~</font>~isg; 

	$message =~ s~\[\[~\{\{~g;
	$message =~ s~\]\]~\}\}~g;
	$message =~ s~\n\[~\[~g;
	$message =~ s~\]\n~\]~g;

	$message =~ s~\<br\>~ <br>~g;
	$message =~ s~\<pipe\>~\|~g;
	$message =~ s~\[hr\]\n~<hr size="1">~g;
	$message =~ s~\[hr\]~<hr size="1">~g;

	$message =~ s~\[b\]~<b>~isg;
	$message =~ s~\[\/b\]~</b>~isg;

	$message =~ s~\[i\]~<i>~isg;
	$message =~ s~\[\/i\]~</i>~isg;

	$message =~ s~\[u\]~<u>~isg;
	$message =~ s~\[\/u\]~</u>~isg;
	
	if ($imageicons eq "1") {
		$message =~ s~\[img\](.+?)\[\/img\]~<a href="$1" target="_blank"><img src="$1" width="50" height="50" alt="" border="0"></a>~isg;
		}
	if ($imageicons ne "1") {
		$message =~ s~\[img\](.+?)\[\/img\]~<img src="$1" alt="" border="0">~isg;
		}
	
	$message =~ s~\[color=(\S+?)\]~<font color="$1">~isg;
	$message =~ s~\[\/color\]~</font>~isg;
	
	$message =~ s~\[quote\]<br>(.+?)<br>\[\/quote\]~<blockquote><hr align=left width=40%>$1<hr align=left width=40%></blockquote>~isg;
	$message =~ s~\[quote\](.+?)\[\/quote\]~<blockquote><hr align=left width=40%><b>$1</b><hr align=left width=40%></blockquote>~isg;

	$message =~ s~\[fixed\]~<font face="Courier New">~isg;
	$message =~ s~\[\/fixed\]~</font>~isg;

	$message =~ s~\[sup\]~<sup>~isg;
	$message =~ s~\[\/sup\]~</sup>~isg;
	
	$message =~ s~\[strike\]~<strike>~isg;
	$message =~ s~\[\/strike\]~</strike>~isg;

	$message =~ s~\[sub\]~<sub>~isg;
	$message =~ s~\[\/sub\]~</sub>~isg;

	$message =~ s~\[left\]~<div align="left">~isg;
	$message =~ s~\[\/left\]~</div>~isg;
	$message =~ s~\[center\]~<center>~isg;
	$message =~ s~\[\/center\]~</center>~isg;
	$message =~ s~\[right\]~<div align="right">~isg;
	$message =~ s~\[\/right\]~</div>~isg;

	$message =~ s~\[list\]~<ul>~isg;
	$message =~ s~\[\*\]~<li>~isg;
	$message =~ s~\[\/list\]~</ul>~isg;

	$message =~ s~\[pre\]~<pre>~isg;
	$message =~ s~\[\/pre\]~</pre>~isg;

	$message =~ s~\[code\](.+?)\[\/code\]~<blockquote><font face="Courier New">code:</font><hr align=left width=40%><font face="Courier New"><pre>$1</pre></font><hr align=left width=40%></blockquote>~isg;

	$message =~ s~\[email\](.+?)\[\/email\]~<a href="mailto:$1">$1</a>~isg;

	$message =~ s~\[url\]www\.\s*(.+?)\s*\[/url\]~<a href="http://www.$1" target="_blank">www.$1</a>~isg;
	$message =~ s~\[url=\s*(\w+\://.+?)\](.+?)\s*\[/url\]~<a href="$1" target="_blank">$2</a>~isg;
	$message =~ s~\[url=\s*(.+?)\]\s*(.+?)\s*\[/url\]~<a href="http://$1" target="_blank">$2</a>~isg;
	$message =~ s~\[url\]\s*(.+?)\s*\[/url\]~<a href="$1" target="_blank">$1</a>~isg;

	$message =~ s~([^\w\"\=\[\]]|[\n\b]|\A)\\*(\w+://[\w\~\.\;\:\,\$\-\+\!\*\?/\=\&\@\#\%]+[\w\~\.\;\:\$\-\+\!\*\?/\=\&\@\#\%])~$1<a href="$2" target="_blank">$2</a>~isg;
	$message =~ s~([^\"\=\[\]/\:\.]|[\n\b]|\A)\\*(www\.[\w\~\.\;\:\,\$\-\+\!\*\?/\=\&\@\#\%]+[\w\~\.\;\:\$\-\+\!\*\?/\=\&\@\#\%])~$1<a href="http://$2" target="_blank">$2</a>~isg;

	$message =~ s~\{\{~\[~g;
	$message =~ s~\}\}~\]~g;
}
1;





Next, upload instantmessage.pl file in your user-lib folder.  Only admin can see admin tools.  




