#############
sub messageadmin {
#############


unless (-e("$memberdir/im")) 
{
   mkdir("$memberdir/im",0755);
   chmod(0755,"$memberdir/im");
}
unless (-e("$memberdir/saved")) 
{
   mkdir("$memberdir/saved",0755);
   chmod(0755,"$memberdir/saved");
}
unless (-e("$memberdir/backup")) 
{
   mkdir("$memberdir/backup",0755);
   chmod(0755,"$memberdir/backup");
}

open(FILE, "$memberdir/im/admin.txt"); 
      lock(FILE); 
      @entries = <FILE>; 
      unlock(FILE); 
      close(FILE);    
foreach $curentry (@entries) {
                                    
			$curentry =~ s/[\n\r]//g; ($name1, $value1) = split(/\|/, $curentry);}	
	$navbar = "$btn{'014'} Message Admin";	
	print_top();
	print qq~<table width="100%" border="0" cellspacing="1" cellpadding="3" bgcolor="$titlebg">
  <form action="$pageurl/$cgi?action=messageadmin2" method="post" onSubmit="submitonce(this)"> 

  <tr><td colspan=3 align=center><b>Message Admin</b></td></tr>
<tr><td colspan=3 bgcolor=#FAFAEF><B>Inbox Folder</b></td> </tr> 
<tr bgcolor=#FAFAEF>
<td><b>Max Message</b></td>
<td><input type="text" name="message" size=10 maxlength=3 value="$name">
 <Br>*Recommended no more than 100</td>
<Td><input type="submit" value="Save IM Folder" name="moda"><input type="reset" value="Reset"></td></tr>
 </form> 
<tr><td colspan=3>It is set for $name right now, type in a number to change it.  Or <a href="$cgi?action=im">Leave it like that?</a></td> 

  </tr> 
<tr><td colspan=3><br><br></td> 

  </tr>   <form action="$pageurl/$cgi?action=messageadmin3" method="post" onSubmit="submitonce(this)"> 
<tr><td colspan=3 bgcolor=#FAFAEF><B>Sent Folder</b></td> </tr>
~;
open(FILE, "$memberdir/backup/admin.txt"); 
      lock(FILE); 
      @entries2 = <FILE>; 
      unlock(FILE); 
      close(FILE);    
foreach $curentry (@entries2) {
                                    
			$curentry =~ s/[\n\r]//g; ($backup, $value) = split(/\|/, $curentry);}	
print qq~
 <tr bgcolor=#FAFAEF>
<td><b>Max Message</b></td>
<td><input type="text" name="message" size=10 maxlength=3 value="$backup">
 <Br>*Recommended no more than 100</td>
<Td><input type="submit" value="Save Sent Folder" name="moda"><input type="reset" value="Reset"></td></tr>

<tr><td colspan=3>It is set for $backup right now, type in a number to change it.  Or <a href="$cgi?action=imfolder">Leave it like that?</a></td> 

  </tr> </form> 
<tr><td colspan=3><br><br></td> 

  </tr>   <form action="$pageurl/$cgi?action=messageadmin4" method="post" onSubmit="submitonce(this)"> 
<tr><td colspan=3 bgcolor=#FAFAEF><B>Saved Folder</b></td> </tr> 
~;
open(FILE, "$memberdir/saved/admin.txt"); 
      lock(FILE); 
      @entries3 = <FILE>; 
      unlock(FILE); 
      close(FILE);    
foreach $curentry (@entries3) {
                                    
			$curentry =~ s/[\n\r]//g; ($saved, $value) = split(/\|/, $curentry);}	
print qq~
<tr bgcolor=#FAFAEF>
<td><b>Max Message</b></td>
<td><input type="text" name="message" size=10 maxlength=3 value="$saved">
 <Br>*Recommended no more than 100</td>
<Td><input type="submit" value="Save Saved Folder" name="moda"><input type="reset" value="Reset"></td></tr>

<tr><td colspan=3>It is set for $saved right now, type in a number to change it.  Or <a href="$cgi?action=saveim">Leave it like that?</a></td> 

  </tr> 
<tr><td colspan=3><br><br></td> 

  </tr> 

 </form> 
  </table> 
~;

print_bottom();
}

#############
sub messageadmin2 {
#############
       


	
if ($input{'message'} eq "") {
$navbar ="$btn{'014'} $bud{'020'}"; 
    print_top(); 
print qq~<b>Cannot be empty. </b><br>

    <br><br><p><b><a href="$pageurl/$cgi?action=messageadmin">Message admin</a></b><br>
        
    ~; 
    print_bottom(); 
} else {
	$navbar ="$btn{'014'} Message Admin";
    print_top(); 
    
    open (FILE , ">$memberdir/im/admin.txt"); 
    lock(FILE); 
    print FILE "$input{'message'}"; 
    unlock (FILE); 
    close (FILE); 


	print "You have set $input{'message'} as the max number"; 
    print qq ~ 
    <br><br><p><b><a href="$pageurl/$cgi?action=messageadmin">Message Admin</a></b><br>
        <b><a href="$pageurl/$cgi?action=im">Inbox</a></b>  
    ~; 
    print_bottom(); 
}




}
#############
sub messageadmin3 {
#############
       


	
if ($input{'message'} eq "") {
$navbar ="$btn{'014'} Message Admin"; 
    print_top(); 
print qq~<b>Cannot be empty. </b><br>

    <br><br><p><b><a href="$pageurl/$cgi?action=messageadmin">Message admin</a></b><br>
        
    ~; 
    print_bottom(); 
} else {
	$navbar ="$btn{'014'} Message Admin";
    print_top(); 
    
    open (FILE , ">$memberdir/backup/admin.txt"); 
    lock(FILE); 
    print FILE "$input{'message'}"; 
    unlock (FILE); 
    close (FILE); 


	print "You have set $input{'message'} as the max number"; 
    print qq~ 
    <br><br><p><b><a href="$pageurl/$cgi?action=messageadmin">Message Admin</a></b><br>
        <b><a href="$pageurl/$cgi?action=im">Inbox</a></b>  
    ~; 
    print_bottom(); 
}



}

#############
sub messageadmin4 {
#############
       


	
if ($input{'message'} eq "") {
$navbar ="$btn{'014'} Message Admin"; 
    print_top(); 
print qq~<b>Cannot be empty. </b><br>

    <br><br><p><b><a href="$pageurl/$cgi?action=messageadmin">Message admin</a></b><br>
        
    ~; 
    print_bottom(); 
} else {
	$navbar ="$btn{'014'} Message Admin";
    print_top(); 
    
    open (FILE , ">$memberdir/saved/admin.txt"); 
    lock(FILE); 
    print FILE "$input{'message'}"; 
    unlock (FILE); 
    close (FILE); 


	print "You have set $input{'message'} as the max number"; 
    print qq ~ 
    <br><br><p><b><a href="$pageurl/$cgi?action=messageadmin">Message Admin</a></b><br>
        <b><a href="$pageurl/$cgi?action=im">Inbox</a></b>  
    ~; 
    print_bottom(); 
}




}


#############
sub imindex {
#############
	if ($username eq "$anonuser") { error("noguests"); }

	open(FILE, "$memberdir/$username.msg");
	lock(FILE);
	@imessages = <FILE>;
	unlock(FILE);
	close(FILE);
	$mnum1 = @imessages;

	open(FILE, "$memberdir/membergroups.dat");
	lock(FILE);
	@membergroups = <FILE>;
	unlock(FILE);
	close(FILE);
	
	open(CENSOR, "$boardsdir/censor.txt");
	lock(CENSOR);
	@censored = <CENSOR>;
	unlock(CENSOR);
	close(CENSOR);

	open(FILE, "$memberdir/$username.dat") || error("$err{'010'}"); 
	lock(FILE); 
	chomp(@memsettings = <FILE>); 
	unlock(FILE); 
	close(FILE); 
	open(IM3, "$memberdir/saved/$username.msg"); 
                  lock(IM3); 
                  @immessages3 = <IM3>; 
                  unlock(IM3); 
                  close(IM3); 

                  $mnum3 = @immessages3; 

			open(IM, "$memberdir/backup/$username.msg"); 
                  lock(IM); 
                  @immessages2 = <IM>; 
                  unlock(IM); 
                  close(IM); 

                  $mnum2 = @immessages2; 
                  $messnum = "$mnum2"; 

	$umessageid = $info{"messageid"};
	$navbar = "$btn{'014'} $nav{'028'}";	
	print_top();
	print qq~<table width="100%" border="0" cellspacing="1" cellpadding="3">
<tr>
<td>
~;
if ($umessageid ne "") {
	imview();
} 
print qq~<table cellpadding="0" cellspacing="0" width="100%" border="0">
<tr><td colspan=4 bgcolor=navy><font color=white><B>$imx{'001'}</b> ($mnum1)</font></td></tr>

<tr>
<td width=55%>&nbsp;~;if($username eq "admin"){print qq~<a href="$cgi?action=messageadmin"><img src=$imagesurl/im/admin.gif border=0 alt="Admin Tools"></a>~;}
print qq~
</td>
<td align="right"><a href="$cgi?action=imsend"><img src=$imagesurl/im/icon_reply.gif border=0 alt=$nav{'029'}></a></td>
<td align="right"><a href="$cgi?action=imfolder"><img src=$imagesurl/im/icon_return.gif border=0 alt="$imx{'008'}"></a></td>
<td align="right"><a href="$cgi?action=saveim"><img src=$imagesurl/im/icon_save.gif border=0 alt="$imx{'010'}"></a></td>

	
	</tr>

<tr>
<td width=55%>&nbsp;</td>
<td align="right" valign=top>$nav{'029'}</td>
<td align="right" valign=top>$imx{'005'}<br> ($mnum2)</td>
<td align="right" valign=top>$imx{'006'}<br> ($mnum3)</td>
</tr>
<tr><td colspan=4 bgcolor=#D4D7E8 align=right><a href="$cgi?action=imremove&amp;id=all">$msg{'576'}</a></td></tr>

</table>
	<table width="100%" bgcolor="$titlebg" border="0" cellspacing="1" cellpadding="2"><tr>
<td class="imtitle"><b></b></td>
<td class="imtitle" width="10%"><b>$msg{'182'}</b></td>
<td class="imtitle" width="20%"><b>$msg{'214'}:</b></td>
<td class="imtitle" width="50%"><b>$msg{'037'}</b></td>
<td class="imtitle" width=15%><b>$msg{'208'}:</b></td>

</tr>

~;

	if (@imessages == 0) {
		print qq~<tr>
<td colspan="5" class="imwindow1">$msg{'050'}</td>
</tr>~;
}
	$second = "imwindow2";
	sort {$b[5] <=> $a[5]} @immessages;
	for ($a = 0; $a < @imessages; $a++) {
		if ($second eq "imwindow1") { $second="imwindow2"; }
		else { $second="imwindow1"; }
		
		($musername[$a], $msub[$a], $mdate[$a], $mmessage[$a], $messageid[$a], $micon[$a], $mviewed[$a]) = split(/\|/, $imessages[$a]);
                
                if ($messageid[$a] < 100) { $messageid[$a] = $a; }
		$subject = "$msub[$a]";
		if ($subject eq "") { $subject="---"; }
		
		$mmessage[$a] =~ s/\n//g;
		$mmessage[$a] =~ s/\r//g;
		$message="$mmessage[$a]";
		$name = "$mname[$a]";
		$mail = "$memset[2]";
		$date = "$mdate[$a]";
		$ip = "$mip[$a]";
		$postinfo = "";
		$signature = "";
		$viewd = "";
		$icq = "";
		$star = "";
		$newim = "";
		$imnav = "oldimlink";

if ($mviewed[$a] eq "" && $umessageid ne $messageid[$a]) {
	$newim = qq~<img src="$imagesurl/forum/new.gif" border="0" alt="$msg{'543'}">&nbsp;~; $imnav = "newimlink";
}
elsif ($umessageid eq $messageid[$a]) {
	$second = "imselected";
}

display_date($mdate[$a]); $mdate[$a] = $user_display_date;
$numbers = $a+1;
if ($musername[$a] eq "$anonuser") {
print qq~<td class="$second" align=center><b>
<font color=navy><a href="$cgi?action=im&amp;from=$musername[$a]&amp;messageid=$messageid[$a]" class="$imnav">$numbers</a></font></b></td><td class="$second" width="10%"><b>$msg{'668'}</b></td>~;
} else {print qq~<td class="$second" align=center><b><font color=navy><a href="$cgi?action=im&amp;from=$musername[$a]&amp;messageid=$messageid[$a]" class="$imnav">$numbers</a></font></b></td><td class="$second" width="10%"> <a href="$cgi?action=imsend&to=$musername[$a]" class="$imnav">$musername[$a]</a></td>~;
}

print qq~<td class="$second" width="20%" nowrap>$mdate[$a]</td>
<td class="$second" width="50%"><a href="$cgi?action=im&amp;from=$musername[$a]&amp;messageid=$messageid[$a]" class="$imnav">$newim$msub[$a]</td>~;

if ($musername[$a] eq "$anonuser") {
print qq~<td class="$second">
<center><a href="$cgi?action=imremove&id=$messageid[$a]"><img src="$imagesurl/forum/delete.gif" alt="$msg{'058'}" border="0"></a></center></td>~;
} else {

print qq~<td class="$second" width="10%"><center>

<a href="$cgi?action=imsend&to=$musername[$a]&num=$messageid[$a]"><img src="$imagesurl/forum/replymsg.gif" alt="$msg{'057'}" border="0"></a>
&nbsp;&nbsp;
~;

print qq~

<a href="$cgi?action=imremove&id=$messageid[$a]"><img src="$imagesurl/forum/delete.gif" alt="$msg{'058'}" border="0"></a></center></td>~;
}
print qq~</tr>~;	
}

print qq~</table>
<p align=left>
<table width=200><tr><td><B>$imx{'002'}</B></td></tr>
<tr><Td>
~;
open(FILE, "$memberdir/im/admin.txt"); 
      lock(FILE); 
      @entries = <FILE>; 
      unlock(FILE); 
      close(FILE);    
foreach $curentry (@entries) {
                                    
			$curentry =~ s/[\n\r]//g; ($mymess, $value) = split(/\|/, $curentry);}
if ($mymess eq ""){$messages = "25";}else{
$messages = "$mymess";}
$averagescore = "$mnum1"; 
							
$multiply = ((100/$messages));

if ($averagescore > 0) {       
$usando = ($messages-$averagescore)*$multiply;
$actual =$averagescore*$multiply;	
$greycells = "$usando-$averagescore*$multiply";      
	
								
										print qq~
										0&nbsp;<img src="$imagesurl/rategreen.gif" height="8" width="$actual" border="0" alt="$actual%"><img src="$imagesurl/rategrey.gif" height="8" width="$greycells" border="0" alt="">&nbsp;100
										~; 
										}
										
										else{       
$usando = "100";										print qq~
										0&nbsp;<img src="$imagesurl/rategrey.gif" height="8" width="100" border="0" alt="">&nbsp;100
										~; 
}
if ($usando < "11"){$usando2 = qq~<font color=red>$imx{'011'}</font><br> $imx{'012'}~;}else{$usando2 = qq~ &nbsp; ~;}
if ($usando eq "0"){

	$username  = $username;
      $msgid = time;
      $imsubj = "IM Administration on $username";
      $formatmsg = qq~$username's $imx{'013'}.~;	

      open (FILE, "$memberdir/admin.msg");
	lock(FILE);
	@imessages = <FILE>;
	unlock(FILE);
	close (FILE);
	open (FILE, ">$memberdir/admin.msg");
	lock(FILE);
	print FILE "$username|$imsubj|$date|$formatmsg|$msgid\n";
	foreach $curm (@imessages) { print FILE "$curm"; }
	unlock(FILE);
	close(FILE);
}


print qq~</td></tr>

<tr><td></td></tr>
<tr><td>$imx{'003'} = <b>$usando\% </b> <br>$imx{'004'} = <B>$messages </b><br>$usando2 </td></tr>
</table>~;

print qq~</p>
<table cellpadding="0" cellspacing="0" width="100%" border="0">

<tr><td colspan=4 bgcolor=navy><font color=white><B>$imx{'001'}</b> ($mnum1)</font></td></tr>

<tr>
<td width=55%>&nbsp;</td>
<td align="right"><a href="$cgi?action=imsend"><img src=$imagesurl/im/icon_reply.gif border=0 alt=$nav{'029'}></a></td>
<td align="right"><a href="$cgi?action=imfolder"><img src=$imagesurl/im/icon_return.gif border=0 alt="$imx{'008'}"></a></td>
<td align="right"><a href="$cgi?action=saveim"><img src=$imagesurl/im/icon_save.gif border=0 alt="$imx{'010'}"></a></td>

	
	</tr>

<tr>
<td width=55%>&nbsp;</td>
<td align="right" valign=top>$nav{'029'}</td>
<td align="right" valign=top>$imx{'005'}<br> ($mnum2)</td>
<td align="right" valign=top>$imx{'006'}<br> ($mnum3)</td>
</tr>
<tr><td colspan=4 bgcolor=#D4D7E8>&nbsp;</td></tr>
</table><br>~;

if ($username eq "admin") {
print qq~<table width="100%" bgcolor="$titlebg" border="0" cellspacing="1" cellpadding="2"><tr>
<td colspan="4" class="imtitle"><b>$msg{'561'}</b></td>
<tr>
<td colspan="4" class="imwindow1"><a href="$cgi?action=siteim">$msg{'562'}</a><br>
<a href="$cgi?action=adminim">$msg{'595'}</a><br>
<a href="$cgi?action=modim">$msg{'594'}</a></td>
</tr>
</table>~;
}

if ($username ne "admin" && $settings[7] eq "$root") {
print qq~<table width="100%" bgcolor="$titlebg" border="0" cellspacing="1" cellpadding="2"><tr>
<td colspan="4" class="imtitle"><b>$msg{'561'}</b></td>
<tr>
<td colspan="4" class="imwindow1"><a href="$cgi?action=adminim">$msg{'595'}</a><br>
<a href="$cgi?action=modim">$msg{'594'}</a></td>
</tr>
</table>~;
}

if ($username ne "admin" && $settings[7] eq "$boardmoderator") {
print qq~<table width="100%" bgcolor="$titlebg" border="0" cellspacing="1" cellpadding="2"><tr>
<td colspan="4" class="imtitle"><b>$msg{'596'}</b></td>
<tr>
<td colspan="4" class="imwindow1"><a href="$cgi?action=modim">$msg{'594'}</a></td>
</tr>
</table>~;
}



print qq~<br>~;

print_bottom();
}

#############
sub imfolder {
#############

{
unless (-e("$memberdir/backup")) 
{
   mkdir("$memberdir/backup",0777);
   chmod(0777,"$memberdir/backup");
}
	if ($username eq "$anonuser") { error("noguests"); }
	open(IM, "$memberdir/$username.msg"); 
                  lock(IM); 
                  @buzonmessages = <IM>; 
                  unlock(IM); 
                  close(IM); 

                  $mnum2 = @buzonmessages; 
                 

	open(IM2, "$memberdir/backup/$username.msg"); 
                  lock(IM2); 
                  @imessages = <IM2>; 
                  unlock(IM2); 
                  close(IM2); 
                  $mnum1 = @imessages; 
	open(IM3, "$memberdir/saved/$username.msg"); 
                  lock(IM3); 
                  @immessages3 = <IM3>; 
                  unlock(IM3); 
                  close(IM3); 

                  $mnum3 = @immessages3;
                  

	open(FILE, "$memberdir/membergroups.dat");
	lock(FILE);
	@membergroups = <FILE>;
	unlock(FILE);
	close(FILE);
	
	open(CENSOR, "$boardsdir/censor.txt");
	lock(CENSOR);
	@censored = <CENSOR>;
	unlock(CENSOR);
	close(CENSOR);

	open(FILE, "$memberdir/$username.dat") || error("$err{'010'}"); 
	lock(FILE); 
	chomp(@memsettings = <FILE>); 
	unlock(FILE); 
	close(FILE); 
	

	$umessageid = $info{"messageid"};
	$navbar = "$btn{'014'} $imx{'008'}";	
	print_top();
	print qq~<table width="100%" border="0" cellspacing="1" cellpadding="3">
<tr>
<td>
~;
if ($umessageid ne "") {
	imview2();
} 
print qq~<table cellpadding="0" cellspacing="0" width="100%" border="0">
<tr><td colspan=4 bgcolor=navy><font color=white><B>$imx{'008'}</b> ($mnum1)</font></td></tr>

<tr>
<td width=55%>&nbsp;</td>
<td align="center"><a href="$cgi?action=imsend"><img src=$imagesurl/im/icon_reply.gif border=0 alt=$nav{'029'}></a></td>
<td align="center"><a href="$cgi?action=im"><img src=$imagesurl/im/message.gif border=0 alt="$imx{'001'}"></a></td>
<td align="center"><a href="$cgi?action=saveim"><img src=$imagesurl/im/icon_save.gif border=0 alt="$imx{'010'}"></a></td>

	
	</tr>

<tr>
<td width=55%>&nbsp;</td>
<td align="center" valign=top>$nav{'029'}</td>
<td align="center" valign=top>$imx{'001'}<br> ($mnum2)</td>
<td align="center" valign=top>$imx{'006'}<br> ($mnum3)</td>
</tr>
<tr><td colspan=4 bgcolor=#D4D7E8 align=right><a href="$cgi?action=imremove2&amp;id=all">$msg{'576'}</a></td></tr>

</table>
	<table width="100%" bgcolor="$titlebg" border="0" cellspacing="1" cellpadding="2"><tr>
<td class="imtitle"><b></b></td>
<td class="imtitle" width="10%"><b>$msg{'320'}:</b></td>
<td class="imtitle" width="20%"><b>$msg{'214'}:</b></td>
<td class="imtitle" width="60%"><b>$msg{'037'}</b></td>
<td class="imtitle" width="10%"><b>$msg{'208'}:</b></td>
</tr>
~;

	if (@imessages == 0) {
		print qq~<tr>
<td colspan="5" class="imwindow1">$msg{'050'}</td>
</tr>~;
}
	$second = "imwindow2";
	sort {$b[5] <=> $a[5]} @immessages;
	for ($a = 0; $a < @imessages; $a++) {
		if ($second eq "imwindow1") { $second="imwindow2"; }
		else { $second="imwindow1"; }
		
		($musername[$a], $msub[$a], $mdate[$a], $mmessage[$a], $messageid[$a], $recipient, $micon[$a], $mviewed[$a]) = split(/\|/, $imessages[$a]);
                
                if ($messageid[$a] < 100) { $messageid[$a] = $a; }
		$subject = "$msub[$a]";
		if ($subject eq "") { $subject="---"; }
		
		$mmessage[$a] =~ s/\n//g;
		$mmessage[$a] =~ s/\r//g;
		$message="$mmessage[$a]";
		$name = "$mname[$a]";
		$mail = "$memset[2]";
		$date = "$mdate[$a]";
		$ip = "$mip[$a]";
		$postinfo = "";
		$signature = "";
		$viewd = "";
		$icq = "";
		$star = "";
		$newim = "";
		$imnav = "oldimlink";

if ($mviewed[$a] eq "" && $umessageid ne $messageid[$a]) {
	$newim = qq~<img src="$imagesurl/forum/new.gif" border="0" alt="$msg{'543'}">&nbsp;~; $imnav = "newimlink";
}
elsif ($umessageid eq $messageid[$a]) {
	$second = "imselected";
}

display_date($mdate[$a]); $mdate[$a] = $user_display_date;
$numbers=$a+1;
if ($musername[$a] eq "$anonuser") {
print qq~<td class="$second" align=center><b><font color=navy>$numbers</font></b></td><td class="$second" width="10%"><b>$msg{'668'}</b></td>~;
} else {print qq~<td class="$second" align=center><b><font color=navy>$numbers</font></b></td><td class="$second" width="10%"><a href="$cgi?action=imsend&to=$recipient" class="$imnav">$recipient</a></td>~;
}

print qq~<td class="$second" width="20%" nowrap>$mdate[$a]</td>
<td class="$second" width="60%"><a href="$cgi?action=im2&amp;to=$recipient&amp;messageid=$messageid[$a]" class="$imnav">$msub[$a]</td>~;

if ($musername[$a] eq "$anonuser") {
print qq~<td class="$second" width="10%"><center><a href="$cgi?action=imremove2&id=$messageid[$a]"><img src="$imagesurl/forum/delete.gif" alt="$msg{'058'}" border="0"></a></center></td>~;
} else {print qq~<td class="$second" width="10%"><center><a href="$cgi?action=imsend&to=$musername[$a]&num=$messageid[$a]"><img src="$imagesurl/forum/replymsg.gif" alt="$msg{'057'}" border="0"></a>&nbsp;&nbsp;<a href="$cgi?action=imremove2&id=$messageid[$a]"><img src="$imagesurl/forum/delete.gif" alt="$msg{'058'}" border="0"></a></center></td>~;
}
print qq~</tr>~;	
}

print qq~</table>
<p align=left>
<table width=200><tr><td><B>$imx{'002'}</B></td></tr>
<tr><Td>
~;

open(FILE, "$memberdir/backup/admin.txt"); 
      lock(FILE); 
      @entries = <FILE>; 
      unlock(FILE); 
      close(FILE);    
foreach $curentry (@entries) {
                                    
			$curentry =~ s/[\n\r]//g; ($mymess, $value) = split(/\|/, $curentry);}
if ($mymess eq ""){$messages = "25";}else{
$messages = "$mymess";}
$averagescore = "$mnum1"; 
							

$multiply = ((100/$messages));

if ($averagescore > 0) {       
$usando = ($messages-$averagescore)*$multiply;
$actual =$averagescore*$multiply;	
$greycells = "$usando-$averagescore*$multiply";     	
								
										print qq~
										0&nbsp;<img src="$imagesurl/rategreen.gif" height="8" width="$actual" border="0" alt="$actual%"><img src="$imagesurl/rategrey.gif" height="8" width="$greycells" border="0" alt="">&nbsp;100
										~; 
										}
										
										else{       
$usando = "100";										print qq~
										0&nbsp;<img src="$imagesurl/rategrey.gif" height="8" width="100" border="0" alt="">&nbsp;100
										~; 
}
if ($usando < "11"){$usando2 = qq~<font color=red>$imx{'011'}</font><br>$imx{'012'}~;}else{$usando2 = qq~ &nbsp; ~;}
if ($usando < 0){

	$username  = $username;
      $msgid = time;
      $imsubj = "IM Administration on $username";
      $formatmsg = qq~$username's $imx{'013'}.~;	

      open (FILE, "$memberdir/admin.msg");
	lock(FILE);
	@imessages = <FILE>;
	unlock(FILE);
	close (FILE);
	open (FILE, ">$memberdir/admin.msg");
	lock(FILE);
	print FILE "$username|$imsubj|$date|$formatmsg|$msgid\n";
	foreach $curm (@imessages) { print FILE "$curm"; }
	unlock(FILE);
	close(FILE);
}




print qq~</td></tr>

<tr><td></td></tr>
<tr><td>$imx{'003'} = <b>$usando\% </b> <br>$imx{'004'} = <B>$messages </b><br>$usando2 </td></tr>
</table>~;

print qq~</p>
<table cellpadding="3" cellspacing="3" width="100%" border="0">
<tr><td colspan=4 bgcolor=navy><font color=white><B>Mensajes $imx{'005'}</b> ($mnum1)</font></td></tr>

<tr>
<td width=55%>&nbsp;</td>
<td align="center"><a href="$cgi?action=imsend"><img src=$imagesurl/im/icon_reply.gif border=0 alt=$nav{'029'}></a></td>
<td align="center"><a href="$cgi?action=im"><img src=$imagesurl/im/message.gif border=0 alt="$imx{'001'}"></a></td>
<td align="center"><a href="$cgi?action=saveim"><img src=$imagesurl/im/icon_save.gif border=0 alt="$imx{'010'}"></a></td>
</tr>

<tr>
<td width=55%>&nbsp;</td>
<td align="center" valign=top>$nav{'029'}</td>
<td align="center" valign=top>$imx{'001'}<br> ($mnum2)</td>
<td align="center" valign=top>$imx{'006'}<br> ($mnum3)</td>
</tr>
<tr><td colspan=4 bgcolor=#D4D7E8>&nbsp;</td></tr>
</table><br>~;

if ($username eq "admin") {
print qq~<table width="100%" bgcolor="$titlebg" border="0" cellspacing="1" cellpadding="2"><tr>
<td colspan="4" class="imtitle"><b>$msg{'561'}</b></td>
<tr>
<td colspan="4" class="imwindow1"><a href="$cgi?action=siteim">$msg{'562'}</a><br>
<a href="$cgi?action=adminim">$msg{'595'}</a><br>
<a href="$cgi?action=modim">$msg{'594'}</a></td>
</tr>
</table>~;
}


if ($username ne "admin" && $settings[7] eq "$root") {
print qq~<table width="100%" bgcolor="$titlebg" border="0" cellspacing="1" cellpadding="2"><tr>
<td colspan="4" class="imtitle"><b>$msg{'561'}</b></td>
<tr>
<td colspan="4" class="imwindow1"><a href="$cgi?action=adminim">$msg{'595'}</a><br>
<a href="$cgi?action=modim">$msg{'594'}</a></td>
</tr>
</table>~;
}

if ($username ne "admin" && $settings[7] eq "$boardmoderator") {
print qq~<table width="100%" bgcolor="$titlebg" border="0" cellspacing="1" cellpadding="2"><tr>
<td colspan="4" class="imtitle"><b>$msg{'596'}</b></td>
<tr>
<td colspan="4" class="imwindow1"><a href="$cgi?action=modim">$msg{'594'}</a></td>
</tr>
</table>~;
}



print qq~<br>~;

print_bottom();
}


#############
sub imsaved {
#############

{
unless (-e("$memberdir/saved")) 
{
   mkdir("$memberdir/saved",0755);
   chmod(0755,"$memberdir/saved");
}
	if ($username eq "$anonuser") { error("noguests"); }
	open(IM3, "$memberdir/$username.msg"); 
                  lock(IM3); 
                  @buzonmessages = <IM3>; 
                  unlock(IM3); 
                  close(IM3); 

                  $mnum2 = @buzonmessages; 

    	open(IM, "$memberdir/backup/$username.msg"); 
                  lock(IM); 
                  @foldermessages = <IM>; 
                  unlock(IM); 
                  close(IM); 

                  $mnum3 = @foldermessages; 
       

	open(IM2, "$memberdir/saved/$username.msg"); 
                  lock(IM2); 
                  @imessages = <IM2>; 
                  unlock(IM2); 
                  close(IM2); 
                  $mnum1 = @imessages; 
                  

	open(FILE, "$memberdir/membergroups.dat");
	lock(FILE);
	@membergroups = <FILE>;
	unlock(FILE);
	close(FILE);
	
	open(CENSOR, "$boardsdir/censor.txt");
	lock(CENSOR);
	@censored = <CENSOR>;
	unlock(CENSOR);
	close(CENSOR);

	open(FILE, "$memberdir/$username.dat") || error("$err{'010'}"); 
	lock(FILE); 
	chomp(@memsettings = <FILE>); 
	unlock(FILE); 
	close(FILE); 
	

	$umessageid = $info{"messageid"};
	$navbar = "$btn{'014'} $imx{'010'}";	
	print_top();
	print qq~<table width="100%" border="0" cellspacing="1" cellpadding="3">
<tr>
<td>
~;
if ($umessageid ne "") {
	imview3();
} 
print qq~<table cellpadding="0" cellspacing="0" width="100%" border="0">
<tr><td colspan=4 bgcolor=navy><font color=white><B>$imx{'010'}</b> ($mnum1)</font></td></tr>

<tr>
<td width=55%>&nbsp;</td>
<td align="right"><a href="$cgi?action=imsend"><img src=$imagesurl/im/icon_reply.gif border=0 alt=$nav{'029'}></a></td>
<td align="right"><a href="$cgi?action=imfolder"><img src=$imagesurl/im/icon_return.gif border=0 alt="$imx{'008'}"></a></td>
<td align="right"><a href="$cgi?action=im"><img src=$imagesurl/im/message.gif border=0 alt="$imx{'001'}"></a></td>

	
	</tr>

<tr>
<td width=55%>&nbsp;</td>
<td align="right" valign=top>$nav{'029'}</td>
<td align="right" valign=top>$imx{'005'}<br> ($mnum3)</td>
<td align="right" valign=top>$imx{'001'}<br> ($mnum2)</td>
</tr>
<tr><td colspan=4 bgcolor=#D4D7E8 align=right><a href="$cgi?action=imremove3&amp;id=all">$msg{'576'}</a></td></tr>

</table>
	<table width="100%" bgcolor="$titlebg" border="0" cellspacing="1" cellpadding="2"><tr>
<td class="imtitle"><b></b></td>
<td class="imtitle" width="10%"><b>$msg{'182'}</b></td>
<td class="imtitle" width="20%"><b>Guardado:</b></td>
<td class="imtitle" width="60%"><b>$msg{'037'}</b></td>
<td class="imtitle" width="10%"><b>$msg{'208'}:</b></td>

</tr>
~;

	if (@imessages == 0) {
		print qq~<tr>
<td colspan="5" class="imwindow1">$msg{'050'}</td>
</tr>~;
}
	$second = "imwindow2";
	sort {$b[5] <=> $a[5]} @immessages;
	for ($a = 0; $a < @imessages; $a++) {
		if ($second eq "imwindow1") { $second="imwindow2"; }
		else { $second="imwindow1"; }
		
		($musername[$a], $msub[$a], $mdate[$a], $mmessage[$a], $messageid[$a], $micon[$a], $mviewed[$a]) = split(/\|/, $imessages[$a]);
                




                if ($messageid[$a] < 100) { $messageid[$a] = $a; }
		$subject = "$msub[$a]";
		if ($subject eq "") { $subject="---"; }
		
		$mmessage[$a] =~ s/\n//g;
		$mmessage[$a] =~ s/\r//g;
		$message="$mmessage[$a]";
		$name = "$mname[$a]";
		$mail = "$memset[2]";
		$date = "$mdate[$a]";
		$ip = "$mip[$a]";
		$postinfo = "";
		$signature = "";
		$viewd = "";
		$icq = "";
		$star = "";
		$newim = "";
		$imnav = "oldimlink";

if ($mviewed[$a] eq "" && $umessageid ne $messageid[$a]) {
	$newim = qq~<img src="$imagesurl/forum/new.gif" border="0" alt="$msg{'543'}">&nbsp;~; $imnav = "newimlink";
}
elsif ($umessageid eq $messageid[$a]) {
	$second = "imselected";
}

display_date($mdate[$a]); $mdate[$a] = $user_display_date;
$numbers = $a+1;
if ($musername[$a] eq "$anonuser") {
print qq~<td class="$second" align=center><b><font color=navy><a href="$cgi?action=im3&amp;from=$musername[$a]&amp;messageid=$messageid[$a]" class="$imnav">$numbers</a></font></b></td><td class="$second" width="10%"><b>$msg{'668'}</b></td>~;
} else {print qq~<td class="$second" align=center><b><font color=navy><a href="$cgi?action=im3&amp;from=$musername[$a]&amp;messageid=$messageid[$a]" class="$imnav">$numbers</a></font></b></td><td class="$second" width="10%"> <a href="$cgi?action=imsend&to=$musername[$a]" class="$imnav">$musername[$a]</a></td>~;
}

print qq~<td class="$second" width="20%" nowrap>$mdate[$a]</td>
<td class="$second" width="60%"><a href="$cgi?action=im3&amp;from=$musername[$a]&amp;messageid=$messageid[$a]" class="$imnav">$msub[$a]</td>~;

if ($musername[$a] eq "$anonuser") {
print qq~<td class="$second" width="10%"><center><a href="$cgi?action=imremove3&id=$messageid[$a]"><img src="$imagesurl/forum/delete.gif" alt="$msg{'058'}" border="0"></a></center></td>~;
} else {print qq~<td class="$second" width="10%"><center><a href="$cgi?action=imsend&to=$musername[$a]&num=$messageid[$a]"><img src="$imagesurl/forum/replymsg.gif" alt="$msg{'057'}" border="0"></a>&nbsp;&nbsp;

<a href="$cgi?action=imremove&id=$messageid[$a]"><img src="$imagesurl/forum/delete.gif" alt="$msg{'058'}" border="0"></a></center></td>~;
}
print qq~</tr>~;	
}

print qq~</table>

<p align=left>
<table width=200><tr><td><B>$imx{'002'}</B></td></tr>
<tr><Td>
~;

open(FILE, "$memberdir/saved/admin.txt"); 
      lock(FILE); 
      @entries = <FILE>; 
      unlock(FILE); 
      close(FILE);    
foreach $curentry (@entries) {
                                    
			$curentry =~ s/[\n\r]//g; ($mymess, $value) = split(/\|/, $curentry);}
if ($mymess eq ""){$messages = "25";}else{
$messages = "$mymess";}
$averagescore = "$mnum1"; 
							

$multiply = ((100/$messages));

if ($averagescore > 0) {       
$usando = ($messages-$averagescore)*$multiply;
$actual =$averagescore*$multiply;	
$greycells = "$usando-$averagescore*$multiply";     	
								
										print qq~
										0&nbsp;<img src="$imagesurl/rategreen.gif" height="8" width="$actual" border="0" alt="$actual%"><img src="$imagesurl/rategrey.gif" height="8" width="$greycells" border="0" alt="">&nbsp;100
										~; 
										}
										
										else{       
$usando = "100";										print qq~
										0&nbsp;<img src="$imagesurl/rategrey.gif" height="8" width="100" border="0" alt="">&nbsp;100
										~; 
}
if ($usando < "11"){$usando2 = qq~<font color=red>$imx{'011'}</font><br>$imx{'012'}~;}else{$usando2 = qq~ &nbsp; ~;}
if ($usando < 0){

	$username  = $username;
      $msgid = time;
      $imsubj = "IM Administration on $username";
      $formatmsg = qq~$username's $imx{'013'}.~;	

      open (FILE, "$memberdir/admin.msg");
	lock(FILE);
	@imessages = <FILE>;
	unlock(FILE);
	close (FILE);
	open (FILE, ">$memberdir/admin.msg");
	lock(FILE);
	print FILE "$username|$imsubj|$date|$formatmsg|$msgid\n";
	foreach $curm (@imessages) { print FILE "$curm"; }
	unlock(FILE);
	close(FILE);
}




print qq~</td></tr>

<tr><td></td></tr>
<tr><td>$imx{'003'} = <b>$usando\% </b> <br>$imx{'004'} = <B>$messages </b><br>$usando2 </td></tr>
</table>~;

print qq~</p>
<br><Br>
<table cellpadding="0" cellspacing="0" width="100%" border="0">
<tr><td colspan=4 bgcolor=navy><font color=white><B>$imx{'010'}</b> ($mnum1)</font></td></tr>

<tr>
<td width=55%>&nbsp;</td>
<td align="right"><a href="$cgi?action=imsend"><img src=$imagesurl/im/icon_reply.gif border=0 alt=$nav{'029'}></a></td>
<td align="right"><a href="$cgi?action=imfolder"><img src=$imagesurl/im/icon_return.gif border=0 alt="$imx{'008'}"></a></td>
<td align="right"><a href="$cgi?action=im"><img src=$imagesurl/im/message.gif border=0 alt="$imx{'001'}"></a></td>

	
	</tr>

<tr>
<td width=55%>&nbsp;</td>
<td align="right" valign=top>$nav{'029'}</td>
<td align="right" valign=top>$imx{'005'}<br> ($mnum3)</td>
<td align="right" valign=top>$imx{'001'}<br> ($mnum2)</td>
</tr>
<tr><td colspan=4 bgcolor=#D4D7E8>&nbsp;</td></tr>

</table>
<br>~;

if ($username eq "admin") {
print qq~<table width="100%" bgcolor="$titlebg" border="0" cellspacing="1" cellpadding="2"><tr>
<td colspan="4" class="imtitle"><b>$msg{'561'}</b></td>
<tr>
<td colspan="4" class="imwindow1"><a href="$cgi?action=siteim">$msg{'562'}</a><br>
<a href="$cgi?action=adminim">$msg{'595'}</a><br>
<a href="$cgi?action=modim">$msg{'594'}</a></td>
</tr>
</table>~;
}


if ($username ne "admin" && $settings[7] eq "$root") {
print qq~<table width="100%" bgcolor="$titlebg" border="0" cellspacing="1" cellpadding="2"><tr>
<td colspan="4" class="imtitle"><b>$msg{'561'}</b></td>
<tr>
<td colspan="4" class="imwindow1"><a href="$cgi?action=adminim">$msg{'595'}</a><br>
<a href="$cgi?action=modim">$msg{'594'}</a></td>
</tr>
</table>~;
}

if ($username ne "admin" && $settings[7] eq "$boardmoderator") {
print qq~<table width="100%" bgcolor="$titlebg" border="0" cellspacing="1" cellpadding="2"><tr>
<td colspan="4" class="imtitle"><b>$msg{'596'}</b></td>
<tr>
<td colspan="4" class="imwindow1"><a href="$cgi?action=modim">$msg{'594'}</a></td>
</tr>
</table>~;
}



print qq~<br>~;

print_bottom();
}


############### 
sub moveim { 
############### 

{
unless (-e("$memberdir/saved")) 
{
   mkdir("$memberdir/saved",0755);
   chmod(0755,"$memberdir/saved");
}      

if ($info{'msg'} ne "") { 
           $form_message = $info{'msg'}; 
     } 


	if ($info{'save'} == 1) {
			$form_message =~ s/\[quote\](\S+?)\[\/quote\]//isg;
			$form_message =~ s/\[(\S+?)\]//isg;
			$mmessage = showhtml($info{'msg'});
			$form_message = "$mmessage";
	$from = $info{'from'};         
	$mdate = $date;
    	$messageid = $info{'id'};
	$subject = $info{'subj'};
	$icon = $info{'icon'};



     

	open (FILE, "$memberdir/saved/$username.msg");
	lock(FILE);
	@imessages = <FILE>;
	unlock(FILE);
	close(FILE);

	
	open (FILE2, ">$memberdir/saved/$username.msg");
	lock(FILE2);
	print FILE2 "$from|$subject|$mdate|$form_message|$messageid|$icon\n";
	foreach $curm (@imessages) { print FILE2 "$curm"; }
	unlock(FILE2);
	close(FILE2);}

	
	open(FILE, "$memberdir/$username.msg");
	lock(FILE);
	@imessages = <FILE>;
	unlock(FILE);
	close(FILE);

	open(FILE, ">$memberdir/$username.msg");
	lock(FILE);
	for ($a = 0; $a < @imessages; $a++) {
		($musername, $msub, $mdate, $mmessage, $messageid) = split(/\|/, $imessages[$a]);
		if ($messageid < 100 ) {
			if($a ne $info{'id'}) { print FILE "$imessages[$a]"; }
		}
		else {
			if(!($messageid =~ /$info{'id'}/)) { print FILE "$imessages[$a]"; }
		}
	}
	unlock(FILE);
	close(FILE);


      $navbar = "$btn{'014'} Message of $musername";
	print_top();
	print qq~Message to $musername has been saved.  Return to <a href="$pageurl/$cgi?action=im">Instant Messages</a>.~;
	exit;
	print_bottom();

}

}
}

#############
sub imview {
#############	
  if ($username eq "$anonuser") { error("noguests"); }
	if ($info{'from'} =~ /(\$+|\|+|\(+|\)+|\[+|\]+|\{+|\}+|\^+|\*+|\.+|\<)/) { print_top();  print "What are you doing Stan?"; print_bottom(); exit; }
	
	$to = $info{"from"};

	open(FILE, "$memberdir/$to.dat");
	lock(FILE);
	@memset = <FILE>;
	unlock(FILE);
	close(FILE);

		open(FILE, ">$memberdir/$username.msg");
		lock(FILE);
		foreach $msg (@imessages) {
		chomp $msg;
		($t, $t, $t, $t, $messageid1, $t) = split(/\|/, $msg);
		if ($umessageid == $messageid1) {
			($musername, $msub, $mdate, $mmessage, $messageid, $micon, $mviewed) = split(/\|/, $msg);
			$subject = $msub; $message = $mmessage;
			print FILE "$msg|1\n";
		}
		else {
			print FILE "$msg\n" ;
		}
	}
	unlock(FILE);
	close(FILE);
	
	
		$ranking = $memset[6]+$memset[11]+$memset[12];
		
		$postinfo = qq~<small>$msg{'021'} $memset[6]<br>
$msg{'022'} $memset[11]<br>
$msg{'023'} $memset[12]</small><br>
~;
		$viewd = qq~&nbsp;&nbsp;<a href="$cgi\?action=viewprofile&username=$musername"><img src="$imagesurl/forum/profile.gif" alt="$msg{'051'} $musername" border="0"></a>~;
			$memberinfo = "$membergroups[2]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		if ($ranking > 25) {
			$memberinfo = "$membergroups[3]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		}
		if ($ranking > 50) {
			$memberinfo = "$membergroups[4]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		}
		if ($ranking > 75) {
			$memberinfo = "$membergroups[5]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		}
		if ($ranking > 100) {
			$memberinfo = "$membergroups[6]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		}
		if ($ranking > 250) {
			$memberinfo = "$membergroups[7]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		}
		if ($ranking > 500) {
			$memberinfo = "$membergroups[8]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		}
		if ($boardmoderator eq "$musername") { $memberinfo = "$membergroups[1]"; }
		if ($memset[7] ne "\n") { $memberinfo = "$memset[7]"; }
		if ($memberinfo eq "$root") { $memberinfo = "$membergroups[0]"; }
		$signature = "$memset[5]";
		$signature =~ s/\&\&/<br>/g;
		$signature = qq~<br><br><br>
-----------------<br>
$signature
~;
		$memset[8] =~ s/\n//g;
		$memset[8] =~ s/\r//g;
		if ($memset[8] ne "") {
	                if (!($memset[8] =~ /\D/)) { 
				$icq = qq~&nbsp;&nbsp;<a href="http://www.icq.com/$memset[8]" target="_blank"><img src="http://wwp.icq.com/scripts/online.dll?icq=$memset[8]&amp;img=5" alt="$msg{'052'} $memset[8]" border="0"></a>~;
			}
		}
		$message = "$message\n$signature";

		if ($enable_ubbc) { doubbc(); }
		if ($enable_smile) { dosmilies(); }

		$url = "";
		if ($memset[3] ne "\n" && $musername ne "$anonuser") {
			$url = qq~<a href="$memset[4]" target="_blank"><img src="$imagesurl/forum/www.gif" alt="$msg{'053'} $musername" border="0"></a>&nbsp;&nbsp;~;
		}

		foreach $censor (@censored) {
			$censor =~ s/\n//g;
			($word, $censored) = split(/\=/, $censor);
			$message =~ s/$word/$censored/g;
			$subject =~ s/$word/$censored/g;
		}
	$memberpic ="";

		if ($musername ne "$anonuser") { 
			if ($memset[9] eq "") { $memset[9] = "_nopic.gif"; }
			if ($memset[9] =~ /^\http:\/\// ) {
				if ($memberpic_width ne 0) { $tmp_width = qq~width="$memberpic_width"~; } 
				else { $tmp_width = ""; }
				if ($memberpic_height ne 0) { $tmp_height = qq~height="$memberpic_height"~; } 
				else { $tmp_height = ""; }
				$memberpic = qq~<img src="$memset[9]" $tmp_width $tmp_height border="0" alt="$info{'username'}"></a>~;
			}
			else {
				$memberpic = qq~<img src="$imagesurl/avatars/$memset[9]" border="0" alt=""></a>~;
			}
		}



		display_date($mdate); $mdate = $user_display_date;
		print qq~<table width="100%" bgcolor="$titlebg" border="0" cellspacing="0" cellpadding="0">
<tr>
<td valign="top" width="100%">
<table width="100%" border="0" cellspacing="1" cellpadding="2">
<tr>
<td class="forumwindow1"><b><u>$msg{'006'}</u></b></td>
<td class="forumwindow1"><b><u>$msg{'037'}</u></b></td>
</tr>
<tr>
<td bgcolor="#ffffff" width="140" valign="top" rowspan="2">
<b><font color=red face=Helvetica size=2>$memset[1]</font></b><br>
$memberpic
<br>
$memberinfo
<br>

</td>
<td bgcolor="#FFFFFF" valign="top">
<table border="0" width="100%" cellpadding="0" cellspacing="1">
<tr>
<td width="100%">&nbsp;<b><font face=Helvetica size=4>~;if ($micon ne "1"){print qq~
<img src="$imagesurl/im/$micon.gif">&nbsp; ~;}else{print qq~ 
<img src="$imagesurl/im/aicon1.gif">&nbsp; ~;} print qq~$subject</b></font></td>
<td align="right" nowrap><b>$msg{'054'}</b> $mdate</td>
</tr>
</table>
<hr noshade="noshade" size="1">
$message
</td>
</tr>
<tr>
<td class="forumwindow1">
<table border="0" width="100%" cellpadding="0" cellspacing="1">
<tr bgcolor=#D4D7E8>
<td>~;
if ($musername ne "$anonuser") {print qq~$url~;
if ($hidemail eq "1" || $hidemail eq "") {
print qq~<a href="$cgi?action=anonemail&sendto=$musername">~;
}
else {
print qq~<a href="mailto:$mail">~;
}
print qq~<img src="$imagesurl/forum/email.gif" alt="$msg{'055'} $musername" border="0"></a>$viewd$icq~;
}
print qq~</td><td align="right">~;

if ($musername ne "$anonuser") {print qq~
<a href="$cgi?action=imsend&num=$messageid&quote=1&to=$musername"><img src="$imagesurl/forum/quote.gif" alt="$msg{'056'}" border="0"></a>&nbsp;&nbsp;<a href="$cgi?action=imsend&to=$musername&num=$messageid"><img src="$imagesurl/forum/replymsg.gif" alt="$msg{'057'}" border="0"></a>
<a href="$pageurl/$cgi?action=moveim&msg=$mmessage&save=1&from=$musername&subj=$msub&id=$messageid&icon=$micon&viewd=$mviewed"><img src="$imagesurl/im/disk.gif" alt="Save" border="0"></a>
~;}
print qq~

<a href="$cgi?action=imremove&id=$messageid"><img src="$imagesurl/forum/delete.gif" alt="$msg{'058'}" border="0"></a></td>
</tr>
<tr><td colspan=2 bgcolor=#D4D7E8 align=right><font color=navy><b><a href=$cgi?action=im>$imx{'007'}</a></font></b></td></tr>

</table>
</td>
</tr>
</table>
</td>
</tr>
</table>
<br><br>
<table width=100%><tr><td class=forumwindow1><hr></td></tr></table><br><br>
~;
}




#############
sub imview2 {
#############	
  if ($username eq "$anonuser") { error("noguests"); }
	if ($info{'to'} =~ /(\$+|\|+|\(+|\)+|\[+|\]+|\{+|\}+|\^+|\*+|\.+|\<)/) { print_top();  print "What are you doing Stan?"; print_bottom(); exit; }
	
	$to = $info{"to"};

	open(FILE, "$memberdir/$to.dat");
	lock(FILE);
	@memset = <FILE>;
	unlock(FILE);
	close(FILE);

		open(FILE, ">$memberdir/backup/$username.msg");
		lock(FILE);
		foreach $msg (@imessages) {
		chomp $msg;
		($t, $t, $t, $t, $messageid1, $t) = split(/\|/, $msg);
		if ($umessageid == $messageid1) {
			($musername, $msub, $mdate, $mmessage, $messageid, $recipient, $micon, $mviewed) = split(/\|/, $msg);
			$subject = $msub; $message = $mmessage;
			print FILE "$msg|1\n";
		}
		else {
			print FILE "$msg\n" ;
		}
	}
	unlock(FILE);
	close(FILE);
	
	
		$ranking = $memset[6]+$memset[11]+$memset[12];
		
		$postinfo = qq~<small>$msg{'021'} $memset[6]<br>
$msg{'022'} $memset[11]<br>
$msg{'023'} $memset[12]</small><br>
~;
		$viewd = qq~&nbsp;&nbsp;<a href="$cgi\?action=viewprofile&username=$recipient"><img src="$imagesurl/forum/profile.gif" alt="$msg{'051'} $recipient" border="0"></a>~;
			$memberinfo = "$membergroups[2]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		if ($ranking > 25) {
			$memberinfo = "$membergroups[3]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		}
		if ($ranking > 50) {
			$memberinfo = "$membergroups[4]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		}
		if ($ranking > 75) {
			$memberinfo = "$membergroups[5]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		}
		if ($ranking > 100) {
			$memberinfo = "$membergroups[6]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		}
		if ($ranking > 250) {
			$memberinfo = "$membergroups[7]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		}
		if ($ranking > 500) {
			$memberinfo = "$membergroups[8]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		}	
		if ($boardmoderator eq "$musername") { $memberinfo = "$membergroups[1]"; }
		if ($memset[7] ne "\n") { $memberinfo = "$memset[7]"; }
		if ($memberinfo eq "$root") { $memberinfo = "$membergroups[0]"; }
		$signature = "$memset[5]";
		$signature =~ s/\&\&/<br>/g;
		$signature = qq~<br><br><br>
-----------------<br>
$signature
~;
		$memset[8] =~ s/\n//g;
		$memset[8] =~ s/\r//g;
		if ($memset[8] ne "") {
	                if (!($memset[8] =~ /\D/)) { 
				$icq = qq~&nbsp;&nbsp;<a href="http://www.icq.com/$memset[8]" target="_blank"><img src="http://wwp.icq.com/scripts/online.dll?icq=$memset[8]&amp;img=5" alt="$msg{'052'} $memset[8]" border="0"></a>~;
			}
		}
		$message = "$message\n";

		if ($enable_ubbc) { doubbc(); }
		if ($enable_smile) { dosmilies(); }

		$url = "";
		if ($memset[3] ne "\n" && $musername ne "$anonuser") {
			$url = qq~<a href="$memset[4]" target="_blank"><img src="$imagesurl/forum/www.gif" alt="$msg{'053'} $musername" border="0"></a>&nbsp;&nbsp;~;
		}

		foreach $censor (@censored) {
			$censor =~ s/\n//g;
			($word, $censored) = split(/\=/, $censor);
			$message =~ s/$word/$censored/g;
			$subject =~ s/$word/$censored/g;
		}
	$memberpic ="";

		if ($musername ne "$anonuser") { 
			if ($memset[9] eq "") { $memset[9] = "_nopic.gif"; }
			if ($memset[9] =~ /^\http:\/\// ) {
				if ($memberpic_width ne 0) { $tmp_width = qq~width="$memberpic_width"~; } 
				else { $tmp_width = ""; }
				if ($memberpic_height ne 0) { $tmp_height = qq~height="$memberpic_height"~; } 
				else { $tmp_height = ""; }
				$memberpic = qq~<img src="$memset[9]" $tmp_width $tmp_height border="0" alt="$info{'username'}"></a>~;
			}
			else {
				$memberpic = qq~<img src="$imagesurl/avatars/$memset[9]" border="0" alt=""></a>~;
			}
		}



		display_date($mdate); $mdate = $user_display_date;
		print qq~<table width="100%" bgcolor="$titlebg" border="0" cellspacing="0" cellpadding="0">
<tr>
<td valign="top" width="100%">
<table width="100%" border="0" cellspacing="1" cellpadding="2">
<tr>
<td class="forumwindow1"><b><u>$msg{'006'}</u></b></td>
<td class="forumwindow1"><b><u>$msg{'037'}</u></b></td>
</tr>
<tr>
<td bgcolor="#ffffff" width="140" valign="top" rowspan="2">
<b><font color=red face=Helvetica size=2>$memset[1]</font></b><br>
$memberpic
<br>
$memberinfo
<br>

</td>
<td bgcolor="#FFFFFF" valign="top">
<table border="0" width="100%" cellpadding="0" cellspacing="1">
<tr>
<td width="100%">&nbsp;<b><font face=Helvetica size=4>~;if ($micon ne "1"){print qq~
<img src="$imagesurl/im/$micon.gif">&nbsp; ~;}else{print qq~ 
<img src="$imagesurl/im/aicon1.gif">&nbsp; ~;} print qq~$subject</b></font></td>
<td align="right" nowrap><b>$msg{'054'}</b> $mdate</td>
</tr>
</table>
<hr noshade="noshade" size="1">
$message
<br><br><br><br><br><Br><br>
</td>
</tr>
<tr>
<td class="forumwindow1">
<table border="0" width="100%" cellpadding="0" cellspacing="1">
<tr bgcolor=#D4D7E8>
<td>~;
if ($musername ne "$anonuser") {print qq~$url~;
if ($hidemail eq "1" || $hidemail eq "") {
print qq~<a href="$cgi?action=anonemail&sendto=$recipient">~;
}
else {
print qq~<a href="mailto:$mail">~;
}
print qq~<img src="$imagesurl/forum/email.gif" alt="$msg{'055'} $recipient" border="0"></a>$viewd$icq~;
}
print qq~</td><td align="right">~;

print qq~<a href="$cgi?action=imremove2&id=$messageid"><img src="$imagesurl/forum/delete.gif" alt="$msg{'058'}" border="0"></a></td>
</tr>
<tr><td colspan=2 bgcolor=#D4D7E8 align=right><font color=navy><b><a href=$cgi?action=imfolder>$imx{'007'}</a></font></b></td></tr>
</table>
</td>
</tr>
</table>
</td>
</tr>
</table>
<br><br>
<table width=100%><tr><td class=forumwindow1><hr></td></tr></table><br><br>
~;
}

#############
sub imview3 {
#############	
	
  if ($username eq "$anonuser") { error("noguests"); }
	if ($info{'from'} =~ /(\$+|\|+|\(+|\)+|\[+|\]+|\{+|\}+|\^+|\*+|\.+|\<)/) { print_top();  print "What are you doing Stan?"; print_bottom(); exit; }
	
	$to = $info{"from"};

	open(FILE, "$memberdir/$to.dat");
	lock(FILE);
	@memset = <FILE>;
	unlock(FILE);
	close(FILE);

		open(FILE, ">$memberdir/saved/$username.msg");
		lock(FILE);
		foreach $msg (@imessages) {
		chomp $msg;
		($t, $t, $t, $t, $messageid1, $t) = split(/\|/, $msg);
		if ($umessageid == $messageid1) {
			($musername, $msub, $mdate, $mmessage, $messageid, $micon, $mviewed) = split(/\|/, $msg);
			$subject = $msub; $message = $mmessage;
			print FILE "$msg|1\n";
		}
		else {
			print FILE "$msg\n" ;
		}
	}
	unlock(FILE);
	close(FILE);
	
	
		$ranking = $memset[6]+$memset[11]+$memset[12];
		
		$postinfo = qq~<small>$msg{'021'} $memset[6]<br>
$msg{'022'} $memset[11]<br>
$msg{'023'} $memset[12]</small><br>
~;
		$viewd = qq~&nbsp;&nbsp;<a href="$cgi\?action=viewprofile&username=$musername"><img src="$imagesurl/forum/profile.gif" alt="$msg{'051'} $musername" border="0"></a>~;
			$memberinfo = "$membergroups[2]";
			$star = qq~<img src="$imagesurl/forum/rank/rank1.gif" alt="" border="0">~;
				if ($ranking > 25) {
			$memberinfo = "$membergroups[3]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		}
		if ($ranking > 50) {
			$memberinfo = "$membergroups[4]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		}
		if ($ranking > 75) {
			$memberinfo = "$membergroups[5]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		}
		if ($ranking > 100) {
			$memberinfo = "$membergroups[6]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		}
		if ($ranking > 250) {
			$memberinfo = "$membergroups[7]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		}
		if ($ranking > 500) {
			$memberinfo = "$membergroups[8]";
			$star = qq~<img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0"><img src="$imagesurl/forum/star.gif" alt="" border="0">~;
		}	
		if ($boardmoderator eq "$musername") { $memberinfo = "$membergroups[1]"; }
		if ($memset[7] ne "\n") { $memberinfo = "$memset[7]"; }
		if ($memberinfo eq "$root") { $memberinfo = "$membergroups[0]"; }
		$signature = "$memset[5]";
		$signature =~ s/\&\&/<br>/g;
		$signature = qq~<br><br><br>
-----------------<br>
$signature
~;
		$memset[8] =~ s/\n//g;
		$memset[8] =~ s/\r//g;
		if ($memset[8] ne "") {
	                if (!($memset[8] =~ /\D/)) { 
				$icq = qq~&nbsp;&nbsp;<a href="http://www.icq.com/$memset[8]" target="_blank"><img src="http://wwp.icq.com/scripts/online.dll?icq=$memset[8]&amp;img=5" alt="$msg{'052'} $memset[8]" border="0"></a>~;
			}
		}
		$message = "$message\n$signature";

		if ($enable_ubbc) { doubbc(); }
		if ($enable_smile) { dosmilies(); }

		$url = "";
		if ($memset[3] ne "\n" && $musername ne "$anonuser") {
			$url = qq~<a href="$memset[4]" target="_blank"><img src="$imagesurl/forum/www.gif" alt="$msg{'053'} $musername" border="0"></a>&nbsp;&nbsp;~;
		}

		foreach $censor (@censored) {
			$censor =~ s/\n//g;
			($word, $censored) = split(/\=/, $censor);
			$message =~ s/$word/$censored/g;
			$subject =~ s/$word/$censored/g;
		}
	$memberpic ="";

		if ($musername ne "$anonuser") { 
			if ($memset[9] eq "") { $memset[9] = "_nopic.gif"; }
			if ($memset[9] =~ /^\http:\/\// ) {
				if ($memberpic_width ne 0) { $tmp_width = qq~width="$memberpic_width"~; } 
				else { $tmp_width = ""; }
				if ($memberpic_height ne 0) { $tmp_height = qq~height="$memberpic_height"~; } 
				else { $tmp_height = ""; }
				$memberpic = qq~<img src="$memset[9]" $tmp_width $tmp_height border="0" alt="$info{'username'}"></a>~;
			}
			else {
				$memberpic = qq~<img src="$imagesurl/avatars/$memset[9]" border="0" alt=""></a>~;
			}
		}



		display_date($mdate); $mdate = $user_display_date;
		print qq~<table width="100%" bgcolor="$titlebg" border="0" cellspacing="0" cellpadding="0">
<tr>
<td valign="top" width="100%">
<table width="100%" border="0" cellspacing="1" cellpadding="2">
<tr>
<td class="forumwindow1"><b><u>$msg{'006'}</u></b></td>
<td class="forumwindow1"><b><u>$msg{'037'}</u></b></td>
</tr>
<tr>
<td bgcolor="#ffffff" width="140" valign="top" rowspan="2">
<b><font color=red face=Helvetica size=2>$memset[1]</font></b><br>
$memberpic
<br>
$memberinfo

<br>

</td>
<td bgcolor="#FFFFFF" valign="top">
<table border="0" width="100%" cellpadding="0" cellspacing="1">
<tr>
<td width="100%">&nbsp;<b><font face=Helvetica size=4>~;if ($micon ne "1"){print qq~
<img src="$imagesurl/im/$micon.gif">&nbsp; ~;}else{print qq~ 
<img src="$imagesurl/im/aicon1.gif">&nbsp; ~;} print qq~$subject</b></font></td>
<td align="right" nowrap><b>$msg{'054'}</b> $mdate</td>
</tr>
</table>
<hr noshade="noshade" size="1">
$message
</td>
</tr>
<tr>
<td class="forumwindow1">
<table border="0" width="100%" cellpadding="0" cellspacing="1">
<tr bgcolor=#D4D7E8>
<td>~;
if ($musername ne "$anonuser") {print qq~$url~;
if ($hidemail eq "1" || $hidemail eq "") {
print qq~<a href="$cgi?action=anonemail&sendto=$musername">~;
}
else {
print qq~<a href="mailto:$mail">~;
}
print qq~<img src="$imagesurl/forum/email.gif" alt="$msg{'055'} $musername" border="0"></a>$viewd$icq~;
}
print qq~</td><td align="right">~;

if ($musername ne "$anonuser") {print qq~
<a href="$cgi?action=imsend&to=$musername&num=$messageid"><img src="$imagesurl/forum/replymsg.gif" alt="$msg{'057'}" border="0"></a>
~;}
print qq~<a href="$cgi?action=imremove&id=$messageid"><img src="$imagesurl/forum/delete.gif" alt="$msg{'058'}" border="0"></a></td>
</tr>
<tr><td colspan=2 bgcolor=#D4D7E8 align=right><font color=navy><b><a href=$cgi?action=saveim>$imx{'007'}</a></font></b></td></tr>

</table>
</td>
</tr>
</table>
</td>
</tr>
</table>
<br><br>
<table width=100%><tr><td class=forumwindow1><hr></td></tr></table><br><br>
~;
}






##############
sub imremove {
##############
	if ($username eq "$anonuser") { error("noguests"); }


if ($info{'id'} eq "all") { 

	open(FILE, ">$memberdir/$username.msg");
	lock(FILE);
	print FILE "";
	unlock(FILE);
	close(FILE);
	
}

else {

	open(FILE, "$memberdir/$username.msg");
	lock(FILE);
	@imessages = <FILE>;
	unlock(FILE);
	close(FILE);

	open(FILE, ">$memberdir/$username.msg");
	lock(FILE);
	for ($a = 0; $a < @imessages; $a++) {
		($musername, $msub, $mdate, $mmessage, $messageid) = split(/\|/, $imessages[$a]);
		if ($messageid < 100 ) {
			if($a ne $info{'id'}) { print FILE "$imessages[$a]"; }
		}
		else {
			if(!($messageid =~ /$info{'id'}/)) { print FILE "$imessages[$a]"; }
		}
	}
	unlock(FILE);
	close(FILE);
}

	print "Location: $pageurl/$cgi\?action=im\n\n";
}
##############
sub imremove2 {
##############
	if ($username eq "$anonuser") { error("noguests"); }


if ($info{'id'} eq "all") { 

	open(FILE, ">$memberdir/backup/$username.msg");
	lock(FILE);
	print FILE "";
	unlock(FILE);
	close(FILE);
	
}

else {

	open(FILE, "$memberdir/backup/$username.msg");
	lock(FILE);
	@imessages = <FILE>;
	unlock(FILE);
	close(FILE);

	open(FILE, ">$memberdir/backup/$username.msg");
	lock(FILE);
	for ($a = 0; $a < @imessages; $a++) {
		($musername, $msub, $mdate, $mmessage, $messageid) = split(/\|/, $imessages[$a]);
		if ($messageid < 100 ) {
			if($a ne $info{'id'}) { print FILE "$imessages[$a]"; }
		}
		else {
			if(!($messageid =~ /$info{'id'}/)) { print FILE "$imessages[$a]"; }
		}
	}
	unlock(FILE);
	close(FILE);
}

	print "Location: $pageurl/$cgi\?action=imfolder\n\n";
}
##############
sub imremove3 {
##############
	if ($username eq "$anonuser") { error("noguests"); }


if ($info{'id'} eq "all") { 

	open(FILE, ">$memberdir/saved/$username.msg");
	lock(FILE);
	print FILE "";
	unlock(FILE);
	close(FILE);
	
}

else {

	open(FILE, "$memberdir/saved/$username.msg");
	lock(FILE);
	@imessages = <FILE>;
	unlock(FILE);
	close(FILE);

	open(FILE, ">$memberdir/saved/$username.msg");
	lock(FILE);
	for ($a = 0; $a < @imessages; $a++) {
		($musername, $msub, $mdate, $mmessage, $messageid) = split(/\|/, $imessages[$a]);
		if ($messageid < 100 ) {
			if($a ne $info{'id'}) { print FILE "$imessages[$a]"; }
		}
		else {
			if(!($messageid =~ /$info{'id'}/)) { print FILE "$imessages[$a]"; }
		}
	}
	unlock(FILE);
	close(FILE);
}

	print "Location: $pageurl/$cgi\?action=saveim\n\n";
}
############
sub impost {
############
        $mid = time; 
	
	open(FILE, "$memberdir/$username.msg");
	lock(FILE);
	@imessages = <FILE>;
	unlock(FILE);
	close(FILE);
	
	 if ($info{'subject'} ne "") { 
           $form_subject = $info{'subject'}; 
     } 

     if ($info{'msg'} ne "") { 
           $form_message = $info{'msg'}; 
     } 

	if ($info{'num'} ne "") {
		foreach $line (@imessages) {
			($mfrom, $msubject, $mdate, $mmessage, $messageid) = split(/\|/, $line);
			if ($info{'num'} eq $messageid) {
				$msubject =~ s/Re: //g;
				$form_subject = "Re: $msubject";
				$msg = $mmessage;
			}
		}
		if ($info{'quote'} == 1) {
			$form_message =~ s/\[quote\](\S+?)\[\/quote\]//isg;
			$form_message =~ s/\[(\S+?)\]//isg;
			$mmessage = htmltotext($msg);
			$form_message = "\n\n\[quote\]$mmessage\[/quote\]";
		}
	}

	$navbar = "$btn{'014'} $nav{'029'}";
	print_top();
	print qq~<table width="100%" border="0" cellspacing="0" cellpadding="1"> 
<tr>
<td><form action="$cgi?action=imsend2" name=creator method="post" onSubmit="submitonce(this)">
<input name="messageid" value="$mid" type="hidden">
<table border="0" cellspacing="1" width=100%>
<tr bgcolor=#CCCC99><td align=center colspan=2><b>$imx{'014'}</b></td></tr>
<tr bgcolor="#FAFAEF">
<td><b>Logon as: </b></td><td><b> $username </b>~;if ($username ne "$anonuser"){print qq~
<a href=$pageurl/$cgi?action=logout><small>[$imx{'015'}]</small></a>~;}else{print qq~
<a href=$pageurl/$cgi?action=register><small>[$imx{'016'}]</small></a>~;}
print qq~

</td></tr>

<tr bgcolor="#FFFFFF">
<td><b>$msg{'059'}</b></td>
~;
	if ($info{'to'} ne "") {
		print qq~<td><input type="text" name="to" value="$info{'to'}" size="20" maxlength="50"></td>~;
	}
	else {
		print qq~<td><select name="to">
~;
		open(MEM, "$memberdir/memberlist.dat");
		lock(MEM);
		@members = <MEM>;
		unlock(MEM);
		close(MEM);

		for ($i = 0; $i < @members; $i++) {
			$members[$i] =~ s/\n//g;
			if ($members[$i] ne $username) {print qq~<option value="$members[$i]">$members[$i]</option>\n~;}
		}
	print qq~</select></td>
~;
	}
	print qq~</tr>
<tr bgcolor="#FAFAEF">
<td><b>$msg{'037'}</b></td>
<td><input type="text" name="subject" value="$form_subject" size="40" maxlength="50"></td>
</tr>
<tr bgcolor=#FFFFFF>
<td valign=top><font size="1" face="Helvetica, Arial, Verdana">
<b>$imx{'017'}:</b></font>
</td>
<td>
<font size="1" face="Helvetica, Arial, Verdana">
   <input type="radio" name="icon" value="aicon2" CHECKED>&nbsp;
<img src="$imagesurl/im/aicon2.gif" height="15" width="15" align="middle" alt="">&nbsp;&nbsp;&nbsp;&nbsp;
   <input type="radio" name="icon" value="aicon1" >&nbsp;
<img src="$imagesurl/im/aicon1.gif" height="15" width="15" align="middle" alt="">&nbsp;&nbsp;&nbsp;&nbsp;
   <input type="radio" name="icon" value="icon3" >&nbsp;
<img src="$imagesurl/im/icon3.gif" height="15" width="15" align="middle" alt="">&nbsp;&nbsp;&nbsp;&nbsp;
   <input type="radio" name="icon" value="aicon4" >&nbsp;
<img src="$imagesurl/im/aicon4.gif" height="15" width="15" align="middle" alt="">&nbsp;&nbsp;&nbsp;&nbsp;
   <input type="radio" name="icon" value="aicon5" >&nbsp;
<img src="$imagesurl/im/aicon5.gif" height="15" width="15" align="middle" alt="">&nbsp;&nbsp;&nbsp;&nbsp;
   <input type="radio" name="icon" value="icon7" >&nbsp;
<img src="$imagesurl/im/icon7.gif" height="15" width="15" align="middle" alt="">&nbsp;&nbsp;&nbsp;&nbsp;
   <input type="radio" name="icon" value="aicon10" >&nbsp;
<img src="$imagesurl/im/aicon10.gif" height="15" width="15" align="middle" alt="">&nbsp;&nbsp;&nbsp;&nbsp;<br>
   <input type="radio" name="icon" value="aicon13" >&nbsp;
<img src="$imagesurl/im/aicon13.gif" height="15" width="15" align="middle" alt="">&nbsp;&nbsp;&nbsp;&nbsp;
   <input type="radio" name="icon" value="aicon14" >&nbsp;
<img src="$imagesurl/im/aicon14.gif" height="15" width="15" align="middle" alt="">&nbsp;&nbsp;&nbsp;&nbsp;
   <input type="radio" name="icon" value="icon1" >&nbsp;
<img src="$imagesurl/im/icon1.gif" height="15" width="15" align="middle" alt="">&nbsp;&nbsp;&nbsp;&nbsp;
   <input type="radio" name="icon" value="icon4" >&nbsp;
<img src="$imagesurl/im/icon4.gif" height="15" width="15" align="middle" alt="">&nbsp;&nbsp;&nbsp;&nbsp;
   <input type="radio" name="icon" value="icon5" >&nbsp;
<img src="$imagesurl/im/icon5.gif" height="15" width="15" align="middle" alt="">&nbsp;&nbsp;&nbsp;&nbsp;
   <input type="radio" name="icon" value="aicon9" >&nbsp;
<img src="$imagesurl/im/aicon9.gif" height="15" width="15" align="middle" alt="">&nbsp;&nbsp;&nbsp;&nbsp;
   <input type="radio" name="icon" value="icon10" >&nbsp;
<img src="$imagesurl/im/icon10.gif" height="15" width="15" align="middle" alt="">&nbsp;&nbsp;&nbsp;&nbsp;

</font>

</td>
</tr>
~;
if ($enable_ubbc eq "1") {print qq~
<tr bgcolor=#FFFFFF>
<td valign=top><font size="1" face="Helvetica, Arial, Verdana">
<b>$msg{'156'}</b></font></td>
<td valign="top">
<table><tr><td>
<script language="javascript" type="text/javascript">
<!--
function addCode(anystr) { 
document.creator.message.value+=anystr;
} 
function showColor(color) { 
document.creator.message.value+="[color="+color+"][/color]";
}
function showFont(font) {
document.creator.message.value+="[font="+font+"][/font]";
}
function showSize(size) {
document.creator.message.value+="[size="+size+"][/size]";
}
function upload() {
window.open("$pageurl/$cgi?action=uploadpicture","","width=300,height=150,scrollbars")
}
// -->
</script>
<select name="color" onChange="showColor(this.options[this.selectedIndex].value)">
<option value="Black" selected>$msg{'127'}</option>
<option value="Red" style='color:red'>$msg{'128'}</option>
<option value="Yellow" style='color:yellow'>$msg{'129'}</option>
<option value="Pink" style='color:pink'>$msg{'130'}</option>
<option value="Green" style='color:green'>$msg{'131'}</option>
<option value="Orange" style='color:orange'>$msg{'132'}</option>
<option value="Purple" style='color:purple'>$msg{'133'}</option>
<option value="Blue" style='color:blue'>$msg{'134'}</option>
<option value="Beige" style='color:beige'>$msg{'135'}</option>
<option value="Brown" style='color:brown'>$msg{'136'}</option>
<option value="Teal" style='color:teal'>$msg{'137'}</option>
<option value="Navy" style='color:navy'>$msg{'138'}</option>
<option value="Maroon" style='color:maroon'>$msg{'139'}</option>
<option value="LimeGreen" style='color:limegreen'>$msg{'140'}</option>
</select>
&nbsp;
<select name="font" onChange="showFont(this.options[this.selectedIndex].value)">
<option value='Arial' style="font-family:Arial" selected>Arial</option>
<option value='Times New Roman' style="font-family:Times New Roman">Times New Roman</option>
<option value='Courier' style="font-family:Courier">Courier</option>
<option value='Impact' style="font-family:Impact">Impact</option>
<option value='Geneva' style="font-family:Geneva">Geneva</option>
<option value='Verdana' style="font-family:verdana">Verdana</option>
</select>
&nbsp;
<select name="size" onChange="showSize(this.options[this.selectedIndex].value)">
<option value='1'>$imx{'018'}</option>
<option value='3' selected>$imx{'019'}</option>
<option value='5'>$imx{'020'}</option>
<option value='7'>$imx{'021'}</option>
<option value='10'>$imx{'022'}</option>
</select>

</td></tr>
<tr><td valign=bottom align=center>
<input type=button onclick="javascript:addCode('[b][/b]')" value=" B ">

<input type=button onclick="javascript:addCode('[i][/i]')" value=" I ">

<input type=button onclick="javascript:addCode('[u][/u]')" value=" U ">

<input type=button onclick="javascript:addCode('[url][/url]')" value=" http:// ">

<input type=button onclick="javascript:addCode('[email][/email]')" value=" @ ">

<input type=button onclick="javascript:addCode('[img][/img]')" value=" IMG ">

<input type=button onclick="javascript:addCode('[quote][/quote]')" value=" $imx{'023'} ">
</td></tr>
</td></table>
</td>
</tr>~;}
print qq~
<tr bgcolor="#FAFAEF">
<td valign="top"><b>$msg{'038'}</b><br>
<table width=90 border=1 bordercolor=navy cellpadding=0>
<tr><Td align=center class=forumwindow1><b>$msg{'533'}</b></td></tr>
<tr><td align=center>~;
smilieblock(); 
print qq~</td></tr></table>

</td>
<td><textarea name="message" rows="10" cols="45">$form_message</textarea>
<br><input type="checkbox" name="copy_im" checked><small>$imx{'024'}</small>
</td>
</tr>
<tr bgcolor=#FFFFFF>
<td colspan="2" align=center>
<br><input type="submit" value="$btn{'008'}">
<input type="reset" value="$btn{'009'}"></td></tr></table></form></td></tr></table>~;

	print_bottom();
	exit;
}

#############
sub impost2 {
#############
	

	$messageid = $input{'messageid'};
	$subject = htmlescape($input{'subject'});
	$message = htmlescape($input{'message'});
        $recipient = $input{'to'};
      $icon = "$input{'icon'}";
	if (-e("$memberdir/$input{'to'}.dat")) { } else { error("$err{'010'}"); }

	open (FILE, "$memberdir/$input{'to'}.msg");
	lock(FILE);
	@imessages = <FILE>;
	unlock(FILE);
	close (FILE);

	open (FILE, ">$memberdir/$input{'to'}.msg");
	lock(FILE);
	print FILE "$username|$subject|$date|$message|$messageid|$icon\n";
	foreach $curm (@imessages) { print FILE "$curm"; }
	unlock(FILE);
	close(FILE);
   
 	if ($input{'copy_im'} eq "on") {
	$subject = htmlescape("$imx{'009'}: $input{'subject'} $msg{'320'} $recipient");
 	open (FILE, "$memberdir/backup/$username.msg");
	lock(FILE);
	@imessages = <FILE>;
	unlock(FILE);
	close (FILE);

	open (FILE, ">$memberdir/backup/$username.msg");
	lock(FILE);
	print FILE "$username|$subject|$date|$message|$messageid|$recipient|$icon\n";
	foreach $curm (@imessages) { print FILE "$curm"; }
	unlock(FILE);
	close(FILE);}

	print "Location: $pageurl/$cgi\?action=im\n\n";
	exit;

}

############
sub siteim {
############

	if ($username ne "admin") { error("$err{'011'}"); }

	open(FILE, "$memberdir/$username.dat"); 
	lock(FILE); 
	chomp(@memsettings = <FILE>); 
	unlock(FILE); 
	close(FILE);

     $mid = time; 


	$navbar = "$btn{'014'} $nav{'029'}";
	print_top();
	print qq~<table width="100%" border="0" cellspacing="0" cellpadding="1">
<tr>
<td><form action="$cgi?action=siteim2" name=creator method="post">
<input name="messageid" value="$mid" type="hidden">
<table border="0" cellspacing="1" width=100%>
<tr bgcolor=#FFFFEE>
<td><b>$msg{'059'}</b></td>
<td>$msg{'563'}</td>
</tr>
<tr bgcolor=#F0F0D0>
<td><b>$msg{'037'}</b></td>
<td><input type="text" name="subject" value="$form_subject" size="40" maxlength="50"></td>
</tr>

~;
if ($enable_ubbc eq "1") {print qq~
<tr bgcolor=#FFFFEE>
<td valign=top><font size="1" face="Helvetica, Arial, Verdana">
<b>$msg{'156'}</b></font></td>
<td valign="top">
<table><tr><td>
<script language="javascript" type="text/javascript">
<!--
function addCode(anystr) { 
document.creator.message.value+=anystr;
} 
function showColor(color) { 
document.creator.message.value+="[color="+color+"][/color]";
}
function showFont(font) {
document.creator.message.value+="[font="+font+"][/font]";
}
function showSize(size) {
document.creator.message.value+="[size="+size+"][/size]";
}
function upload() {
window.open("$pageurl/$cgi?action=uploadpicture","","width=300,height=150,scrollbars")
}
// -->
</script>
<select name="color" onChange="showColor(this.options[this.selectedIndex].value)">
<option value="Black" selected>$msg{'127'}</option>
<option value="Red" style='color:red'>$msg{'128'}</option>
<option value="Yellow" style='color:yellow'>$msg{'129'}</option>
<option value="Pink" style='color:pink'>$msg{'130'}</option>
<option value="Green" style='color:green'>$msg{'131'}</option>
<option value="Orange" style='color:orange'>$msg{'132'}</option>
<option value="Purple" style='color:purple'>$msg{'133'}</option>
<option value="Blue" style='color:blue'>$msg{'134'}</option>
<option value="Beige" style='color:beige'>$msg{'135'}</option>
<option value="Brown" style='color:brown'>$msg{'136'}</option>
<option value="Teal" style='color:teal'>$msg{'137'}</option>
<option value="Navy" style='color:navy'>$msg{'138'}</option>
<option value="Maroon" style='color:maroon'>$msg{'139'}</option>
<option value="LimeGreen" style='color:limegreen'>$msg{'140'}</option>
</select>
&nbsp;
<select name="font" onChange="showFont(this.options[this.selectedIndex].value)">
<option value='Arial' style="font-family:Arial" selected>Arial</option>
<option value='Times New Roman' style="font-family:Times New Roman">Times New Roman</option>
<option value='Courier' style="font-family:Courier">Courier</option>
<option value='Impact' style="font-family:Impact">Impact</option>
<option value='Geneva' style="font-family:Geneva">Geneva</option>
<option value='Verdana' style="font-family:verdana">Verdana</option>
</select>
&nbsp;
<select name="size" onChange="showSize(this.options[this.selectedIndex].value)">
<option value='1'>$imx{'018'}</option>
<option value='3' selected>$imx{'019'}</option>
<option value='5'>$imx{'020'}</option>
<option value='7'>$imx{'021'}</option>
<option value='10'>$imx{'022'}</option>
</select>

</td></tr>
<tr><td valign=bottom align=center>
<input type=button onclick="javascript:addCode('[b][/b]')" value=" B ">

<input type=button onclick="javascript:addCode('[i][/i]')" value=" I ">

<input type=button onclick="javascript:addCode('[u][/u]')" value=" U ">

<input type=button onclick="javascript:addCode('[url][/url]')" value=" http:// ">

<input type=button onclick="javascript:addCode('[email][/email]')" value=" E-mail ">

<input type=button onclick="javascript:addCode('[img][/img]')" value=" IMG ">

<input type=button onclick="javascript:addCode('[quote][/quote]')" value=" $imx{'023'} ">
</td></tr>
</td></table>
</td>
</tr>~;}
print qq~
<tr bgcolor=#F0F0D0>
<td valign="top"><b>$msg{'038'}</b><br>
<table width=90 border=1 bordercolor=navy cellpadding=0>
<tr><Td align=center class=forumwindow1><b>$msg{'533'}</b></td></tr>
<tr><td align=center>~;
smilieblock(); 
print qq~</td></tr></table>

</td>

<td><textarea name="message" rows="10" cols="40"></textarea></td>
</tr>
<tr bgcolor=#FFFFEE>
<td colspan="2"><input type="submit" value="$btn{'008'}">
<input type="reset" value="$btn{'009'}"></td>
</tr>
</table>
</form>
</td>
</tr>
</table>
~;

	print_bottom();
	exit;

}

#############
sub siteim2 {
#############

	if ($username ne "admin") { error("$err{'011'}"); }

	open(FILE, "$memberdir/$username.dat"); 
	lock(FILE); 
	chomp(@memsettings = <FILE>); 
	unlock(FILE); 
	close(FILE);


	error("$err{'014'}") unless($input{'subject'});
	error("$err{'015'}") unless($input{'message'});

	$imsubj = htmlescape($input{'subject'});
	$formatmsg = htmlescape($input{'message'});


	open (FILE, "$memberdir/memberlist.dat");
	lock(FILE);
	@sendingto = <FILE>;
	unlock(FILE);
	close (FILE);

	foreach $sitemember (@sendingto) {
		$sitemember =~ s/[\n\r]//g;
							

				sendim($sitemember, $imsubj, $formatmsg, $username);


		}

	print "Location: $pageurl/$cgi\?action=im\n\n";
	exit;

}
}
1; # return true