##################################################################################
##################################################################################
##              P J I R C - C h a t  M O D   v1.0	For WebApp 			  		##
##______________________________________________________________________________##
##																				##
##	By Dennis Jozefowicz http://rainbowlife.com 	 							##
##______________________________________________________________________________##
##																				##
## This script is free software; you can redistribute it and/or					##
## modify it under the terms of the GNU General Public License					##
## as published by the Free Software Foundation; either version 2				##
## of the License, or (at your option) any later version.						##
##																				##
## This program is distributed in the hope that it will be useful,				##
## but WITHOUT ANY WARRANTY; without even the implied warranty of				##
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the				##
## GNU General Public License for more details.									##
##																				##
## You should have received a copy of the GNU General Public License			##
## along with this program; if not, write to the Free Software					##
## Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.	##
##################################################################################
##################################################################################

Welcome to the most exciting addition to your WebAPP site, WebAPPIRC.
Follow these steps to quickly and easily install your chat room today!

Please note:BY ALL MEANS, to save youself headaches, use the default
paths to this mod, and installation should be painless!

Step 1
------
Open the ingex.cgi in your editor and change the perl path on the first line.
(If it isn't correct already!)  Then save it!

Step 2
------
Open the settings.pl file, and enter all the settings parameters.
Everything is commented in detail in the file.
Save it!

Step 3
------
Uploading:
Create a folder in your mods/ directory, and name it "chat".
Upload all the files in the cgi-bin/mods/chat of this archive in ASCII to your cgi-bin/mods/chat. 
CHMOD index.cgi and settings.pl to 755

In your www/ directory, create another folder, and call it "chat".
Using the AUTO feature of your FTP, upload all the contents in the www/chat of this archive to your www/chat.
(Everything here is binary except .lng files and the html file.)

Step 4
------
Testing:
Go to http://www.yoursite.com/cgi-bin/mods/chat/index.cgi
Did everything work?  I hope so!

Step 5
------
Add a menu item:
There are 2 ways we can add this item to your main menu.  The first, everyone can see the option
on your main menu and use it.

In theme.pl, add the following line in the sub main_menu:
<td class="cat"><img src="$themesurl/$usertheme/images/dot.gif">&nbsp;<a href="http://www.yoursite.com/cgi-bin/mods/chat/index.cgi" class="menu">IRC Chat</a></td>

Now, to only have members see this option on the menu, add the following lines to sub main_menu:
if ($username eq "$anonuser"){}
else{print qq~<tr>
<td class="cat"><img src="$themesurl/$usertheme/images/dot.gif">&nbsp;<a href="http://www.yoursite.com/cgi-bin/mods/chat/index.cgi" class="menu">IRC Chat</a></td>
</tr>~;}

Step 6
------
ENJOY!  I hope it works for you, this is my 1st mod!
DenDen32

In the works for future versions:
web cam support!
even better integration into WebAPP.
Language support.
Themes.
