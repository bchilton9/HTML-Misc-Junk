##################################################################################
##################################################################################
##              P J I R C - C h a t  M O D   v1.0	For WebApp 			  		##
##______________________________________________________________________________##
##																				##
##	By Dennis Jozefowicz http://rainbowlife.com from 					##
##______________________________________________________________________________##
##																				##
## This script is free software; you can redistribute it and/or					##
## modify it under the terms of the GNU General Public License					##
## as published by the Free Software Foundation; either version 2				##
## of the License, or (at your option) any later version.						##
##																				##
## This program is distributed in the hope that it will be useful,				##
## but WITHOUT ANY WARRANTY; without even the implied warranty of				##
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the				##
## GNU General Public License for more details.									##
##																				##
## You should have received a copy of the GNU General Public License			##
## along with this program; if not, write to the Free Software					##
## Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.	##
##################################################################################
##################################################################################

##############################################
# The following variables should be edited! #
##############################################

# Edit this only if you are NOT using default install directories!!!!
$jircurl = "$baseurl/chat";

# This is where you enter an IRC Server.
# 2 places to find official server listings for Undernet and Efnet networks is
# http://www.undernet.org/servers.php and http://www.efnet.info/?module=servers
# (You're more likely to find a server that works for you in these websites.)
# The default is an undernet server.
$server = "Sterling.VA.US.Undernet.Org";

# Select a second server to connect to if the 1st one is down, and what port to connect to.
$altserver = "miami.fl.us.Undernet.org 6667";

# Port (most IRC servers work in ports 6660 to 6670, 6667 is standard).
$ircport = "6667";

# Type in the name of the chat room you'd like to enter, or create, after log in.
# The name MUST start with the pound sign "#".
$chatroom = "#yourroomname";

# Size of the chat applet
$width = "100%";
$height = "400";
# This is the name dispayed when someone gets info on any of your users.
# It can be anything you like.  
$fullname = "mysite.com Java User";
# Enter a message to be displayed in a room when one of your users quits chat.
$quit = "Visit mysite.com, the nice community.";

# this is the language files of the IRC client, NOT WebAPP.
# more can be obtained at http://www.pjirc.com/downloads.php?p=0&c=1
# You need 2 lang files, one for the chat, and one for the PIXX interface.
# example: english.lng and pixx-english.lng are for english translations.
$irclang = "english";

# You're website's name or title.
$webname = "mysite.com";

# This is your Alternate nick name for people who are not members
# of your website.  They cannot change their name.  An incentive to
# join your website. Use 7 letters with the ?? at the end!!!!!!
# The ?? generates a random number not taken by anyone else.
# The default would generate a nick "nonmemb75" for example.
$altnick = "nonmemb??";

# That's all.  See readme.txt for installation!
