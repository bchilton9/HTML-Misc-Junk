##################################################################
##################################################################
# 
#     HomePages for WebAPP by bigmike - bigmike@bigmikesmedia.com
#     ver 0.1 - 5/20/03
#
##################################################################
##################################################################
#   The original credits and script history are in homepage.pl
#   FOR THE IMPATIENT!!  Scroll down to the step by step install
################################################################## 

 Overview:                      
 
 First off, this is basically just a fun add on that gives your members a bit more to do at your site
 and makes it more interactive. I'm sure some of you can find a constructive use for this but if 
 nothing else it's kinda neat.
 
 This mod will give members of your site (and visitors if you choose) the ability to create a simple
 webpage containing text, links, and graphics. Users can also edit or delete their page at any time.
 You decide what graphics to make available by simply adding them to their propper folder. At this time
 there isn't any upload capabilities for the user or any language support, but that may be a future
 add-on if people like it.

 Requirements:

 A WebApp site and the showhtml mod                      

 Installation overview:

 Installation should be pretty straight forward as long as I don't leave something out, so here goes.
 Here is a brief description, basically there are three parts to this installation, the mod folder, which
 has the scripts and some of the data files. The HomePages index page, which resides in your html folder
 of your showhtml mod. And lastly the HomePages folder that holds the actual users pages and all the
 graphics for those pages. This folder resides at the root of your website. There are good reasons for why
 I've put the pages the where I did and if I could remember them I'd tell you. (just kidding) It basically
 has to do with writeable pages and trying to keep a relatively easy URL for the users pages.
 
 Usage:

 Once installed usage should be pretty self explanitory. There are navigation links on both the script
 produced pages and the homepages.html page (the user pages index page). I have included a couple test pages
 so you can see how it kinda looks with pages. Originally the only way to delete or edit a page was through
 the "Edit page" and "Delete page" links which is kind of a pain. It requires the user supplied username,
 email address and page name which is in the data.txt file of the data folder in your cgi-bin. If you want
 to edit a page you still have to go that route but if you want to delete a page you can use the admin script
 that I put together which only requires the page name. The only link to the admin page is through the Mod
 Manager where you see the Homepages Mod. It is only available to the $root admin, you can change that if you
 like. The way it is right now anyone can see the pages and the homepages.html but only members can create
 pages. The script also sends confirmation e-mails to both you and the user via sendmail. If you don't have
 sendmail you can disable this feature by going into homepage.pl and commenting out where it sends the mail.
 I've commented where it's at and what to comment, you have to do it in two spots.
 
 Feel free to make any changes, anywhere!
 
 Step by step install:

 Step 1: Install the homepages folder located in the HTML folder in the root directory of your website and
 chmod 777.
 ie. http://www.yoursite.com/homepages

 Step 2: Install the homepages folder located in the cgi-bin/mods folder into your mods folder of your cgi-bin
 and chmod as usual, folders 777, scripts 755 and the data.txt either 666 or 777.
 ie. http://www.yoursite.com/cgi-bin/mods/homepages

 Step 3: Install the homepages.html file into the html folder of your showhtml mod and chmod 777. Then open
 it in an editor and change the page links to your site URL, JUST where it says www.yoursite.com NOT the links
 to the script above!
 ie. http://www.yoursite.com/cgi-bin/mods/showhtml/html/homepages.html

 Step 4: Last but not least, go back to your cgi-bin and configure the variables in the homepage.cfg file.
 If this mod is installed as instructed here this is the only file you should have to modify.

 Step 5: Create a link to the homepages.html flle and start playing!
 ie. http://www.yoursite.com/cgi-bin/mods/showhtml/showhtml.pl?filename=homepages.html
 
 The admin page is at:
 http://www.yoursite.com/cgi-bin/mods/homepages/admin/admin.cgi

 That should be it! enjoy! feel free to let me know if you have any questions.

 Big Mike :)

 ps. I hope I didn't leave anything out ;)
 



