############################################################################################################
# THIS FILE CONTAINS HTML USED BY HOMEPAGE.PL - EDIT IT TO SUIT YOUR NEEDS!

############################################################################################################
# STANDARD USER PAGES CSS LINK - SETS STYLES FOR USER PAGES (USEFUL FOR USE WITH YOUR USER PAGE HEADER) 
# DELETE THE CONTENTS OF THIS IF YOU DON'T WANT TO USE CSS

$hp_css = qq~
<LINK rel="stylesheet" type="text/css" href="$baseurl/css/hp.css">
~;

############################################################################################################
# STANDARD HEADER - USED BY THE SCRIPT'S PAGES 
# Don't change this! otherwise you won't have any navigation on your script pages
$badj_header = qq~
<!--HEADER STARTS-->
<TABLE border="0" width="80%" cellspacing="0" align=center>
   <tr><td align=center>
        <B><A href="/cgi-bin/mods/homepages/homepages.cgi?newpage">Create
        Page</A>&nbsp;
        �&nbsp;<A href="/cgi-bin/mods/homepages/homepages.cgi?editpage">Edit
        Page</A>&nbsp;
        �&nbsp;<A href="/cgi-bin/mods/homepages/homepages.cgi?delpage">Delete
        Page</A>&nbsp;
        �&nbsp;<A href="/cgi-bin/mods/showhtml/showhtml.pl?filename=homepages.html">
        View Pages</A>
        �&nbsp;<A href="/cgi-bin/mods/homepages/homepages.cgi?help">
        Help</A></B>        
    </td></td></table>
<!--HEADER ENDS-->
~;

# USERPAGE HEADER ##########################################################################################
# This is placed at the top of user pages. It's reccomended you use an SSI pointing to a page
# containing the header so it can be easily updated on all pages. If you haven't gos SSI just
# include the HTML of the header here. Delete the HTML if you don't want to include a header.

$userpage_header = qq~
<!--HEADER STARTS-->

<!--HEADER ENDS-->
~;

# SEPERATOR ################################################################################################
# Don't worry about this - it's just a html seperator table to space things out on the page.

$badj_seperator = qq~
<!--SEPERATOR STARTS-->
<TABLE border="0" width="100%" cellspacing="0" cellpadding="5">
  <TR>
    <TD width="100%">
      <TABLE border="0" width="100%" cellspacing="0" cellpadding="0">
        <TR>
          <TD width="100%"></TD>
        </TR>
      </TABLE>
    </TD>
  </TR>
</TABLE>
<!--SEPERATOR ENDS-->
~;

# BADJ FOOTER ##############################################################################################
# The footer displayed beneath homepage.pl's forms. 
# Feel free to change this to your WebAPP site's address
$badj_footer = qq~
<!--FOOTER STARTS-->
<TABLE border="0" width="100%" cellspacing="0" cellpadding="5"><TR><TD width="100%">
<P align="center">
Powered by <A href="http://www.scoretv.net/cgi-bin/mods/showhtml/showhtml.pl?filename=homepages.html">Homepages for WebAPP</A>
</FONT></TD></TR></TABLE>
<!--FOOTER ENDS-->
~;

# COPYRIGHT NOTICE #########################################################################################
# This need not be a copyright notice, but it's what is displayed at the bottom of user pages.
# Feel free to change this to your WebAPP site's address
$copyright_notice = qq~
<!--FOOTER STARTS-->
<P><font size="1"><A href="http://www.scoretv.net/cgi-bin/mods/showhtml/showhtml.pl?filename=homepages.html">Created with HomePages for WebApp</A>
</FONT></P>
<!--FOOTER ENDS-->
~;












