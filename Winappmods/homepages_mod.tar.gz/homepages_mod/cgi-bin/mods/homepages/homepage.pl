#!/usr/bin/perl
#####################################################
# EZHOMEPG - ETHOS STYLE v 1.4                      #
#                                                   #
# This script is provided in the hope that it will  #
# useful. You can modify it to your heart's content #
# but you can't distribute it without prior         #
# permission from the copyright holders.            #
#                                                   #
# This script is provided in an 'as is' condition.  #
# We hope you will find it useful. We have made     #
# every effort to ensure that the script works      #
# properly on all platforms and the installation    #
# is as quick and painless as possible. However,    #
# neither Ethos Online, Manny Juan or any other     #
# contributors to this script can be held           #
# responsible for any loss or damaged caused either #
# directly or indirectly by this script. USE IT AT  #
# YOUR OWN RISK!                                    #
#####################################################
#                                                   #
# CONTRIBUTORS AND HISTORY:                         #
#                                                   #
# This script is based on Manny Juan's EZHomepg,    #
# has been modified by Ethos Online and includes a  #
# modification by Bill Hall.                        #
#                                                   #
# For more information about EZHomepg visit either  #
# Manny Juan's Script Page at                       #
# http://www.inet-images.com/manny/ or Ethos Online #
# at http://www.ethosonline.com/scripts/            #
#####################################################
#
# EZHomepg - Ethos Style - http://www.ethosonline.com/scripts/
# Version 1.0 - 19/02/00 Beta release
# Version 1.1 - 28/02/00 Original release. Fixed some HTML problems and altered comment lines.
# Version 1.2 - 09/03/00 Added support for blocking special characters in file names. A much
#                        needed modification.
# Version 1.3 - 05/05/00 Added email validator
# Version 1.4 - 11/06/01 Fixed Headers problem encountered on some servers.
#####################################################
# ezhomepg - EZ Home Page Generator - by Manny Juan <manny@jps.net> 
# http://inet-images.com/manny/userpages/
#
# ver 1.20 - 10/8/98 added simple table creation
# ver 1.10 - 10/7/98 added deletion capability and handled un-selected graphics
# ver 1.00 - 9/25/98 changed to use same code for create/edit logic, eliminate makepage.html 
#                    also added code to remember user's clip art choices 
# ver 1.21 - 01/29/2000 - modifications by Bill Hall Compucat Software
#
# Ethos modifications by Ethos Online <scripts@ethosonline.com>
# http://www.ethosonline.com/
#
# Original program was
# HomePageMaker v.1.6 written by Dave Palmer <dave@upstatepress.com>
# http://www.upstatepress.com/dave/perl.shtml
# Modified by Greg Mathews <webmaster@notts.net>.
#####################################################################################
# HomePages for WebAPP - by - bigmike - bigmike@bigmikesmedia.com - aka - 1bigmike at WebAPP
# ver 0.1 - 5/20/03 Modified original script and added some routines to make it work within 
# the WebAPP enviroment. Also added admin delete page ability
#######################################################################################

# A COUPLE OF THINGS TO SET!

# Path to homepage.cfg file
# Set this to the full path if you are having problems
require "homepage.cfg";

# Path to HTML code file (contains headers, footers, etc).
# Set this to the full path if you are having problems
require "html.pl";

# YOU DO NOT NEED TO CHANGE ANYTHING BELOW THIS LINE!
######################################################################################
$SIG{__DIE__} = \&Error_Msg;

sub Error_Msg {
    $msg = "@_";
    print "\nContent-type: text/html\n\n";
    print "The following error occurred : $msg\n";
    exit;
}

# Get the input
read(STDIN, $input, $ENV{'CONTENT_LENGTH'});

    # split the input
    @pairs = split(/&/, $input);

    # split the name/value pairs
    foreach $pair (@pairs) {

    ($name, $value) = split(/=/, $pair);

    $name =~ tr/+/ /;
    $name =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
    $value =~ tr/+/ /;
    $value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
    $value =~ s/<([^>]|\n)*>//g;

  $FORM{$name} = $value;
    }

# Lets do some translating first
$usrname = $FORM{'usrname'};
$email = $FORM{'email'};
$background = $FORM{'background'};
$emailgif = $FORM{'emailgif'};
$linkc = $FORM{'linkc'};
$vlinkc = $FORM{'vlinkc'};
$textc = $FORM{'textc'};
$headline = $FORM{'headline'};
$subhead = $FORM{'subhead'};
$headpos = $FORM{'headpos'};
$topimage = $FORM{'topimage'};
$line2 = $FORM{'line'};
$imageyn = "yes";
$imagepos = $FORM{'imagepos'};
$imdesc = $FORM{'imdesc'};
$usrlink1 = $FORM{'usrlink1'};
$usrlink2 = $FORM{'usrlink2'};
$usrlink3 = $FORM{'usrlink3'};
$linkname1 = $FORM{'linkname1'};
$linkname2 = $FORM{'linkname2'};
$linkname3 = $FORM{'linkname3'};
$FORM{'content'}=~s/\cM//g;
$FORM{'content'}=~s/\n\n/%%/g;
$FORM{'content'}=~s/\n/<br>/g;
$content = $FORM{'content'};
$images = $FORM{'images'};
$pagename = $FORM{'pagename'};
$login = $FORM{'login'};
$bullet = $FORM{'bullet'};
$FORM{'tbltext'}=~s/\cM//g;
$FORM{'tbltext'}=~s/\n/%%/g;
$tbltext = $FORM{'tbltext'};
$updact = $FORM{'updact'};
$font = $FORM{'font'};
$anotherline = $FORM{'anotherline'};
$emailonpage = $FORM{'emailonpage'};


# Add the line breaks for paragraph spacing
$printcontent =~ s/&&/<br><br>/g;
$printcontent =~ s/&&/%%/g;

# This fixes the bug of white space and
# other wierd spacing:
$content =~ s/\cM//g;
$content =~ s/\n/  /g;
$tbltext =~ s/\cM//g;
$tbltext =~ s/\n/  /g;

# If the user tries to add more than one word in
# the page name field, this will put an underscore
# in the spaces to make it one word
$pagename =~ s/ /_/g;

# Find out what the user wants to do
if ($FORM{'action'} eq "New Page") {
    &newpage;
    }
if ($FORM{'action'} eq "Create Page") {
    &create;
    }
if ($FORM{'action'} eq "Edit Page") {
    &confirm("edit");
    }
if ($FORM{'action'} eq "checkuser") {
    &checkuser;
    }
if ($FORM{'action'} eq "checkuser2") {
    &checkuser2;
    }
if ($FORM{'action'} eq "recreate") {
    &recreate;
    }
if ($FORM{'action'} eq "Delete Page") {
    &confirm("delete");
    }

$homepageaction = $ENV{'QUERY_STRING'};

if ($homepageaction eq "newpage") {
    &newpage;
    }
if ($homepageaction eq "editpage") {
    &confirm("edit");
    }
if ($homepageaction eq "delpage") {
    &confirm("delete");
    }
if ($homepageaction eq "help") {
    &helppage;
    }
else { &newpage; }

sub newpage() {
    local($usrname, $mail, $head, $sub, $body, $bgimage, $linkcolor, $vlinkcolor, 
        $ahref1, $ahref2, $ahref3, $ahrefname1, $ahref2name, $ahref3name,
            $filename, $imurl, $hrline, $emailpic, $textcolor, $bullet, $tbltext, $font, $hrline2, $emailonpage, $headpos, $imagepos);

($usrname, $mail, $bgimage, $head, $sub, $body, $linkcolor, $vlinkcolor, 
    $ahref1, $ahref2, $ahref3, $ahrefname1, $ahref2name, $ahref3name, 
    $filename, $imurl, $hrline, $emailpic, $textcolor, $bullet, $tbltext, $font, $hrline2, $emailonpage, $headpos, $imagepos) = split(/&&/, "");

$ahref1="http://";    
$ahref2="http://";
$ahref3="http://";
$textcolor="#000000";
$linkcolor="#0000ff";
$vlinkcolor="#800000";
$bullet="0";
# To avoid any security risks. Take out the HTML tags added when HPM translated
# the && to: <br><br>. They will be re-translated to: && Once the user updates
# the page, the: && will be put back to: <br><br>
$body =~ s/<br><br>/&&/g;

# print the create-page form

print "Content-type: text/html\n\n";
print "<html><head><title>Create Your Own HomePage</title></head>\n";
print $badj_css;
print $badj_body;
print $badj_header;
print $badj_seperator;
print qq~
<DIV align="center">
  <CENTER>
  <TABLE border="0" width="90%" cellspacing="0" cellpadding="0">
    <TR>
      <TD width="100%"><FONT face="verdana, helvetica, arial" size="4" color="#FF0000">Create
        your own home page</FONT>
        <P><FONT face="verdana, helvetica, arial" size="2">This web page
        creation tool is a quick and easy way of creating a simple home page.
        Fill in the form fields below to create your page. You may edit any part
        of your page later.</FONT></P>
        <HR noshade size="1">
<form action="$cgiurl/homepage.pl" method="POST">
<input type=hidden name="action" value="Create Page">
<TABLE border="0" width="100%" cellspacing="3" cellpadding="5">
          <TR>
            <TD width="100%" bgcolor="#A0BAD3"><FONT face="verdana, helvetica, arial" size="1"><B>Your
              name:<BR>
              </B>(will appear as an email link)<BR>
              </FONT><input type=text size=40 name=usrname value=$usrname><FONT face="verdana, helvetica, arial" size="1"><I>
              required</I></FONT></TD>
          </TR>
          <TR>
            <TD width="100%" bgcolor="#A0BAD3"><FONT face="verdana, helvetica, arial" size="1"><B>Login
              ID:</B><BR>
              (required for editing - must not be easy to guess, and should always be kept secret)<BR>
              </FONT><input type=text size=40 name=login value=$login><FONT face="verdana, helvetica, arial" size="1"><I>
              required</I></FONT></TD>
          </TR>
          <TR>
            <TD width="100%" bgcolor="#A0BAD3"><FONT face="verdana, helvetica, arial" size="1"><B>Email
              address</B><B>:</B><BR>
              (required for editing and appears in page - must be valid)<BR>
              </FONT><input type=text size=40 name=email value=$mail><FONT face="verdana, helvetica, arial" size="1"><I>
              required</I></FONT></TD>
          </TR>
		  	     <TR>
		  		 <TD width="100%" bgcolor="#A0BAD3"><FONT face="verdana, helvetica, arial" size="1"><B>Display email
		  		 address</B><B>:</B><BR>
		  		 (to display email address on page select yes, to hide it select no)<BR>
		  		 </FONT><INPUT type="radio" value="yes" checked name="emailonpage"><FONT face="verdana, helvetica, arial" size="1"><b> Yes&nbsp;
		  		 </b></font><INPUT type="radio" name="emailonpage" value="no"><FONT face="verdana, helvetica, arial" size="1"><b> No</b>
		  		 </FONT></TD>
         </TR>
          <TR>
            <TD width="100%" bgcolor="#A0BAD3"><FONT face="verdana, helvetica, arial" size="1"><B>File
              name:</B><BR>
              (will become the file name of your page - one word, letters and/or numbers only)<BR>
              </FONT><input type=text size=40 name=pagename value=$filename><FONT face="verdana, helvetica, arial" size="1"><I>
              required</I></FONT></TD>
          </TR>
          <TR>
            <TD width="100%" bgcolor="#A0BAD3"><FONT face="verdana, helvetica, arial" size="1"><B>Headline:</B><BR>
              (appears as the title and headline of your page, and entry in our
              index of user pages)<BR>
              </FONT><input type=text size=40 name=headline value=$head><FONT face="verdana, helvetica, arial" size="1"><I>
              required</I></FONT></TD>
          </TR>
          <TR>
            <TD width="100%" bgcolor="#A0BAD3"><FONT face="verdana, helvetica, arial" size="1"><B>Sub
              heading:<BR>
              </B>(appears beneath the headline)<BR>
              </FONT><input type=text size=40 name=subhead value=$sub></TD>
          </TR>
          <TR>
            <TD width="100%" bgcolor="#A0BAD3"><FONT face="verdana, helvetica, arial" size="1"><B>Do
              you want the headline and sub heading centered?<BR>
              </B></FONT><input type=radio name=headpos value=yes checked><FONT face="verdana, helvetica, arial" size="1"><b> Yes</b>&nbsp;
              </FONT><input type=radio name=headpos value=no><FONT face="verdana, helvetica, arial" size="1"><b> No</b></FONT></TD>
          </TR>
		  <TR>
		              <TD width="100%" bgcolor="#A0BAD3"><FONT face="verdana, helvetica, arial" size="1"><B>Text
		                font face:</B><BR>
		                (select a font face and alternatives - eg. 'verdana, helvetica,
		                arial')<BR>
		                </FONT><input type=text size=40 name=font value='verdana, helvetica, arial'></TD>
		            </TR>

~;

&build_form_body($usrname, $mail, $head, $sub, $body, $bgimage, $linkcolor, $vlinkcolor, 
        $ahref1, $ahref2, $ahref3, $ahrefname1, $ahref2name, $ahref3name,
            $filename, $imurl, $hrline, $emailpic, $textcolor, $bullet, $tbltext, $font, $hrline2, $emailonpage, $headpos, $imagepos);
print "</td></tr><TR><TD width=\"100%\" bgcolor=\"#A0BAD3\"><P><input type=submit value=\"Create Page\"><br><FONT face=\"verdana, helvetica, arial\" size=\"1\">By hitting 'Create Page' your page will be generated. If you don't like the look of your page you can edit it at any time by visiting the user pages listing and selecting 'Edit Page'\n";
print "</TD></form></TR></TABLE>\n";
print $badj_seperator;
print $badj_footer;
print "</td></tr></table></body></html>\n";
exit;
    }

sub create {

# Now, lets do some error checking. Making sure they filled out each field
# This is pretty low tech now. I'll improve it later
&missing(name) unless $usrname;
&missing(email) unless $email;
&missing(pagename) unless $pagename;
&missing(missing_name) unless $usrname;
&missing(missing_email) unless $email;
&missing(missing_pagename) unless $pagename;


 if ($FORM{'email'} =~ /\w+@\w+.\w+/) {
 $bademail = "0";
 }
else {
 $bademail = "1";
 }

if ($bademail =~ "1") {
    print "Content-type: text/html\n\n";
    print "<html><head><title>Error</title></head>\n";
print $badj_css;
print $badj_body;
#print $badj_header;
print $badj_seperator;
print "<DIV align=\"center\"><CENTER><TABLE border=\"0\" width=\"90%\" cellspacing=\"0\" cellpadding=\"0\"><TR><TD width=\"100%\">\n";
print "<P><FONT face=\"verdana, helvetica, arial\" size=\"4\" color=\"#FF0000\">\n";
print "Error</font></p>\n";
print "<p><FONT face=\"verdana, helvetica, arial\" size=\"2\">Your email address (<b>$FORM{'email'}</b>) does not appear to be valid. Please use your back button and enter a valid email address.</p>\n";
print $badj_seperator;
#print $badj_footer;
print "</td></tr></table></body></html>\n";
    exit;
        }

if ($pagename=~s/\W//g) {
    print "Content-type: text/html\n\n";
    print "<html><head><title>Error</title></head>\n";
print $badj_css;
print $badj_body;
#print $badj_header;
print $badj_seperator;
print "<DIV align=\"center\"><CENTER><TABLE border=\"0\" width=\"90%\" cellspacing=\"0\" cellpadding=\"0\"><TR><TD width=\"100%\">\n";
print "<P><FONT face=\"verdana, helvetica, arial\" size=\"4\" color=\"#FF0000\">\n";
print "Error</font></p>\n";
print "<p><FONT face=\"verdana, helvetica, arial\" size=\"2\">Only letters, numbers and underscores can be used in your file name. Please use your back button and change your file name.</p>\n";
print $badj_seperator;
#print $badj_footer;
print "</td></tr></table></body></html>\n";
    exit;
        }

# if they try to name their page "index" This will stop them
if ($pagename eq "index") {
    print "Content-type: text/html\n\n";
    print "<html><head><title>Error</title></head>\n";
print $badj_css;
print $badj_body;
#print $badj_header;
print $badj_seperator;
print "<DIV align=\"center\"><CENTER><TABLE border=\"0\" width=\"90%\" cellspacing=\"0\" cellpadding=\"0\"><TR><TD width=\"100%\">\n";
print "<P><FONT face=\"verdana, helvetica, arial\" size=\"4\" color=\"#FF0000\">\n";
print "Error</font></p>\n";
print "<p><FONT face=\"verdana, helvetica, arial\" size=\"2\">The file name 'index' can't be used. Please use your back button and rename your page!</p>\n";
print $badj_seperator;
#print $badj_footer;
print "</td></tr></table></body></html>\n";
    exit;
        }
# if they Don't give their page a heading This will stop them
if ($headline eq "") {
    print "Content-type: text/html\n\n";
    print "<html><head><title>Error</title></head>\n";
print $badj_css;
print $badj_body;
#print $badj_header;
print $badj_seperator;
print "<DIV align=\"center\"><CENTER><TABLE border=\"0\" width=\"90%\" cellspacing=\"0\" cellpadding=\"0\"><TR><TD width=\"100%\">\n";
print "<P><FONT face=\"verdana, helvetica, arial\" size=\"4\" color=\"#FF0000\">\n";
print "Error</font></p>\n";
print "<p><FONT face=\"verdana, helvetica, arial\" size=\"2\">You must enter a headline for your page. Please use your back button and enter a headline!</p>\n";
print $badj_seperator;
#print $badj_footer;
print "</td></tr></table></body></html>\n";
    exit;
        }

# if the user tries to name their page 
# something that is already taken
# this will HOPEFULLY stop them :)
# This block was written by Norm
if (-e "$page_dir$pagename\.$fileext") {
    print "Content-type: text/html\n\n";
    print "<html><head><title>Error</title></head>\n";
print $badj_css;
print $badj_body;
#print $badj_header;
print $badj_seperator;
print "<DIV align=\"center\"><CENTER><TABLE border=\"0\" width=\"90%\" cellspacing=\"0\" cellpadding=\"0\"><TR><TD width=\"100%\">\n";
print "<P><FONT face=\"verdana, helvetica, arial\" size=\"4\" color=\"#FF0000\">\n";
print "Error</font></p>\n";
print "<p><FONT face=\"verdana, helvetica, arial\" size=\"2\">The file name you selected is already taken. Please use your back button and rename your page!</p>\n";
print $badj_seperator;
#print $badj_footer;
print "</td></tr></table></body></html>\n";
    exit;
        }

#now, lets create our new html page
  &buildpage;

# Write the login name and email address to a separate file for confirmation
# when they want to edit their page
open (FILE, ">>$data") || die "I can't open $data\n";
if ($useflock) {
flock (FILE, 2) or die "can't lock data file\n";
}
print FILE "$login&&$email&&$pagename\n";
close(FILE);


################# Suck the index page, and write the new entry to it for new pages ####################
open(FILE, "$indexpage") || die "I can't open that file\n";
if ($useflock) {
flock (FILE, 1) or die "can't lock index file\n";
}
    @lines = <FILE>;
    close(FILE);
    $sizelines = @lines;

# Now, re-open the links file, and add the new link
open(FILE, ">$indexpage") || die "I can't open that file\n";
if ($useflock) {
flock (FILE, 2) or die "can't lock index file\n";
}
    
        for ($a = 0; $a <= $sizelines; $a++) {
    
        $_ = $lines[$a];

    if (/<!--begin-->/) {
    
    print FILE "<!--begin-->\n";
    print FILE "<font face=\"$myfontface\"><b><a href=\"$baseurl/$pagename.$fileext\" target=\"home\">$headline</a></b></font><br>\n";

        } else {
            print FILE $_;
        }
    }
close(FILE);


# Give the user a response

print "Content-type: text/html\n\n";
print "<html><head><title>Your page has been created</title></head>\n";
print $badj_css;
print $badj_body;
#print $badj_header;
print $badj_seperator;
print "<DIV align=\"center\"><CENTER><TABLE border=\"0\" width=\"90%\" cellspacing=\"0\" cellpadding=\"0\"><TR><TD width=\"100%\">\n";
print "<P><FONT face=\"verdana, helvetica, arial\" size=\"4\" color=\"#FF0000\">\n";
print "Your page has been created</font></p>\n";
print "<p><FONT face=\"verdana, helvetica, arial\" size=\"2\">Your page has been created, and you should receive a confirmation email.</p>\n";
print "<p>Your page URL is: <a href=\"$baseurl/$pagename\.$fileext\" target=\"home\">\n";
print "$baseurl/$pagename\.$fileext</a> - you may need to press reload / refresh in your browser to view the changes.</p>\n";
print "<p>(Return to <a href=\"$indexpageurl\">User Pages</a>)</p>\n";
print $badj_seperator;
#print $badj_footer;
print "</td></tr></table></body></html>\n";

    
################################ e-mail and response ###############################
########### Send the user an e-mail confirming their page ##########################
##### to disable mail comment from this line to where it says stop commenting here
open (MAIL, "| $sendmail -t") || die "I can't open sendmail\n";
  print MAIL "To: $usrname <$email>\n";
  print MAIL "From: $myemail\n";
  print MAIL "Subject: Your URL on $title\n";
 print MAIL "Your page can be viewed at the URL below:\n";
  print MAIL "\n";
  print MAIL "$baseurl/$pagename\.$fileext\n";
 print MAIL "\nThank you for using $title\n";
  print MAIL "\n\n$title - $myemail\n";
  close (MAIL);

################################### e-mail and response ###########################
########### Notify us when someone creates a page #################################
open (MAIL, "| $sendmail -t") || die "I can't open sendmail\n";
  print MAIL "To: $myemail\n";
  print MAIL "From: $usrname <$email>\n";
  print MAIL "Subject: New Page Report\n";
  print MAIL "$usrname created a new page:\n";
  print MAIL "$baseurl/$pagename\.$fileext\n";
  print MAIL "\nThe content is :\n$content\n";
close(MAIL);
####################### stop commenting here ########################################
exit;##### if you comment out the email, DO NOT comment this line! 
        }

sub recreate {
#now, lets create our new html page
  &buildpage;
  
################################# e-mail and response ################################
########## Send the user a notice that their page has been re-done ###################
##### to disable mail comment from this line to the next row of comments #############
  open (MAIL, "| $sendmail -t") || die "I can't open sendmail\n";
  print MAIL "To: $usrname <$email>\n";
  print MAIL "From: $myemail\n";
  print MAIL "Subject: Your Changes on $title\n";
  print MAIL "Your revised page can be viewed at the URL below:\n";
  print MAIL "\n";
  print MAIL "$baseurl/$pagename\.$fileext\n";
  print MAIL "\nOnce again thank you for using $title\n";
  print MAIL "\n\n$title - $myemail\n";
  close (MAIL);
######################################################################################
# Give the user a response
print "Content-type: text/html\n\n";
print "<html><head><title>Your page has been updated</title></head>\n";
print $badj_css;
print $badj_body;
#print $badj_header;
print $badj_seperator;
print "<DIV align=\"center\"><CENTER><TABLE border=\"0\" width=\"90%\" cellspacing=\"0\" cellpadding=\"0\"><TR><TD width=\"100%\">\n";
print "<P><FONT face=\"verdana, helvetica, arial\" size=\"4\" color=\"#FF0000\">\n";
print "Your page has been updated</font></p>\n";
print "<p><FONT face=\"verdana, helvetica, arial\" size=\"2\">Your page has been updated, and you should receive a confirmation email.</p>\n";
print "<p>Your page URL is: <a href=\"$baseurl/$pagename\.$fileext\" target=\"home\">\n";
print "$baseurl/$pagename\.$fileext</a> - you may need to press reload / refresh in your browser to view the changes.</p>\n";
print "<p>(Return to <a href=\"$indexpageurl\">HomePages</a>)</p>\n";
print $badj_seperator;
#print $badj_footer;
print "</td></tr></table></body></html>\n";

##########################################
#BILL HALL MOD
#check to see if csreeditindes is on
  if($csreeditindex){
  &csreeditentry;
  }
##########################################

exit;
        }

sub buildpage {
open(HTML, ">$page_dir$pagename\.$fileext") || die "I can't create $pagename\.$fileext\n";
if ($useflock) {
flock (HTML, 2) or die "can't lock html file\n";
}
print HTML "<html><head><title>$headline</title></head>\n";
print HTML $hp_css;
print HTML "<body ";

if ($background eq "0") {
print ""; }
else {
print HTML "background=\"$background\" ";
}

print HTML "text=$textc link=$linkc vlink=$vlinkc><font face=\"$font\">\n";
print HTML "$userpage_header\n";
print HTML "<blockquote><blockquote><blockquote>\n";
    if ($headpos eq "yes") {
    print HTML "<center>\n";
        }
print HTML "<p><font face=\"$font\" size=+7><b>$headline</b></font></br>\n";
print HTML "<font face=\"$font\" size=+2><b>$subhead</b></font></p>\n";
    if ($headpos eq "yes") {
    print HTML "</center>\n";
        }
    if ($imageyn eq "yes") {
    if ($imagepos eq "yes") {
    print HTML "<center>\n";
        }
    if (($topimage eq "0") or ($topimage eq "")) {
        print HTML "";
        }
    else  {
        print HTML "<img src=\"$topimage\">\n";
        }
    if ($imagepos eq "yes") {
    print HTML "</center>\n";
        }
    print HTML "<center>";
    if (($line2 eq "0") or ($line2 eq "")) {
        print HTML "</center>";
        } 
    else {
       print HTML "</blockquote></blockquote></blockquote><img src=\"$line2\"></center><blockquote><blockquote><blockquote>\n";
        }
    }


@atxt = split(/%%/, $content);

if ($bullet eq "0") {
  print HTML "<center>\n";
  foreach $txtline(@atxt) {
      print HTML "<p><font face=\"$font\" size=3>$txtline</font>\n";
    }
  print HTML "</center>";
  }
else {
print HTML "<table border=0 cellpadding=5>\n";
foreach $txtline (@atxt) {
  print HTML "<tr><td valign=top><img src=\"$bullet\"></td>\n";
  print HTML "<td><font face=\"$font\" size=3>$txtline</font></td></tr>\n";
  }
print HTML "</table>\n";
}

print HTML "<center>\n";
print HTML "<p><table border=1 cellspacing=3 cellpadding=3>";
@all = split(/%%/,$tbltext);
foreach $tbline (@all) {
    print HTML "<tr>";
    @flds = split(/\:\:/, $tbline);
    foreach $fld (@flds) {
        print HTML "<td>$fld</td>";
        }
    print HTML "</tr>";
    }
print HTML "</table>";
print HTML "</center>";

if ($bullet eq "0") {
  print HTML "<center>\n";
  }
  
  $togo = $linkname1.$linkname2.$linkname3;
  $tourl = $usrlink1.$usrlink2.$usrlink3;
  if (($togo eq "") or $tourl eq "http://http://http://") {
          print HTML "";
          } 
      else {
     print HTML "<p><i><font face=\"$font\" size=4><b>Other Places to go:</i></b></font></p>\n";
   print HTML "<p><font face=\"$font\" size=3><a href=\"$usrlink1\">$linkname1</a><br>\n";
print HTML "<a href=\"$usrlink2\">$linkname2</a><br>\n";
print HTML "<a href=\"$usrlink3\">$linkname3</a></font></p>\n";
      }
if ($bullet eq "0") {
  print HTML "</center>\n";
  }

print HTML "<center>";
if (($anotherline eq "0") or ($anotherline eq "")) {
print HTML "";
    } else {
print HTML "</blockquote></blockquote></blockquote><img src=\"$anotherline\"></center><blockquote><blockquote><blockquote>\n";
    }
print HTML "<p><center>";

if ($emailonpage eq "yes") {
     if ($emailgif eq "0") {
print ""; }
     else {
	print HTML "<img src=\"$emailgif\"><br>\n";
    }
print HTML "<font face=\"$font\" size=3>Email: <a href=\"mailto:$email\">$usrname</a></font></center></p>\n";
}
print HTML "<p><center><font face=\"$font\" size=2>";
print HTML "$copyright_notice</b></a></font>";
print HTML "</blockquote></blockquote></blockquote>\n";
print HTML "</center></body></html>";

close(HTML);


# Write all of the input into a flat file.
open(FILE, ">$page_dir$pagename\.dat") || die "I can't create $pagename\.dat\n";
if ($useflock) {
flock (FILE, 2) or die "can't lock user data file\n";
}
$tbltext =~ s/\n/%%/g;
print FILE "$usrname&&$email&&$background&&$headline&&$subhead&&$content&&$linkc&&$vlinkc&&$usrlink1&&$usrlink2&&$usrlink3&&$linkname1&&$linkname2&&$linkname3&&$pagename&&$topimage&&$line2&&$emailgif&&$textc&&$bullet&&$tbltext&&$font&&$anotherline&&$emailonpage&&$headpos&&$imagepos\n";
close(FILE);
chmod 0777, '$page_dir$pagename.dat';
}

################### Standard error message for any missing required fields #################################
sub missing {
local ($missing) = @_;

    print "Content-type: text/html\n\n";
    print "<html><head><title>Error</title></head>\n";
print $badj_css;
print $badj_body;
#print $badj_header;
print $badj_seperator;
print "<DIV align=\"center\"><CENTER><TABLE border=\"0\" width=\"90%\" cellspacing=\"0\" cellpadding=\"0\"><TR><TD width=\"100%\">\n";
print "<P><FONT face=\"verdana, helvetica, arial\" size=\"4\" color=\"#FF0000\">\n";
print "Error</font></p>\n";
print "<p><FONT face=\"verdana, helvetica, arial\" size=\"2\">You forgot to fill in one or more required fields. Please use your back button and fill them in!</p>\n";
print "<p><FONT face=\"verdana, helvetica, arial\" size=\"2\">Missing field: $missing</p>\n";
print $badj_seperator;
#print $badj_footer;
print "</td></tr></table></body></html>\n";

    exit;
        
}

sub confirm {
    local ($updact) = @_;

print "Content-type: text/html\n\n";
print "<html><head><title>$updact Login</title></head>\n";
print $badj_css;
print $badj_body;
print $badj_header;
print $badj_seperator;
print "<DIV align=\"center\"><CENTER><TABLE border=\"0\" width=\"90%\" cellspacing=\"0\" cellpadding=\"0\"><TR><TD width=\"100%\">\n";
print "<P><FONT face=\"verdana, helvetica, arial\" size=\"4\" color=\"#FF0000\">\n";
print "Login</font></p>\n";
print "<p><FONT face=\"verdana, helvetica, arial\" size=\"2\">Please Enter your login name, e-mail and name of your file to <b>$updact</b></p>\n";
print "<form action=\"$cgiurl/homepage.pl\" method=POST>\n";
print "<TABLE border=\"0\" width=\"100%\" cellspacing=\"3\" cellpadding=\"5\"><TR><TD width=\"100%\" bgcolor=\"#A0BAD3\"><FONT face=\"verdana, helvetica, arial\" size=\"1\">\n";
print "<b>Login name:</b><br></font>\n";
print "<input size=40 type=text name=\"login\">\n";
print "</td></tr><TR><TD width=\"100%\" bgcolor=\"#A0BAD3\"><FONT face=\"verdana, helvetica, arial\" size=\"1\"><b>E-mail:</b><br></font>\n";
print "<input size=40 type=text name=\"email\">\n";
print "</td></tr><TR><TD width=\"100%\" bgcolor=\"#A0BAD3\"><FONT face=\"verdana, helvetica, arial\" size=\"1\"><b>Name of your file:</b><br></font>\n";
print "<input type=text size=40 name=\"pagename\">\n";
print "</td></tr><TR><TD width=\"100%\" bgcolor=\"#A0BAD3\"><input type=\"submit\" value=\"Login\">\n";
print "<input type=hidden name=\"action\" value=\"checkuser\">\n";
print "<input type=hidden name=\"updact\" value=\"$updact\">\n";
print "</FONT></td></form></tr></table>\n";
print $badj_seperator;
print $badj_footer;
print "</td></tr></table></body></html>\n";
exit;
    }

sub checkuser {
open(FILE, "$data") || die "I can't open $data\n";  
if ($useflock) {
flock (FILE, 1) or die "can't lock data file\n";
}

    while(<FILE>) {
    chop;       
    @all = split(/\n/);

    foreach $line (@all) {
    ($loginname, $loginemail, $loginpagename) = split(/&&/, $line);
    if($loginname eq "$login" && $loginemail eq "$email" && $loginpagename eq "$pagename") {
        $match = 1;
        if($updact eq "edit") {
          &edit($loginpagename);
          }
        else {
          &delpage($loginpagename);
          }
        }
      }
	}

close(FILE);

if (! $match) {
    &error;
    }

# del entry from data
if($updact eq "delete") {

    # Suck the index page, and write the new entry to it
    open(FILE, "$data") || die "I can't open that file\n";
    if ($useflock) {
	flock (FILE, 1) or die "can't lock data file\n";
	}
        @lines = <FILE>;
        close(FILE);
        $sizelines = @lines;

    # Now, re-open the links file, and comment out the page to delete
    open(FILE, ">$data") || die "I can't open that file\n";
    if ($useflock) {
	flock (FILE, 2) or die "can't lock index file for append\n";
	}
    chop;
            for ($a = 0; $a <= $sizelines; $a++) {
            $_ = $lines[$a];
            $w = $_;
            $w =~ s/\cM//g;
            $w =~ s/\n//g;
    ($loginname, $loginemail, $loginpagename) = split(/&&/, $w);
    if($loginname eq "$login" && $loginemail eq "$email" && $loginpagename eq "$pagename") {
          # do nothing  (ie. don't write)
          } 
        else {
          if($w eq "") {
            # do nothing (skip)
            }
          else {
            print FILE "$w\n";
            }
          }
        }
    close(FILE);
    print "Content-type: text/html\n\n";
    print "<html><head><title>$updact Confirmation</title></head>\n";
    print $badj_css;
print $badj_body;
	#print $badj_header;
	print $badj_seperator;
	print "<DIV align=\"center\"><CENTER><TABLE border=\"0\" width=\"90%\" cellspacing=\"0\" cellpadding=\"0\"><TR><TD width=\"100%\">\n";
    print "<P><FONT color=\"#FF0000\">\n";
    print "Your page has been deleted</font></p>\n";
    print "<p>(Return to <a href=\"$indexpageurl\">User Pages</a>)</p>\n";
    print $badj_seperator;
	#print $badj_footer;
	print "</td></tr></table>\n";
    print "</form></body></html>\n";
  }
  exit;
}
########################### Modified checkuser by bigmike at bigmike@bigmikesmedia.com ###############
sub checkuser2 {
open(FILE, "$data") || die "I can't open $data\n";  
if ($useflock) {
flock (FILE, 1) or die "can't lock data file\n";
}

    while(<FILE>) {
    chop;       
    @all = split(/\n/);

    foreach $line (@all) {
    ($loginname, $loginemail, $loginpagename) = split(/&&/, $line);
    if($loginpagename eq "$pagename") {
        $match = 1;
        if($updact eq "edit") {
          &edit($loginpagename);
          }
        else {
          &delpage($loginpagename);
          }
        }
      }
	}

close(FILE);

if (! $match) {
    &error;
    }

# del entry from data
if($updact eq "delete") {

    # Suck the index page, and write the new entry to it
    open(FILE, "$data") || die "I can't open that file\n";
    if ($useflock) {
	flock (FILE, 1) or die "can't lock data file\n";
	}
        @lines = <FILE>;
        close(FILE);
        $sizelines = @lines;

    # Now, re-open the links file, and comment out the page to delete
    open(FILE, ">$data") || die "I can't open that file\n";
    if ($useflock) {
	flock (FILE, 2) or die "can't lock index file for append\n";
	}
    chop;
            for ($a = 0; $a <= $sizelines; $a++) {
            $_ = $lines[$a];
            $w = $_;
            $w =~ s/\cM//g;
            $w =~ s/\n//g;
    ($loginname, $loginemail, $loginpagename) = split(/&&/, $w);
    if($loginpagename eq "$pagename") {
          # do nothing  (ie. don't write)
          } 
        else {
          if($w eq "") {
            # do nothing (skip)
            }
          else {
            print FILE "$w\n";
            }
          }
        }
    close(FILE);
    print "Content-type: text/html\n\n";
    print "<html><head><title>$updact Confirmation</title></head>\n";
    print $badj_css;
print $badj_body;
	#print $badj_header;
	print $badj_seperator;
	print "<DIV align=\"center\"><CENTER><TABLE border=\"0\" width=\"90%\" cellspacing=\"0\" cellpadding=\"0\"><TR><TD width=\"100%\">\n";
    print "<P><FONT color=\"#FF0000\">\n";
    print "Your page has been deleted</font></p>\n";
    print "<p>(Return to <a href=\"$indexpageurl\">HomePages</a>)</p>\n";
    print $badj_seperator;
	#print $badj_footer;
	print "</td></tr></table>\n";
    print "</form></body></html>\n";
  }
  exit;
}
####################### End Modified checkuser by bigmike ###################
sub edit {

    local ($editfile) = @_;
    
    open(FILE, "$page_dir$editfile\.dat") || die "I can't open $editfile\n";
    if ($useflock) {
	flock (FILE, 1) or die "can't lock data file for edit\n";
	}

    while(<FILE>) {
    chop;
    @datafile = split(/\n/);

    foreach $line (@datafile) {
        &build_edit_form($line);
            }
         }
    close(FILE);
    }

sub delpage {
    local ($editfile) = @_;
    $cnt=unlink "$page_dir$editfile\.dat", "$page_dir$editfile\.$fileext";

    # Suck the index page, and write the new entry to it
    open(FILE, "$indexpage") || die "I can't open that file\n";
    if ($useflock) {
	flock (FILE, 1) or die "can't lock index file\n";
	}
        @lines = <FILE>;
        close(FILE);
        $sizelines = @lines;

    # Now, re-open the links file, and comment out the page to delete
    open(FILE, ">$indexpage") || die "I can't open that file\n";
    if ($useflock) {
	flock (FILE, 2) or die "can't lock index file to delete entry\n";
	}

            for ($a = 0; $a <= $sizelines; $a++) {

            $_ = $lines[$a];

        if (/$pagename.$fileext/) {
          # do nothing  (ie. don't write)
          } 
        else {
          print FILE $_;
           }
        }
    close(FILE);
	
   }


##############################################################
# Bill Hall mod - this re-edits the index page when a user
# page is edited and changes the title
# Thanks Bill!

sub csreeditentry {
    local ($editfile) = @_;
    # Suck the index page, and write the new entry to it
    open(FILE, "$indexpage") || die "I can't open that file\n";

    if ($useflock) {
    flock (FILE, 1) or die "can't lock index file\n";
    }
	
        @lines = <FILE>;
        close(FILE);
        $sizelines = @lines;

    # Now, re-open the links file, and comment out the page to delete
	open(FILE, ">$indexpage") || die "I can't open that file\n";
	if ($useflock) {
    flock (FILE, 2) or die "can't lock index file to delete entry\n";
	}

            for ($a = 0; $a <= $sizelines; $a++) {

            $_ = $lines[$a];

        if (/$pagename.$fileext/) {
          # do nothing  (ie. don't write)
          } 
        else {
          print FILE $_;
           }
        }
    close(FILE);
########################## Suck the index page, and write the new entry to it for edited pages #############
 open(FILE, "$indexpage") || die "I can't open that file\n";
 if ($useflock) {
 flock (FILE, 1) or die "can't lock index file\n";
 }
    @lines = <FILE>;
    close(FILE);
    $sizelines = @lines;

# Now, re-open the links file, and add the new link
 open(FILE, ">$indexpage") || die "I can't open that file\n";
 if ($useflock) {
 flock (FILE, 2) or die "can't lock index file\n";
 }
    
        for ($a = 0; $a <= $sizelines; $a++) {
    
        $_ = $lines[$a];

    if (/<!--begin-->/) {
    
    print FILE "<!--begin-->\n";
#    if($usesthumbs)&&($thumbimage ne "")&&($thumbimage ne "0")) {
#    print FILE "<p><font face=\"Arial, Geneva\" size=4><a href=\"$baseurl/$pagename.html\">$headline</a></p>\n";
#    print FILE "<p><font face=\"Arial, Geneva\" size=4><a href=\"$baseurl/$pagename.html\"><IMG SRC=\"$thumbimage\" ALT=\"$pagename $headline\" ></a></p>\n";
#    }else{
    print FILE "<font face=\"$myfontface\"><b><a href=\"$baseurl/$pagename.$fileext\" target=\"home\">$headline</a></font></b><br>\n";
#    }

    
        } else {
            print FILE $_;
        }
    }
 close(FILE);
     

###############################


sub build_edit_form($line) {
    local ($line) = @_;
    local($fullname, $mail, $head, $sub, $body, $bgimage, $linkcolor, $vlinkcolor, 
        $ahref1, $ahref2, $ahref3, $ahrefname1, $ahref2name, $ahref3name,
            $filename, $imurl, $hrline, $emailpic, $textcolor, $bullet, $tbltext, $font, $hrline2, $emailonpage, $headpos, $imagepos);

($fullname, $mail, $bgimage, $head, $sub, $body, $linkcolor, $vlinkcolor, $ahref1, $ahref2,
 $ahref3, $ahrefname1, $ahref2name, $ahref3name, $filename, $imurl, $hrline, $emailpic, 
 $textcolor, $bullet, $tbltext, $font, $hrline2, $emailonpage, $headpos, $imagepos) = split(/&&/, $line);
    
# To avoid any security risks. Take out the HTML tags added when HPM translated
# the && to: <br><br>. They will be re-translated to: && Once the user updates
# the page, the: && will be put back to: <br><br>
$body =~ s/<br><br>/&&/g;

# print the edit-page form


print "Content-type: text/html\n\n";
print "<html><head><title>Edit your home page</title></head>\n";
print $badj_css;
print $badj_body;
print $badj_header;
print $badj_seperator;
print qq~
<DIV align="center">
  <CENTER>
  <TABLE border="0" width="90%" cellspacing="0" cellpadding="0">
    <TR>
      <TD width="100%"><FONT face="verdana, helvetica, arial" size="4" color="#FF0000">Edit your home page</FONT>
        <P><FONT face="verdana, helvetica, arial" size="2">To edit your home page change the necessary elements below.</FONT></P>
        <HR noshade size="1">
<form action="$cgiurl/homepage.pl" method="POST">
<input type=hidden name="action" value="recreate">
<TABLE border="0" width="100%" cellspacing="3" cellpadding="5">
          <TR>
            <TD width="100%" bgcolor="#A0BAD3"><FONT face="verdana, helvetica, arial" size="1"><B>Your
              name:<BR>
              </B>(will appear as an email link)<BR>
              </FONT><input type=text size=40 name=usrname value="$fullname"><FONT face="verdana, helvetica, arial" size="1"><I>
              required</I></FONT></TD>
          </TR>
          <TR>
            <TD width="100%" bgcolor="#A0BAD3"><FONT face="verdana, helvetica, arial" size="1"><B>Email
              address</B><B>:</B><BR>
              (required for editing and appears in page - must be valid)<BR>
              </FONT><input type=text size=40 name=email value="$mail"><FONT face="verdana, helvetica, arial" size="1"><I>
              required</I></FONT></TD>
          </TR>
		  
		  
	     <TR>
		 <TD width="100%" bgcolor="#A0BAD3"><FONT face="verdana, helvetica, arial" size="1"><B>Display email
		 address</B><B>:</B><BR>
		 (to display email address on page select yes, to hide it select no)<BR>
		 </FONT><INPUT type="radio" value="yes" name="emailonpage"
~;
		 
if ($emailonpage eq "yes") {print "checked";}
		 
print qq~
		 ><FONT face="verdana, helvetica, arial" size="1"><b> Yes&nbsp;
		 </b></font><INPUT type="radio" name="emailonpage" value="no"
~;
		 
if ($emailonpage eq "no") {print "checked";}
		 
print qq~
		 ><FONT face="verdana, helvetica, arial" size="1"><b> No</b>
		 </FONT></TD>
         </TR>
		 
		  
		  <TR>
		  <TD width="100%" bgcolor="#A0BAD3"><FONT face="verdana, helvetica, arial" size="1"><B>Filename
		  of page:</B> $filename</FONT></TD>
          </TR>
          <TR>
            <TD width="100%" bgcolor="#A0BAD3"><FONT face="verdana, helvetica, arial" size="1"><B>Headline:</B><BR>
              (appears as the title and headline of your page, and entry in our
              index of user pages)<BR>
              </FONT><input type=text size=40 name=headline value="$head"><FONT face="verdana, helvetica, arial" size="1"><I>
              required</I></FONT></TD>
          </TR>
          <TR>
            <TD width="100%" bgcolor="#A0BAD3"><FONT face="verdana, helvetica, arial" size="1"><B>Sub
              heading:<BR>
              </B>(appears beneath the headline)<BR>
              </FONT><input type=text size=40 name=subhead value="$sub"></TD>
          </TR>
          <TR><input type=hidden name="pagename" value="$filename">
            <TD width="100%" bgcolor="#A0BAD3"><FONT face="verdana, helvetica, arial" size="1"><B>Do
              you want the headline and sub heading centered?<BR>
              </B></FONT><input type="radio" name="headpos" value="yes"
~;
		 
if ($headpos eq "yes") {print "checked";}
		 
print qq~
			  ><FONT face="verdana, helvetica, arial" size="1"><b> Yes</b>&nbsp;
              </FONT><input type="radio" name="headpos" value="no"
~;
		 
if ($headpos eq "no") {print "checked";}
		 
print qq~
			  ><FONT face="verdana, helvetica, arial" size="1"><b> No</b></FONT></TD>
          </TR>
		  <TR>
		              <TD width="100%" bgcolor="#A0BAD3"><FONT face="verdana, helvetica, arial" size="1"><B>Text
		                font face:</B><BR>
		                (select a font face and alternatives - eg. 'verdana, helvetica,
		                arial')<BR>
		                </FONT><input type=text size=40 name="font" value="$font"></TD>
		            </TR>


~;

&build_form_body($fullname, $mail, $head, $sub, $body, $bgimage, $linkcolor, $vlinkcolor, 
        $ahref1, $ahref2, $ahref3, $ahrefname1, $ahref2name, $ahref3name,
            $filename, $imurl, $hrline, $emailpic, $textcolor, $bullet, $tbltext, $font, $hrline2, $emailonpage, $headpos, $imagepos);
print "</td></tr><TR><TD width=\"100%\" bgcolor=\"#A0BAD3\"><P><input type=submit value=\"Update Page\"><br><FONT face=\"verdana, helvetica, arial\" size=\"1\">By hitting 'Create Page' your page will be generated. If you don't like the look of your page you can edit it at any time by visiting the user pages listing and selecting 'Edit Page'\n";
print "</TD></form></TR></TABLE>\n";
print $badj_seperator;
print $badj_footer;
print "</td></tr></table></body></html>\n";
    
    }

sub build_form_body {
($fullname, $mail, $head, $sub, $body, $bgimage, $linkcolor, $vlinkcolor, 
$ahref1, $ahref2, $ahref3, $ahrefname1, $ahref2name, $ahref3name,
            $filename, $imurl, $hrline, $emailpic, $textcolor, $bullet, $tbltext, $font, $hrline2, $emailonpage, $headpos, $imagepos) = @_;

print "<TR><TD width=\"100%\" bgcolor=\"#A0BAD3\"><p><FONT face=\"verdana, helvetica, arial\" size=\"1\"><B>Splash graphic:</b><br>(displayed directly below sub heading)</font></p>\n";
      opendir (TN, "$tnp_dir");
      rewinddir (TN);
      @tnlist =  grep(!/^\.\.?$/, readdir (TN));
      closedir (TN);

   $tnnum = @tnlist;
   $cnum = "0";
   print "<p><input type=radio name=\"topimage\" value=\"0\" checked><FONT face=\"verdana, helvetica, arial\" size=\"1\"><b>No graphic</b></a></font></p>\n";
   $lend = "0";   
while ($tnnum > $cnum) {
   print "<input type=radio name=\"topimage\" value=\"$tnp_dir_url/$tnlist[$cnum]\"";
   if ($imurl eq "$tnp_dir_url/$tnlist[$cnum]") {print " checked";}
   print "><img src=\"$tnp_dir_url/$tnlist[$cnum]\" border=0>\n";
   $cnum = $cnum + 1;
   $lend = $lend + 1;
   if ($lend eq "4"){
   print "<br><br>\n";
   $lend = 0;
    }
   }
print "<p><FONT face=\"verdana, helvetica, arial\" size=\"1\"><b>Do you want the image centered?</b></font><br><input type=radio name=\"imagepos\" value=\"yes\"";
if ($imagepos eq "no") {print "";} else {print " checked";}
print "><FONT face=\"verdana, helvetica, arial\" size=\"1\">Yes&nbsp;&nbsp;</font>\n";
print "<input type=radio name=\"imagepos\" value=\"no\"";
if ($imagepos eq "no") {print " checked";}
print "><FONT face=\"verdana, helvetica, arial\" size=\"1\">No</font></p></td></tr>\n";
print "<TR><TD width=\"100%\" bgcolor=\"#A0BAD3\"><p><FONT face=\"verdana, helvetica, arial\" size=\"1\"><b>Body:</b><br>(press return once to start a new line, press it twice to start a new paragraph)</font><br>\n";

#########################################
# NOW TURN <BR>s and %%s back into \n s
$body=~s/%%/\n\n/g;
$body=~s/<br>/\n/g;
#########################################

print "<textarea cols=65 rows=6 wrap=on name=\"content\">$body</textarea></td></tr>\n";
#print << 'END'
#<tr><TD width="100%" bgcolor="#A0BAD3"><p><FONT face="verdana, helvetica, arial" size="1"><b>Table (optional):</b><br>(a table can be used to present information such as dates or finances - to start a new cell use two colons (<b>::</b>), to create a new row start a new line by pressing return) For example:</font></br>
#<pre>
#su :: mo :: tu :: we :: th :: fr :: sa
#   ::    ::    ::  1 ::  2 ::  3 ::  4
# 5 ::  6 ::  7 ::  8 ::  9 :: 10 :: 11
#12 :: 13 :: 14 :: 15 :: 16 :: 17 :: 18 etc...
#</pre>
#<FONT face="verdana, helvetica, arial" size="1">(type &amp;nbsp; to render an empty cell)<br>
#END
#;
#
#$tbltext =~ s/%%/\n%%/g;
#
#########################################
# NOW TURN %%s back into \n s
#$tbltext=~s/%%/\n/g;
#########################################
#
#print "<textarea cols=65 rows=6 wrap=on name=\"tbltext\">$tbltext</textarea></p></td></tr>";

print "<TR><TD width=\"100%\" bgcolor=\"#A0BAD3\"><p><FONT face=\"verdana, helvetica, arial\" size=\"1\"><B>Links:</b><br>(links to other web sites)</font></p>\n";
print "<table width=75% cellpadding=2 cellspacing=2 border=0>\n";
print "<tr><td width=50% align=left valign=top>\n";
print "<p><FONT face=\"verdana, helvetica, arial\" size=\"1\">Link 1 URL:<br></font>\n";
print "<input type=text size=40 name=\"usrlink1\" value=\"$ahref1\"></p>\n";
print "<p><FONT face=\"verdana, helvetica, arial\" size=\"1\">Link 2 URL:<br></font>\n";
print "<input type=text size=40 name=\"usrlink2\" value=\"$ahref2\"></p>\n";
print "<p><FONT face=\"verdana, helvetica, arial\" size=\"1\">Link 3 URL:<br></font>\n";
print "<input type=text size=40 name=\"usrlink3\" value=\"$ahref3\"></p>\n";
print "</td>\n";
print "<td width=50% align=left valign=top>\n";
print "<p><FONT face=\"verdana, helvetica, arial\" size=\"1\">Link 1 name:<br></font>\n";
print "<input type=text size=40 name=\"linkname1\" value=\"$ahrefname1\"></p>\n";
print "<p><FONT face=\"verdana, helvetica, arial\" size=\"1\">Link 2 name:<br></font>\n";
print "<input type=text size=40 name=\"linkname2\" value=\"$ahref2name\"></p>\n";
print "<p><FONT face=\"verdana, helvetica, arial\" size=\"1\">Link 3 name:<br></font>\n";
print "<input type=text size=40 name=\"linkname3\" value=\"$ahref3name\"></p>\n";
print "</td></tr></table></td></tr>\n";
print "<TR><TD width=\"100%\" bgcolor=\"#A0BAD3\"><p><FONT face=\"verdana, helvetica, arial\" size=\"1\"><B>Text colour:</b><br>(sets the page text colour)</font><br>\n";
print "<input type=radio name=\"textc\" value=\"#000000\"";
    if ($textcolor eq "#000000") {print " checked";}
    print "><FONT face=\"verdana, helvetica, arial\" size=\"1\" color=\"#000000\"><B>Black</b></font>\n";
print "<input type=radio name=\"textc\" value=\"#800000\"";
    if ($textcolor eq "#800000") {print " checked";}
    print "><FONT face=\"verdana, helvetica, arial\" size=\"1\" color=\"#800000\"><B>Maroon</b></font>\n";
print "<input type=radio name=\"textc\" value=\"#ff0000\"";
    if ($textcolor eq "#ff0000") {print " checked";}
    print "><FONT face=\"verdana, helvetica, arial\" size=\"1\" color=\"#ff0000\"><B>Red</b></font>\n";
print "<input type=radio name=\"textc\" value=\"#ffff00\"";
    if ($textcolor eq "#ffff00") {print " checked";}
    print "><FONT face=\"verdana, helvetica, arial\" size=\"1\" color=\"#ffff00\"><B>Yellow</b></font>\n";
print "<input type=radio name=\"textc\" value=\"#00ff00\"";
    if ($textcolor eq "#00ff00") {print " checked";}
    print "><FONT face=\"verdana, helvetica, arial\" size=\"1\" color=\"#00ff00\"><B>Green</b></font>\n";
print "<input type=radio name=\"textc\" value=\"#ffffff\"";
    if ($textcolor eq "#ffffff") {print " checked";}
    print "><FONT face=\"verdana, helvetica, arial\" size=\"1\" color=\"#ffffff\"><B>White</b></font>\n";
print "<input type=radio name=\"textc\" value=\"#0000ff\"";
    if ($textcolor eq "#0000ff") {print " checked";}
    print "><FONT face=\"verdana, helvetica, arial\" size=\"1\" color=\"#0000ff\"><B>Blue</b></font></p></td></tr>\n";
print "<TR><TD width=\"100%\" bgcolor=\"#A0BAD3\"><p><FONT face=\"verdana, helvetica, arial\" size=\"1\"><B>Link colour:</b><br>(sets the link colour)</font><br>\n";
print "<input type=radio name=\"linkc\" value=\"#000000\"";
    if ($linkcolor eq "#000000") {print " checked";}
    print "><FONT face=\"verdana, helvetica, arial\" size=\"1\" color=\"#000000\"><B>Black</b></font>\n";
print "<input type=radio name=\"linkc\" value=\"#800000\"";
    if ($linkcolor eq "#800000") {print " checked";}
    print "><FONT face=\"verdana, helvetica, arial\" size=\"1\" color=\"#800000\"><B>Maroon</b></font>\n";
print "<input type=radio name=\"linkc\" value=\"#ff0000\"";
    if ($linkcolor eq "#ff0000") {print " checked";}
    print "><FONT face=\"verdana, helvetica, arial\" size=\"1\" color=\"#ff0000\"><B>Red</b></font>\n";
print "<input type=radio name=\"linkc\" value=\"#ffff00\"";
    if ($linkcolor eq "#ffff00") {print " checked";}
    print "><FONT face=\"verdana, helvetica, arial\" size=\"1\" color=\"#ffff00\"><B>Yellow</b></font>\n";
print "<input type=radio name=\"linkc\" value=\"#00ff00\"";
    if ($linkcolor eq "#00ff00") {print " checked";}
    print "><FONT face=\"verdana, helvetica, arial\" size=\"1\" color=\"#00ff00\"><B>Green</b></font>\n";
print "<input type=radio name=\"linkc\" value=\"#ffffff\"";
    if ($linkcolor eq "#ffffff") {print " checked";}
    print "><FONT face=\"verdana, helvetica, arial\" size=\"1\" color=\"#ffffff\"><B>White</b></font>\n";
print "<input type=radio name=\"linkc\" value=\"#0000ff\"";
    if ($linkcolor eq "#0000ff") {print " checked";}
    print "><FONT face=\"verdana, helvetica, arial\" size=\"1\" color=\"#0000ff\"><B>Blue</b></font></p></td></tr>\n";
print "<TR><TD width=\"100%\" bgcolor=\"#A0BAD3\"><p><FONT face=\"verdana, helvetica, arial\" size=\"1\"><B>Visited link colour:</b><br>(sets the visited link colour)</font><br>\n";
print "<input type=radio name=\"vlinkc\" value=\"#000000\"";
    if ($vlinkcolor eq "#000000") {print " checked";}
    print "><FONT face=\"verdana, helvetica, arial\" size=\"1\" color=\"#000000\"><B>Black</b></font>\n";
print "<input type=radio name=\"vlinkc\" value=\"#800000\"";
    if ($vlinkcolor eq "#800000") {print " checked";}
    print "><FONT face=\"verdana, helvetica, arial\" size=\"1\" color=\"#800000\"><B>Maroon</b></font>\n";
print "<input type=radio name=\"vlinkc\" value=\"#ff0000\"";
    if ($vlinkcolor eq "#ff0000") {print " checked";}
    print "><FONT face=\"verdana, helvetica, arial\" size=\"1\" color=\"#ff0000\"><B>Red</b></font>\n";
print "<input type=radio name=\"vlinkc\" value=\"#ffff00\"";
    if ($vlinkcolor eq "#ffff00") {print " checked";}
    print "><FONT face=\"verdana, helvetica, arial\" size=\"1\" color=\"#ffff00\"><B>Yellow</b></font>\n";
print "<input type=radio name=\"vlinkc\" value=\"#00ff00\"";
    if ($vlinkcolor eq "#00ff00") {print " checked";}
    print "><FONT face=\"verdana, helvetica, arial\" size=\"1\" color=\"#00ff00\"><B>Green</b></font>\n";
print "<input type=radio name=\"vlinkc\" value=\"#ffffff\"";
    if ($vlinkcolor eq "#ffffff") {print " checked";}
    print "><FONT face=\"verdana, helvetica, arial\" size=\"1\" color=\"#ffffff\"><B>White</b></font>\n";
print "<input type=radio name=\"vlinkc\" value=\"#0000ff\"";
    if ($vlinkcolor eq "#0000ff") {print " checked";}
    print "><FONT face=\"verdana, helvetica, arial\" size=\"1\" color=\"#0000ff\"><B>Blue</b></font></p></td></tr>\n";

print "<TR><TD width=\"100%\" bgcolor=\"#A0BAD3\"><p><FONT face=\"verdana, helvetica, arial\" size=\"1\"><B>Background:</b><br>(sets the appearance of the page background)</font></p>\n";
      opendir (TN, "$tnbg_dir");
      rewinddir (TN);
      @tnlist =  grep(!/^\.\.?$/, readdir (TN));
      closedir (TN);

   $tnnum = @tnlist;
   $cnum = "0";
   print "<p><input checked type=radio name=\"background\" value=\"0\"";
   if ($line2 eq "0") { print " checked";}
   print "><FONT face=\"verdana, helvetica, arial\" size=\"1\"><b>No background (selects browser default)</b></font></p>\n";
   while ($tnnum > $cnum) {
      print "<p><input type=radio name=\"background\" value=\"$tnbg_dir_url/$tnlist[$cnum]\"" ;
      if ($bgimage eq "$tnbg_dir_url/$tnlist[$cnum]") {print " checked";}
	  print "><TABLE border=\"0\" width=\"70%\" background=\"$tnbg_dir_url/$tnlist[$cnum]\" height=\"50\" cellspacing=\"0\" cellpadding=\"0\"><TR><TD width=\"100%\">&nbsp;</TD></TR></TABLE>\n";
	  
#      print "><img src=\"$tnbg_dir_url/$tnlist[$cnum]\" border=1></p>\n";
      $cnum = $cnum + 1;
      print "\n";
   }
print "</td></tr><TR><TD width=\"100%\" bgcolor=\"#A0BAD3\"><p><FONT face=\"verdana, helvetica, arial\" size=\"1\"><b>First horizontal line:</b><br>(sets the appearance of the first horizontal line)</font></p>\n";
      opendir (TN, "$tn_dir");
      rewinddir (TN);
      @tnlist =  grep(!/^\.\.?$/, readdir (TN));
      closedir (TN);

   $tnnum = @tnlist;
   $cnum = "0";
      print "<p><input checked type=radio name=\"line\" value=\"0\"";
      if ($line2 eq "0") { print " checked";}
      print "><FONT face=\"verdana, helvetica, arial\" size=\"1\"><b>No first line</b></font></a></p>\n";
   while ($tnnum > $cnum) {
      print "<p><input type=radio name=\"line\" value=\"$tn_dir_url/$tnlist[$cnum]\"";
      if ($hrline eq "$tn_dir_url/$tnlist[$cnum]") {print "checked";}
      print "><img src=\"$tn_dir_url/$tnlist[$cnum]\" border=0>\n";
      $cnum = $cnum + 1;
      print "</p>\n";
   }
   
print "</td></tr><TR><TD width=\"100%\" bgcolor=\"#A0BAD3\"><p><FONT face=\"verdana, helvetica, arial\" size=\"1\"><b>Second horizontal line:</b><br>(sets the appearance of the second horizontal line)</font></p>\n";
      opendir (TN, "$tn_dir");
      rewinddir (TN);
      @tnlist =  grep(!/^\.\.?$/, readdir (TN));
      closedir (TN);

   $tnnum = @tnlist;
   $cnum = "0";
      print "<p><input checked type=radio name=\"anotherline\" value=\"0\"";
      if ($anotherline eq "0") { print " checked";}
      print "><FONT face=\"verdana, helvetica, arial\" size=\"1\"><b>No second line</b></font></p>\n";
   while ($tnnum > $cnum) {
      print "<p><input type=radio name=\"anotherline\" value=\"$tn_dir_url/$tnlist[$cnum]\"";
      if ($hrline2 eq "$tn_dir_url/$tnlist[$cnum]") {print "checked";}
      print "><img src=\"$tn_dir_url/$tnlist[$cnum]\" border=0>\n";
      $cnum = $cnum + 1;
      print "</p>\n";
   }

print "</td></tr><TR><TD width=\"100%\" bgcolor=\"#A0BAD3\"><p><FONT face=\"verdana, helvetica, arial\" size=\"1\"><b>Bullet:</b><br>(sets the appearance of bullets used to separate paragraphs of main body text)</font></p>\n";
      opendir (TN, "$tnb_dir");
      rewinddir (TN);
      @tnlist =  grep(!/^\.\.?$/, readdir (TN));
      closedir (TN);

   $tnnum = @tnlist;
   $cnum = "0";
   print "<p><input checked type=radio name=\"bullet\" value=\"0\"";
   if($bullet eq "0") {print "checked";}
   print "><FONT face=\"verdana, helvetica, arial\" size=\"1\"><b>No bullet (all text will be centered)</b></a></p>\n";
   $lend = "0";   
while ($tnnum > $cnum) {
      print "<input type=radio name=\"bullet\" value=\"$tnb_dir_url/$tnlist[$cnum]\"";
      if ($bullet eq "$tnb_dir_url/$tnlist[$cnum]") {print "checked";}
      print "><img src=\"$tnb_dir_url/$tnlist[$cnum]\" border=0></a>&nbsp;&nbsp;\n";
      $cnum = $cnum + 1;
    $lend = $lend + 1;
      if ($lend eq "10"){
    print "\n";
    $lend = 0;
    }
   }
print "</td></tr><TR><TD width=\"100%\" bgcolor=\"#A0BAD3\"><p><FONT face=\"verdana, helvetica, arial\" size=\"1\"><b>Email image:</b><br>(image for email link)</font></p>\n";
      opendir (TN, "$tne_dir");
      rewinddir (TN);
      @tnlist =  grep(!/^\.\.?$/, readdir (TN));
      closedir (TN);

   $tnnum = @tnlist;
   $cnum = "0";
print "<p><input checked type=radio name=\"emailgif\" value=\"0\"";
   if($emailgif eq "0") {print "checked";}
   print "><FONT face=\"verdana, helvetica, arial\" size=\"1\"><b>No email image</b></p>\n";
   $lend = "0";
while ($tnnum > $cnum) {
      print "<input type=radio name=\"emailgif\" value=\"$tne_dir_url/$tnlist[$cnum]\"";
      if ($emailpic eq "$tne_dir_url/$tnlist[$cnum]") {print "checked";}
      print "><img src=\"$tne_dir_url/$tnlist[$cnum]\" border=0>\n";
      $cnum = $cnum + 1;
    $lend = $lend + 1;
      if ($lend eq "4"){
    print "\n";
    $lend = 0;
  }
   }
 }
sub error {
    local ($updact) = @_;
print "Content-type: text/html\n\n";
print "<html><head><title>Permission Denied</title></head>\n";
print $badj_css;
print $badj_body;
print $badj_header;
print $badj_seperator;
print "<DIV align=\"center\"><CENTER><TABLE border=\"0\" width=\"90%\" cellspacing=\"0\" cellpadding=\"0\"><TR><TD width=\"100%\">\n";
print "<P><FONT face=\"verdana, helvetica, arial\" size=\"4\" color=\"#FF0000\">\n";
print "Permission denied</font></p>\n";
print "<p><FONT face=\"verdana, helvetica, arial\" size=\"2\">You do not have permission! The Login information you entered is incorrect.</p>\n";
print $badj_seperator;
print $badj_footer;
print "</td></tr></table></body></html>\n";
exit;
    }

sub helppage {

print "Content-type: text/html\n\n";
print "<html><head><title>$title help</title></head>\n";
print $badj_css;
print $badj_body;
print $badj_header;
print $badj_seperator;
print qq~
<DIV align="center">
  <CENTER>
  <TABLE border="0" width="90%" cellspacing="0" cellpadding="0">
    <TR>
      <TD width="100%"><FONT face="verdana, helvetica, arial" size="4" color="#FF0000">$title
        Help</FONT><P><FONT face="verdana, helvetica, arial" size="2">Creating
        and editing pages with $title is simple. However, if you need
        assistance, you've come to the right place:</FONT></P>
        <P><FONT face="verdana, helvetica, arial" size="2"><B>HELP TOPICS:<BR>
        <A href="#What are $title ?">
        What are $title homepages?</A><BR>
        <A href="#Creating a page">Creating a page</A><BR>
        <A href="#Editing a page">
        Editing a page</A><BR>
        <A href="#Deleting a page">
        Deleting a page<BR>
        </A><A href="#Error messages">Error messages</A></B></FONT></P>
        <HR noshade size="1">
        <P><FONT face="verdana, helvetica, arial" size="4" color="#FF0000"><A name="What are $title ?">What
        are $title ?</A></FONT></P>
        <P><FONT face="verdana, helvetica, arial" size="2">$title are
        web pages created by inputting variables into an online form. The pages
        can include </FONT><FONT face="verdana, helvetica, arial" size="2">the
        following:</FONT></P>
        <P><IMG border="1" src="$imageurl/homepage.jpg" alt="Headline, sub heading, splash image, horizontal lines, body text, table, links, email address and a background image."></P>
        <HR noshade size="1">
<form action="http://localhost/cgi-bin/homepages/homepage.pl" method="POST">
<input type=hidden name="action" value="Create Page">
<!--FOOTER ENDS-->
<P><FONT face="verdana, helvetica, arial" size="4" color="#FF0000"><A name="Creating a page">Creating
a page</A></FONT></P>
<P><FONT face="verdana, helvetica, arial" size="2">Home pages are created by
completing a simple form. Here's a rundown of the form fields and what they do:</FONT></P>
<P><FONT face="verdana, helvetica, arial" size="2"><B>YOUR NAME<BR>
</B>Self explanatory - your name. This is used as a link to your Email address
on your home page. This is a required field as it also provides necessary
EZHomepg account information.</FONT></P>
<P><FONT face="verdana, helvetica, arial" size="2"><B>LOGIN ID<BR>
</B>This should be a single word that will be used to log into your account to
either edit or delete your home page - it shouldn't be easy to guess! This is a
required field.</FONT></P>
<P><FONT face="verdana, helvetica, arial" size="2"><B>EMAIL ADDRESS<BR>
</B>Your email address is used as an email link on your page, and is necessary
to login to your account to either edit or delete your home page. This is a
required field.</FONT></P>
<P><FONT face="verdana, helvetica, arial" size="2"><B>DISPLAY EMAIL ADDRESS<BR>
</B>Choose whether or not you want your email address displayed on your page.</FONT></P>
<P><FONT face="verdana, helvetica, arial" size="2"><B>FILE NAME<BR>
</B>The file name of your page consisting of letters and numbers only. It should
be a single word - spaces will be replaced with underscores. Don't include the
file extension. Your URL will become $baseurl/<B>yourname</B>.$fileext. This is
a required field.</FONT></P>
<P><FONT face="verdana, helvetica, arial" size="2"><B>HEADLINE<BR>
</B>The headline of your page. This appears at the top of your page, as the
title of your page, and as your listing on our <A href="$baseurl"><B>index
page</B></A>. This is a required field.</FONT></P>
<P><FONT face="verdana, helvetica, arial" size="2"><B>SUB HEADING<BR>
</B>This appears underneath the heading of your page.</FONT></P>
<P><FONT face="verdana, helvetica, arial" size="2"><B>DO YOU WANT THE HEADLINE
AND SUB HEADING CENTERED?<BR>
</B>Select whether or not you want the heading and sub heading centered on the
page. If you select 'No' they will be left justified.</FONT></P>
<P><FONT face="verdana, helvetica, arial" size="2"><B>TEXT FONT FACE<BR>
</B>The font face of the text on your page. Enter the name of the font you wish
to use, followed by some alternatives for computers that don't have your first
choice installed. Separate each with a comma. This field defaults to 'verdana,
helvetica, arial'.</FONT></P>
<P><FONT face="verdana, helvetica, arial" size="2"><B>SPLASH GRAPHIC<BR>
</B>Choose a graphic to appear beneath your sub heading, or select 'No graphic'.</FONT></P>
<P><FONT face="verdana, helvetica, arial" size="2"><B>DO YOU WANT THE IMAGE
CENTERED?<BR>
</B>Select whether or not you want the image centered. If you select 'No' the
image will be left justified.</FONT></P>
<P><FONT face="verdana, helvetica, arial" size="2"><B>BODY<BR>
</B>Input the body text of your page. Press &lt;return&gt; to start a new line,
press it twice to start a new paragraph.</FONT></P>
<P><FONT size="2" face="verdana, helvetica, arial"><B>LINKS<BR>
</B>You can link to three URLs from your web page. Enter the URL of each link
followed by the name of the link.</FONT></P>
<P><FONT size="2" face="verdana, helvetica, arial"><B>TEXT COLOR<BR>
</B>Choose the color you would like text to appear as.</FONT></P>
<P><B><FONT size="2" face="verdana, helvetica, arial">LINK COLOR<BR>
</FONT></B><FONT size="2" face="verdana, helvetica, arial">Choose the color you
would like links to appear as.</FONT></P>
<P><FONT size="2" face="verdana, helvetica, arial"><B>VISITED LINK COLOR</B><BR>
Choose the color you would like visited links to appear as.</FONT></P>
<P><FONT size="2" face="verdana, helvetica, arial"><B>BACKGROUND<BR>
</B>Select the background appearance of your page. Selecting 'No background'
will set the background appearance of the page to 'browser default' (usually
white or gray).</FONT></P>
<P><FONT size="2" face="verdana, helvetica, arial"><B>FIRST HORIZONTAL LINE<BR>
</B>Choose the appearance of the horizontal line that sits between the splash image
and the body text, or select 'No first line'.</FONT></P>
<P><B><FONT size="2" face="verdana, helvetica, arial">SECOND HORIZONTAL LINE<BR>
</FONT></B>
<FONT size="2" face="verdana, helvetica, arial">Choose the appearance of the horizontal line that
sits between your links and email address, or select 'No second line'.</FONT></P><P><FONT size="2" face="verdana, helvetica, arial"><B>BULLET<BR>
</B>Bullets are small images that are used to define paragraphs of body text.
Select a bullet image to use or select 'No Bullet' if you don't wish to use a
bullet image - by selecting this body text will become centered.</FONT></P><P><FONT size="2" face="verdana, helvetica, arial"><B>EMAIL
IMAGE<BR>
</B>Select an image to display with your email address link, or select 'No email
image'.</FONT></P><P><FONT size="2" face="verdana, helvetica, arial">To generate
your page hit 'Create Page'. The title of your page will also be added to our <B><A href="$baseurl">list
of pages</A></B>. You will be shown a confirmation screen and given the URL of
your page.</FONT></P>
<HR noshade size="1">
<P><FONT face="verdana, helvetica, arial" size="4" color="#FF0000"><A name="Editing a page">Editing
a page</A></FONT></P>
<P><FONT size="2" face="verdana, helvetica, arial">To edit your page you need to
log in by entering your login name, email address and file name.</FONT></P>
<P><FONT size="2" face="verdana, helvetica, arial">Editing your page is similar
to creating it - you are presented with a similar form. However, when editing
your page your original values are returned. You can change the values to edit
your page, but you can't however edit your page file name or login ID.</FONT></P>
<P><FONT size="2" face="verdana, helvetica, arial">For a description of each
form field see <B><A href="#Creating a page">Creating a page</A></B>.</FONT></P>
<HR noshade size="1">
<P><FONT face="verdana, helvetica, arial" size="4" color="#FF0000"><A name="Deleting a page">Deleting</A></FONT><A name="Deleting a page"><FONT face="verdana, helvetica, arial" size="4" color="#FF0000">
a page</FONT></A></P>
<P><FONT size="2" face="verdana, helvetica, arial">To delete your page enter
your login details and click on 'Login'.</FONT></P>
<HR noshade size="1">
<P><FONT face="verdana, helvetica, arial" size="4" color="#FF0000"><A name="Error messages">Error
messages</A></FONT></P>
<P><FONT size="2" face="verdana, helvetica, arial">If you receive any error
messages using $title it's probably because you either forgot to enter certain
information on a previous form, or entered it incorrectly. Go back and try
again!</FONT></P>
~;
print $badj_seperator;
print $badj_footer;
print "</td></tr></table></body></html>\n";
exit;
}

}






























