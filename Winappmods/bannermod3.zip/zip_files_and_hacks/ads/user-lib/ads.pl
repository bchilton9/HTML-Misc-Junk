###############################################################################
###############################################################################
# WebAPP - Automated Perl Portal                                              #
#-----------------------------------------------------------------------------#
# modified ads.pl for ae's banner mod 				              #
# v0.9.8								      #		#									      #
#                                                                             #
# Copyright (C) 2002 by Carter (carter@mcarterbrown.com)                      #
#                                                                             #
# This program is free software; you can redistribute it and/or               #
# modify it under the terms of the GNU General Public License                 #
# as published by the Free Software Foundation; either version 2              #
# of the License, or (at your option) any later version.                      #
#                                                                             #
# This program is distributed in the hope that it will be useful,             #
# but WITHOUT ANY WARRANTY; without even the implied warranty of              #
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the               #
# GNU General Public License for more details.                                #
#                                                                             #
# You should have received a copy of the GNU General Public License           #
# along with this program; if not, write to the Free Software                 #
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. #
#                                                                             #
#                                                                             #
# File: Last modified: 03/15/03                                               #
###############################################################################
###############################################################################

require "$scriptdir/mods/ads/banads.cfg";
require "$scriptdir/mods/ads/config.dat";
require "$scriptdir/mods/ads/language/$mod_lang";

#################
sub OutputJava {
#################

if ($IIS == 1) { srand (time|$$); }
	else { 	srand(time() ^ ($$ + ($$ << 15)) ); }

open(FILE, "$sites_dat") || error("Can't open $sites_dat");
	lock(FILE);
	chomp(@rotation = <FILE>);
	unlock(FILE);
close(FILE);


	foreach $i (@rotation) {
		chomp($i);
		
		($id,$poster,$thead,$url,$altd,$ih,$iw,$hits,$used) = split(/\|/,$i);
		$refill = $hits - $used;
			
			if ($refill == $refillnum)   { autonotify(); }
			if ($used <= $hits) { 
				push(@rotation_info, $i);
			} 
			
	}
			
	$rid = int(rand(@rotation_info));
		if ($rid < 0) { exit; }

	$banner_info = $rotation_info[$rid];
	chomp($banner_info);
	
	($id,$poster,$thead,$url,$altd,$ih,$iw,$hits,$used) = split(/\|/, $banner_info);

	if ($count_by_clicks == 0) { # we count impressions
	
	 print qq~<center><a href="$banadsurl/index.cgi?action=adsfarm" class="bannerlink">$banner{'016'}</a><br><a href="$url" target="_blank" class="bannerlink"><img src="$thead" width="$iw" height="$ih" alt="$alt" border="0"><br>$altd</a></center>~;

	imp_count();

	} else { # guess we count clicks

	 print qq~<center><a href="$banadsurl/index.cgi?action=adsfarm" class="bannerlink">$banner{'016'}</a><br><a href="$pageurl/$cgi?action=gobanner&amp;url=$url" target="_blank" class="bannerlink"><img src="$thead" width="$iw" height="$ih" alt="$altd" border="0"><br>$altd</a></center>~;

	  }


	
} # end sub


###############
sub imp_count {
###############

	# don't want to use up advertisers impressions by administrating site
	# don't count self views
	if ($username ne "admin" || $username ne "$poster") { $used++; }

open (DATA,">$sites_dat") || error("$banadserror{'004'} $sites_dat");
	lock(DATA);
		foreach $i (@rotation) {
		chomp($i);
			if ($i eq $banner_info) {
			print DATA "$id|$poster|$thead|$url|$altd|$ih|$iw|$hits|$used\n";
			}
			else { print DATA "$i\n"; }
		}
	unlock (DATA);
close (DATA);

} # end sub

##############
sub gobanner {
##############

$gourl = $info{'url'};

open(FILE, "$sites_dat") || error("Can't open $sites_dat");
	lock(FILE);
	chomp(@rotation = <FILE>);
	unlock(FILE);
close(FILE);

open(FILE, ">$sites_dat");
	lock(FILE);

	foreach $i (@rotation){
	chomp($i);
	($id,$poster,$thead,$url,$altd,$ih,$iw,$hits,$used) = split(/\|/, $i);
		if ($gourl eq $url) { $used++;
		print FILE "$id|$poster|$thead|$url|$altd|$ih|$iw|$hits|$used\n"; }
		else { print FILE "$i\n"; }
	} # end loop
	
	unlock(FILE);
close(FILE);
		
	print "Location: $gourl\n\n"; exit;

}

################
sub autonotify {
################

chomp($poster);
chomp($url);
chomp($refillnum);

	open(FILE, "$memberdir/$poster.dat") || error("$banadserror{'004'} $memberdir/$poster.dat"); 
	lock(FILE); 
	chomp(@user = <FILE>); 
	unlock(FILE); 
	close(FILE); 

$ntyto = "$user[1] <$user[2]>";

	open(FILE, "$memberdir/admin.dat") || error("$banadserror{'004'} $memberdir/admin.dat"); 
	lock(FILE); 
	chomp(@adminmail = <FILE>); 
	unlock(FILE); 
	close(FILE); 

$ntyfrom = $adminmail[2];
$ntysubj = "$pagetitle - $exitx{'032'}";
$ntytxt = qq~$exitx{'033'} $url $exitx{'034'}

$banadsurl/admin/admin.cgi

$exitx{'035'}
$pagetitle
$baseurl~;

$ntymsg = "$ntytxt";
	
sendemail($ntyto, $ntysubj, $ntymsg, $ntyfrom);

}


if (-e "$scriptdir/user-lib/ads.pl") {require "$scriptdir/user-lib/ads.pl"} 

1;
