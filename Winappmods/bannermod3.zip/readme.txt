Readme for Banner Mod v0.1 by AE (guru@stowaways.us)

This mod can be used as a replacement for the current WebApp Banner System. It offers an administration section for admin and administrators to edit/delete current banners, and to approve new banners. Advertisers can check their click-through or impression useage, upload banners and supply payment via Paypal.

For WebApp ver9.9: "bannerfarm" isn't part of the core script anymore, I've added it to the mod index.

###############
1. Installation
###############

a. Check the path to perl (default: #!/usr/bin/perl) on all scripts. 
b. Open banads.cfg and change path settings if needed.
c. Make a new folder in your mods directory called "ads" and upload files in ASCII mode (standard mod directory structure):

DIR structure/permissions:

path-to-mods-dir/ads	# base ads mod folder

 - index.cgi		# chckmod 755
 - upload.cgi		# chckmod 755
 - config.dat		# chckmod 666/777*
 - banads.cfg		# chckmod 644

path-to-mods-dir/ads/admin # admin folder below ads folder

 - admin.cgi		# chckmod 755
 - paypal_info.dat	# chckmod 666/777*


path-to-mods-dir/ads/db  # db folder below ads folder, may chckmod 777*

 - adsettings.dat	# chckmod 666/777*
 - tempads.dat		# chckmod 666/777*
 - sites.dat		# chckmod 666/777*

path-to-mods-dir/ads/language  # language folder below exit folder

 - english.dat  	# chckmod 644
 - german.dat	  	# chckmod 644 (optional)

path-to-webapp-dir/cgi-bin/user-lib  # your user-lib folder
# all subroutines in this file have been modified to work with the banner mod
# just copy the whole file into your user-lib dir

 - ads.pl		# chckmod 755

*varies by server

d. Call admin.cgi and edit the paypal settings to reflect your paypal user account.

e. WebApp9.9 users only!!! Add to main index.cgi

elsif ($action eq "gobanner") { require "$sourcedir/ads.pl"; gobanner(); }

Done. If everything is installed correctly, you should see the test banners appear when you reload your page. 

########
2. Usage
########

Don't forget to add links on your site to the signup: http://www.ursite.com/cgi-bin/mods/ads/index.cgi

to the admin area: http://www.ursite.com/cgi-bin/mods/ads/admin/admin.cgi

for your advertisers: http://www.ursite.com/cgi-bin/mods/ads/admin/admin.cgi?op=stats


Let me know any bugs, if I need to document anything better, etc.
Andrea(ae)