INACTIVE MOD V 1.0 BETA
BY: JOHN MILLER
SITE: http://www.swjuggalos.com


I made this script in one day so there is probably some bugs some where!

Email me at fatnutz@swjuggalos.com if you find any bugs. or post them at mod app somewhere!

Setup is easy. Just open index.cgi and change the few setup variables at the top of the file.

Now upload the files like so:

put the following in your mod folder located at yoursite.com/cgi-bin/mod


create folder in mod folder called "inactivemod"!
create folder in inactivemod folder called "db"!
upload index.cgi and config.dat to inactivemod folder!


should look like this

inactivemod		+755
inactivemod/db		+755
inactivemod/index.cgi	+755
inactivemod/config.dat	+666

if the chmodd doesn't work then make everything 777!

Now login as admin and run the index.cgi.. 

The program will now list all the users inactive for 90 days!
From the main screen you can send warning emails or delete the user!
The program will send TWO DIFFERENT Warning messages! A First Warning And A Second And Final Warning!


the STATUS(0,1,2) Means:

0 Emails Sent
1 Email Sent
2 Emails Sent

You can't send anymore then two emails.. Just delete the person if they havn't responded or logged in!

Sorry for the shitty Readme.. But like i said i need this done and i did it in one day! I never really 
meant for other to use but i was asked by a good friend..




