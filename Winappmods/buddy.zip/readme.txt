Buddy List V.1

These are the language tags, they have to go into your english.lng file, make sure you have a back up.

#############################
$bud{'001'} = "Buddy List";
$bud{'002'} = "Usernames";
$bud{'003'} = "Online";
$bud{'004'} = "Offline";
$bud{'005'} = "View Profile";
$bud{'006'} = "Edit List";
$bud{'007'} = "Save List";
$bud{'008'} = "Send IM";
$bud{'009'} = "View Memberlist";
$bud{'010'} = "Add Buddy";
$bud{'011'} = "Add Name";
$bud{'012'} = "Has been added";
$bud{'013'} = "Delete Buddy";
$bud{'014'} = "Has Been Deleted";
$bud{'015'} = "SEND IM TO BUDDY SAYING THAT IT WAS ADDED?";
$bud{'016'} = "Has added you to their Buddy List.";
$bud{'017'} = "of";
$bud{'018'} = "God bless you! greetings from ";
$bud{'019'} = "No one online";
$bud{'020'} = "You cannot add yourself to the list!.";
$bud{'021'} = "-- OnLine --";
###########


Next, get a hold of your index.cgi file, back it up first, next insert these lines:

elsif ($action eq "blistedit") {require "$scriptdir/user-lib/buddylist.pl"; blistedit();}
elsif ($action eq "addbuddy") {require "$scriptdir/user-lib/buddylist.pl"; addbuddy();}
elsif ($action eq "deletebuddy") {require "$scriptdir/user-lib/buddylist.pl"; deletebuddy();}


this next code is what calls up the buddy list hack, you could post this in your user.pl, sub myprofile if you wish,
make sure you back it up first.  :

<!-- Start Buddy List table -->
<table cellspacing=0><tr><Td bgcolor="#225875">
<table border="0" cellpadding="0" cellspacing="0">

<tr>
    <td bgcolor="#225875" width="1" align=right valign=top height="10">
     </td>
    <td bgcolor="#225875" colspan="2" valign=top background="$imagesurl/buddy/bottom.gif" height="19" width="224">
    <p align="center"><font 
face="verdana, arial, helvetica" size="2" 
 
color="#000066"><b>$bud{'001'}</b></font>    
    </td>
        <td bgcolor="#225875" width="4" align=left valign=top height="19">
    </td>
  </tr>

  <tr>
    <td width="4" bgcolor="#225875" height="19">&nbsp;</td>
    <td width="224" bgcolor="#FFFFFF" colspan="2" valign=top background="$imagesurl/buddy/top.gif" height="19">
    <p align="center">
   <img border=0 src="$imagesurl/buddy/group-3.gif" width="17" height="14" alt=""></td>
    <td width="4" bgcolor="#225875" height="19">&nbsp;</td>
  </tr>
  <tr>
    <td width="4" bgcolor="#225875" height="19">&nbsp;</td>
    <td width="224" bgcolor="#FFFFFF" colspan="2" valign=top height="19">
    <center><table colspacing=0 colpadding=0>~;
   ##############################################################
### Hack-Modification by joseedwin 04/29/2003
### This Hack calls up a subroutine in the /user-lib/buddylist.pl file

require "$scriptdir/user-lib/buddylist.pl";
blist();

### End Hack
##############################################################
    
  print qq~  
    </table></center>
    </td>
        <td width="4" bgcolor="#225875" height="19">&nbsp;</td>
  </tr> 
  
  
  <tr>
    <td width="1" bgcolor="#225875" height="1">&nbsp;</td>
    <td bgcolor="#225875" colspan="2" valign=top background="$imagesurl/buddy/top.gif" height="1" width="224">
    
    
    </td>
        <td width="4" bgcolor="#225875" height="1">&nbsp;</td>
  </tr>
 
 <tr>
    <td bgcolor="#225875"width="1" align=right valign=top height="10">
     </td>
    <td bgcolor="#FFFFFF" background="$imagesurl/buddy/bottom.gif" colspan="2" valign=bottom height="5" width="224" align="right"><font 
face="verdana, arial, helvetica" size="2" 
 
color="#000066"><b><a href="$cgi?action=memberlist"><img src="$imagesurl/buddy/guest.gif" border=0 alt="$bud{'009'}"></a>
&nbsp;<a href="$cgi?action=blistedit"><img src="$imagesurl/forum/modify.gif" alt="$bud{'006'}" border=0></a>
</b></font>    
    </td>
        <td bgcolor="#225875" width="4" align=left valign=top height="19">
    <p align="left">
    &nbsp;</td>
  </tr>

</table></td></tr></table>
<br>

<!-- End Buddy List table -->




Small hack to use in your memberlist.pl file, this link lets you add a buddy straight from the memberlist;


<a href="$pageurl/$cgi?action=blistedit&amp;buddy=$musername"><b>+</b></a> 

change + to anything you like, image, different text, etc.....



what's new:  an option to send an IM to the buddy just added, the script will not let you add yourself to the list, it will check if the user actually exist, and the new layout looks better.
