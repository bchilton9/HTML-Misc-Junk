ASET MOD READ ME FILE
-------------------------------------------------------------------------
-------------------------------------------------------------------------
 Written by Weston Lemos (wes@onetruth.com)
 v0.2 Released on April 13, 2003 (Current Version)	   	      
-------------------------------------------------------------------------
-------------------------------------------------------------------------
 Description:    
  ASet is a setting file manager intended to facilitate the
  managing of small settings files.   
   
 Usage:   
  ASet was originally created as a development aid for those      
  wishing to make WebAPP based scripts with "easy-to-manage"      
  settings files.  Besides being able to help other scripts ASet  
  can be installed as a stand alone settings file manager. 
  Although ASet will work with many different settings files, it is      
  recommended on either simple settings files or on settings files
  that were created with specific ASet formatting.  
   
 Mod / Script Developers:      
  Just take this code and include it with your mod and have it    
  point to the settings file that you wish.  Set the "return_url" 
  to point to the name of your main script.  Make sure to set the 
  stand_alone variable to "no". If you do use this script, please 
  place your Mod/Script description above this one.   Advanced    
  Developers: If you wish you can go ahead and modify this code to
  make it more seamless with their own script.  For the most      
  updated version of this program, make sure to check out ModAPP at      
  http://www.web-app.org/modapp/cgi-bin/index.cgi . 
   
 File types supported:  
  It will support most all simple settings files.  The default    
  accepted extensions are .dat, .cfg, and .lng.     
   
 Known Bugs:     
  Tab spaced settings files often will have alignment issues. (FIXED)    
  ASet does not support multilined variables.
  Variables with semicolons in their values do not currently work.(FIXED)
  It seems to be quite processor intensive currently. (FIXED)     
  Error with Double Quotes. (FIXED) Converts all to &quot; 
  &quot; isn't good for array's. -- Use (') single quotes. (WORKS)
  Let me know if you find more.
-------------------------------------------------------------------------
-------------------------------------------------------------------------
 Installation: 
  Modify the path to perl in aset.cgi.
  Create a directory in your mods dir called "aset".
  Upload the aset.cgi, config.dat and asetexample.dat to your aset dir.
  CHMOD aset.cgi to 755 and you should be good to go.
 Installation Note:
  Servers are different, and the example above assumed you have a 
  "friendly" server.  Some servers will require that you CHMOD 777 every
  file and CHMOD 777 every directory that contains the file that you 
  wish to edit.  If this is the case CHMOD your aset directory and your
  asetexample.dat file to 777.  If you are on a very strict server, as
  is my case on my test server, you will not be able to have .cgi files
  or .pl files in a directory that is CHMOD set to 777.  You will have 
  to figure out what works for you in these events.
-------------------------------------------------------------------------
-------------------------------------------------------------------------
 Additional Instructions:
  Play with the example file.  If it works well, try making a back-up
  of another settings files somewhere else and then edit it.  ALWAYS 
  use the "Test Output" option first just to make sure that output 
  looks ok before you save it.  Address all comments or suggestions to
  the messages boards at mod-app.  Enjoy.
-------------------------------------------------------------------------
-------------------------------------------------------------------------  
 License
  This program is free software; you can redistribute it and/or    
  modify it under the terms of the GNU General Public License      
  as published by the Free Software Foundation; either version 2   
  of the License, or (at your option) any later version.    
   
  This program is distributed in the hope that it will be useful,  
  but WITHOUT ANY WARRANTY; without even the implied warranty of   
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the    
  GNU General Public License for more details.
   
  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software      
  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,  
  USA 
-------------------------------------------------------------------------
-------------------------------------------------------------------------    
