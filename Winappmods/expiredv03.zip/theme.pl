#---------------------------------------------------------
#  Subroutine:   broadcastmessage
#  Written By:   burak
#  Description:  Modified for expired Mod
#
#  Revision History:
#  2003-01-14  Script Created
#---------------------------------------------------------

######################
sub broadcastmessage {
######################
print qq~
<script>

//Check all radio/check buttons script- by javascriptkit.com
//Visit JavaScript Kit (http://javascriptkit.com) for script
//Credit must stay intact for use  

function checkall(formname,checkname,thestate){
var el_collection=eval("document.forms."+formname+"."+checkname)
for (c=0;c<el_collection.length;c++)
el_collection[c].checked=thestate
}

</script>
~;

if ($username ne "$anonuser") { 
 
# This is to broadcast an alert message to everyone online at that time 
 
		open(FILE, "$memberdir/admin.pref") || error("$err{'010'}"); 
		lock(FILE); 
		chomp(@preferences = <FILE>); 
		unlock(FILE); 
		close(FILE); 
 
 
		if ($preferences[4] == 1) { 
		 
		print qq~ 
 
<script language="JavaScript1.2"> 
 
 
var ns4=document.layers 
var ie4=document.all 
var ns6=document.getElementById&&!document.all 
 
 
var dragswitch=0 
var nsx 
var nsy 
var nstemp 
 
function drag_dropns(name){ 
if (!ns4) 
return 
temp=eval(name) 
temp.captureEvents(Event.MOUSEDOWN | Event.MOUSEUP) 
temp.onmousedown=gons 
temp.onmousemove=dragns 
temp.onmouseup=stopns 
} 
 
function gons(e){ 
temp.captureEvents(Event.MOUSEMOVE) 
nsx=e.x 
nsy=e.y 
} 
function dragns(e){ 
if (dragswitch==1){ 
temp.moveBy(e.x-nsx,e.y-nsy) 
return false 
} 
} 
 
function stopns(){ 
temp.releaseEvents(Event.MOUSEMOVE) 
} 
 
 
 
function drag_drop(e){ 
if (ie4&&dragapproved){ 
crossobj.style.left=tempx+event.clientX-offsetx 
crossobj.style.top=tempy+event.clientY-offsety 
return false 
} 
else if (ns6&&dragapproved){ 
crossobj.style.left=tempx+e.clientX-offsetx 
crossobj.style.top=tempy+e.clientY-offsety 
return false 
} 
} 
 
function initializedrag(e){ 
crossobj=ns6? document.getElementById("showimage") : document.all.showimage 
 
var firedobj=ns6? e.target : event.srcElement 
var topelement=ns6? "HTML" : "BODY" 
 
while (firedobj.tagName!=topelement&&firedobj.id!="dragbar"){ 
firedobj=ns6? firedobj.parentNode : firedobj.parentElement 
} 
 
if (firedobj.id=="dragbar"){ 
offsetx=ie4? event.clientX : e.clientX 
offsety=ie4? event.clientY : e.clientY 
 
tempx=parseInt(crossobj.style.left) 
tempy=parseInt(crossobj.style.top) 
 
dragapproved=true 
document.onmousemove=drag_drop 
} 
} 
document.onmousedown=initializedrag 
document.onmouseup=new Function("dragapproved=false") 
 
 
function hidebox(){ 
if (ie4||ns6) 
crossobj.style.visibility="hidden" 
else if (ns4) 
document.showimage.visibility="hide" 
} 
 
</script> 
 
<div id="showimage" style="position:absolute;width:250px;left:250;top:250"> 
 
<table border="0" width="250" bgcolor="$bmheadercolor" cellspacing="0" cellpadding="2"> 
  <tr> 
    <td width="100%"><table border="0" width="100%" cellspacing="0" cellpadding="0" 
    height="36"> 
      <tr> 
        <td id="dragbar" style="cursor:hand" width="100%"><ilayer width="100%" onSelectStart="return false"><layer width="100%" onMouseover="dragswitch=1;if (ns4) drag_dropns(showimage)" onMouseout="dragswitch=0"><font face="Verdana" 
        color="$bmbgcolor"><strong><small>Admin Broadcast Message</small></strong></font></layer></ilayer></td> 
        <td style="cursor:hand"><a href="#" onClick="hidebox();return false"><img src="$themesurl/standard/images/close.gif" width="16" 
        height="14" border=0></a></td> 
      </tr> 
      <tr> 
        <td width="100%" bgcolor="$bmbgcolor" style="padding:4px" colspan="2"> 
 
<!-- PUT YOUR CONTENT BETWEEN HERE ----> 
 
$preferences[5]  
 
<!-- END YOUR CONTENT HERE-----> 
 
</td> 
      </tr> 
    </table> 
    </td> 
  </tr> 
</table> 
</div> 
 
 
~; 
 
		} 
} 
 
# End broadcast java alert message 

}


1; # return true

