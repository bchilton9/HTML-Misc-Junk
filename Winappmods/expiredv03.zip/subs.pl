################ 
sub userstatus { 
################ 
     $guests = 0; 
     $users = 0; 

     open(LOG, "$datadir/log.dat"); 
     lock(LOG); 
     chomp(@entries = <LOG>); 
     unlock(LOG); 
     close(LOG); 

     foreach $curentry (@entries) { 
           ($name, $value) = split(/\|/, $curentry); 
           if($name =~ /\./) { ++$guests } 
           else { ++$users      } 
     } 
     if ($username ne "$anonuser") { 
 
##########
#Activity log is written...
##############
	getdate();
	$writedate = $date;
	writelog("Last_Activity");


##################
##To here
####################
           open(MEM, "$memberdir/$username.dat"); 
           lock(MEM); 
           chomp(@sett = <MEM>); 
           unlock(MEM); 
           close(MEM); 

           if ($username ne "$anonuser") { 
                 open(IM, "$memberdir/$username.msg"); 
                 lock(IM); 
                 @immessages = <IM>; 
                 unlock(IM); 
                 close(IM); 

                 $mnum = @immessages; 
                 $messnum = "$mnum"; 
           } 
           print qq~<tr> 
<td class="whocat">$msg{'002'} '$sett[1]'</td> 
</tr> 
<tr> 
<td class="whocat">$msg{'342'}<a href="$pageurl/$cgi?action=im" class="whomenu">$mnum</a>$msg{'343'}</td> 
</tr> 
~; 

if ($mnum >= 0) { 
	

		open(FILE, "$memberdir/$username.pref") || error("$err{'010'}");
		lock(FILE);
		chomp(@preferences = <FILE>);
		unlock(FILE);
		close(FILE);

		if ($preferences[0] == 1 || $preferences[0] eq "" ) {
		require "$sourcedir/subs.pl";
		if ($preferences[6] < $mnum) { require "$sourcedir/subs.pl"; imalert(); } 

if ($username ne "admin") {

open(FILE, ">$memberdir/$username.pref") || error("$err{'010'}");
lock(FILE);
print FILE "$preferences[0]\n";
print FILE "$preferences[1]\n";
print FILE "$preferences[2]\n";
print FILE "$preferences[3]\n";
print FILE "\n";
print FILE "\n";
print FILE "$mnum\n";
print FILE "$preferences[7]\n";
unlock(FILE);
close(FILE);
}

if ($username eq "admin") {

open(FILE, ">$memberdir/$username.pref") || error("$err{'010'}");
lock(FILE);
print FILE "$preferences[0]\n";
print FILE "$preferences[1]\n";
print FILE "$preferences[2]\n";
print FILE "$preferences[3]\n";
print FILE "$preferences[4]\n";
print FILE "$preferences[5]\n";
print FILE "$mnum\n";
print FILE "$preferences[7]\n";
unlock(FILE);
close(FILE);

}                 } 
           } 

     } 

     open(CNT, "$memberdir/mostonline.cnt"); 
     lock(CNT); 
     $oldcount = <CNT>; 
     unlock(CNT); 
     close(CNT); 

     $newcount = $guests + $users; 

     if ($newcount > $oldcount) { 
     open(CNT, ">$memberdir/mostonline.cnt"); 
     lock(CNT); 
     print CNT "$newcount"; 
     unlock(CNT); 
     close(CNT); 
     $mostonline = $newcount; 
     } else { 
     $mostonline = $oldcount; } 

     print qq~<tr> 
<td class="whocat">$msg{'344'}$guests$msg{'346'} 
~; 

if ($username eq "$anonuser") { print qq~ 
$users$msg{'347'}</td></tr>~;

if ($dispmost eq "1") {print qq~ 
     <tr> 
     <td class="whocat">$msg{'345'}$mostonline.</td> 
     </tr>~; } 
} 

if ($username ne "$anonuser") { print qq~ 
<a href="$pageurl/$cgi?action=who" class="whomenu"><u>$users</u></a>$msg{'347'}</td> 
</tr>~;

if ($dispmost eq "1") {print qq~ 
     <tr> 
     <td class="whocat">$msg{'345'}$mostonline.</td> 
     </tr>~; }  
} 
}

1;