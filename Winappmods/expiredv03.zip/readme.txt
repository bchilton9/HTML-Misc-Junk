Expired Mod v. 0.3
by burak - burak@gencnet.com
http://www.gencnet.com

Description:
Expired mod is created for WebAPP. Expired mod is used to pick-out inactive users and notify them. 

History:
2003-01-14:
Script created.
2003-01-29:
v0.2 created. Ability to delete users added. Now script show how many times and when the user has been notified.
2003-02-10:
v0.3 created. The activity of the users are now correct.

Installation:
1. Make changes.
Open expired_config.pl and change the http's, root's and the email to your site.

2. Upload the files to your server.

/cgi-bin/mods/expired/expired.pl
/cgi-bin/mods/expired/config.dat
/cgi-bin/mods/expired/expired_config.pl
/cgi-bin/mods/expired/language/english.dat

*** /cgi-bin/user-lib/themes/theme.pl
Note: If you don't have a theme.pl in your user-lib upload the theme.pl in this zip file you downloaded. If you have a theme.pl in your user-lib open it and add the content of the theme.pl you downloaded. Overwriting the file in your user-lib may/will cause problems! You don't have to upload this file. If you don't upload you will not have the select all feature.

*** /cgi-bin/user-lib/subs.pl
Note: Making this upload will add another log to your username.log files. This mod uses this log to calculate user activity. If you dont have a sub.pl in you user-lib upload this file. If you do have a subs.pl than add the content of the subs.pl you get with this file to your subs.pl. Do not add the 1 at the end of the file since this will cause problems.


3. CHMOD your files.....

/cgi-bin/mods/expired/expired.pl ............... 755
/cgi-bin/mods/expired/config.dat ............... 644
/cgi-bin/mods/expired/expired_config.pl ........ 644
/cgi-bin/mods/expired/language/english.dat ..... 644
/cgi-bin/user-lib/themes/theme.pl .............. 644
/cgi-bin/user-lib/subs.pl ...................... 644

4. Go to http://www.yoursite.com/cgi-bin/mods/expired/expired.cgi

Upgrade Form v0.2
Install the v0.3 by overwriting the old files. This mod adds a new log to the username.log files. Because the logs didn't exist before this upgrade most of the users will be marked as unlogged. 



Future releases:
- Automatic maintainence of the users.

Know bugs:
- Can't select more than 20-25 users per notification.