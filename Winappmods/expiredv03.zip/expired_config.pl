# URL to main webapp index.cgi
$webappURL = "http://www.yoursite.com/cgi-bin/index.cgi";

$expired_url = "http://www.yoursite.com/cgi-bin/mods/expired/expired.cgi";

$hurl = "/home/web/cgi-bin";

$admin_email = "webmaster\@yoursite.com"
#the file extensions used for storeing info about members.
$fileext = "pref msg log dat exp";