Feeback Version 0.1 - A Mod for WebApp
Based on code supplied with the WebApp 0.9.4 distribution.
Written by Brad (webmaster@indie-central.ca)

Updated 24 November 2002 to work with WebAPP v098.
Now includes full language support.
Note: due to mailer problems, currently feedback may only be sent via IM

This modification may be freely distributed or modified under the terms of the GNU General Public License.  
However, if you improve and/or redistribute it, please notify me so I know how the script is being used and improved! :)


OVERVIEW
This modification will add a simple "Feedback Form" to your WebApp-powered website.


INSTRUCTIONS
If you are familiar with perl (and your site is in English), then follow these simple instructions:

1. modify perl path in /feedback/index.cgi
2. upload files into your mods directory, based on the subdirectories in the .zip file
3. chmod index.cgi (755)
4. add a link to the feedback script (/feedback/index.cgi)

That's it!

The following are detailed instructions for implementing the Feedback Mod at your site:

########################################
Step 1 - Configuration
########################################

PERL PATHS
Modify index.cgi to reflect the path to perl on your server. 
The default path (#!/usr/local/bin/perl) may need to be modified to match your site.

FEEDBACK.CFG
If you modify the paths from the zip, you should edit this file as needed.  Note: you should 
leave $by_mail set to 0, since the mailer code doesn't want to work for me.  


########################################
Step 2 - Create Directories
########################################

Note: if you do not follow the directory structures as outlined in this section, you will have to modify the feedback.cfg file 
to a greater extent.  Therefore it is recommended that you follow these instructions to the letter.

You must first create a "mods" directory within your site's cgi-bin directory.
If you already have other mods installed, then this first step is not necessary.

The resulting directory chain should look like this:
/cgi-bin/mods

Next, create a subdirectory called "feedback" within the "mods" directory:
/cgi-bin/mods/feedback

Now create the following subdirectory within this "feedback" directory:
/cgi-bin/mods/feedback/language


########################################
Step 3 - Upload Files
########################################

Upload all files in ASCII mode, into the following directories:
/cgi-bin/mods/feedback/config.dat
/cgi-bin/mods/feedback/feedback.cfg
/cgi-bin/mods/feedback/index.cgi
/cgi-bin/mods/feedback/index.html
/cgi-bin/mods/feedback/language/english.dat


########################################
Step 3 - Chmod File
########################################

Change the permissions as follows:

index.cgi	755


########################################
Step 4 - Accessing the script
########################################

You will need to include a link somewhere within your main site to the feedback form.  

The link will be something like:

<a href="$pageurl/mods/feedback/index.cgi">Send us Feedback</a>



Questions or comments may be directed to Brad (webmaster@indie-central.ca).


########################################
Breakdown of files within this package
########################################

/feedback/feedback.cfg 			configuration file for this mod
/feedback/config.dat			configuration file for Floyd's Mod Manager
/feedback/index.cgi				main script for this mod
/feedback/index.html			temp page (redirects to index.cgi)
/feedback/readme.txt			this file
/feedback/language/english.dat	english language file for this mod



# end


