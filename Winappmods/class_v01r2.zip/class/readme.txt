Classifieds Version 0.1
Based on code supplied with the WebApp distribution.
Written by Brad (webmaster@indie-central.ca)

Revision 1
- modified from original source to work with WebAPP v097+
Revision 2
- added search feature (searches ad title and content)

***********************************************************************************
NOTE: THIS VERSION OF CLASSIFIEDS HAS BEEN SLIGHTLY MODIEFIED FOR WEBAPPS .97...  *
CHANGES TO THE README ARE NOTED..BY: ^^NOTE: CHANGE^^                             *
SEE BOTTOM OF THIS README FOR A LIST OF CHANGES TO BRAD'S CLASSIFIEDS             *
***********************************************************************************

This modification may be freely distributed or modified under the terms of the GNU General Public License.  However, if you improve and/or redistribute it, please notify me so I know how the script is being used and improved! :)


OVERVIEW
This modification will add a "Classified Ads" area to your WebApp-powered website.  Only members will be able to place an ad, however, all guests will be able to view them.  If you wish to not allow guests to view the ads, then you should modify your link to the classifieds area accordingly (see detailed instructions).

IMPORTANT NOTE:
When naming your classified sections, the "short title" will be used to create the database file in which the info for the section will be stored.  It is vital that this short name does not include any special characters (such as /  -  *  ^  #  <  >  [  ]  {  } or spaces); just use regular characters, underscores, etc.  If you do not do this, this Mod will not work correctly! [thanks to David Rolen for this info!)

^^NOTE: ADDED^^
When in "Edit Config File"  set "Admin Script:" to "1". For the "Main Admin Script Name:" enter "admin.cgi"...
When first time in "Classified Admin" "add categories". Add a minimum of 2 categories for proper display......

INSTRUCTIONS
Following the detailed instructions are notes on additional uses for this script, as well as a detailed breakdown of all files within this package.

If you are familiar with perl (and your site is in English), then follow these simple instructions:

1. modify perl paths in /class/index.cgi and /class/admin/admin.cgi
2. upload files into your mods directory, based on the subdirectories in the .zip file
3. chmod all .cgi (755), and all .dat (666)
4. create a "class" directory within your main WebAPP images directory
5. upload the graphics in the images directory (along with any new images you wish to use) into /class/images
6. add a link to the classifieds script (/class/index.cgi)

That's it!

The following are detailed instructions for implementing the Classifieds Mod at your site:

########################################
Step 1 - Configuration
########################################

Within the mod package there are a few files which must be modified before it can be used.

PERL PATHS
Modify both index.cgi and admin.cgi to reflect the path to perl on your server. The default path (#!/usr/local/bin/perl -w) may need to be modified to match your site.

CLASS.CFG
This file should not have to be modified if your site is in English.  If your site uses another language, you will have to create a language file for this mod (or modify the supplied English language file, english.dat).  You should name your language file "language.dat", for example, "french.dat" (all lower case).  

If you create a new language file, it is very important that you set the first variable in the class.cfg file to match your language (lower case), for example:
$this_lang = "french"; 


########################################
Step 2 - Create Directories
########################################

Note: if you do not follow the directory structures as outlined in this section, you will have to modify the class.cfg file to a greater extent.  Therefore it is recommended that you follow these instructions to the letter.

You must first create a "mods" directory within your site's cgi-bin directory.
If you already have other mods installed, then this first step is not necessary.

The resulting directory chain should look like this:
/cgi-bin/mods

Next, create a subdirectory called "class" within the "mods" directory:
/cgi-bin/mods/class

Now create the following subdirectories within this "class" directory:
/cgi-bin/mods/class/admin
/cgi-bin/mods/class/db
/cgi-bin/mods/class/db/ads
/cgi-bin/mods/class/language

Finally, create a "class" directory within your main WebAPP images directory, resulting in:
/images/class


########################################
Step 3 - Upload Files
########################################

Upload the graphics (from the /images directory) in BINARY mode into this directory: 
/images/class

^^Note Added^^
The image files in the zip images/class directory goes into /yoursite/images/class

Only the "_dot.gif" and "_clear.gif" graphics are necessary.  All others are made available for the main categories, and may be removed from this directory if you do not wish to use them.  Note: you may add your own images (.gif, .jpg or .png) for use in the classifieds; all you need to do is upload them into this same directory.  

Next, upload the remaining files in ASCII mode, into the following directories:
/cgi-bin/mods/class/class.cfg
/cgi-bin/mods/class/config.dat
/cgi-bin/mods/class/index.cgi
/cgi-bin/mods/class/index.html
/cgi-bin/mods/class/admin/admin.cgi
/cgi-bin/mods/class/admin/config.dat
/cgi-bin/mods/class/admin/index.html
/cgi-bin/mods/class/db/cats.dat
/cgi-bin/mods/class/db/newads.dat
/cgi-bin/mods/class/language/english.dat

^^NOTE: ADDED^^
/cgi-bin/mods/class/smilie.pl 

(Smilie.pl is included in this zip file.  This file is required for the java smilie faces.
Smilie.pl was not used after webapps.95, so has to be included in this zip.


########################################
Step 3 - Chmod Files
########################################

Change the permissions as follows:

class.cfg	666
index.cgi	755
admin.cgi	755
admin.dat	666
cats.dat	666
newads.dat	666
english.dat	666

smilie.pl       755

########################################
Step 4 - Accessing the script
########################################

You will need to include a link somewhere within your main site to the classifieds area.  

If you wish allow all visitors to view the classifieds, then the link will be:
<a href="$pageurl/mods/class/index.cgi">Classified Ads</a>

If you do not want guests to view the ads, then you will have to code something like this:

if ($username ne "$anonuser") {
  print qq~<a href="$pageurl/mods/class/index.cgi">Classified Ads</a>~;
}

There are methods in place within the script to prevent guest posting, should a more devious visitor try to manually access the posting area.

Note: there is no need to add a link to the admin script.  If you are logged in as admin, a link to this area will appear at the bottom of the main categories page (next to "place ad").

Make sure you create a category before you allow members to access this mod! :)

Questions or comments may be directed to Brad (webmaster@indie-central.ca).


########################################
Additional uses for this classifieds mod
########################################

This mod may be used for other applications, it is not limited to classifieds.  It is essentially a tool for accessing and organizing individual items/pages within different categories. 

Possible applications:
1. short stories (drama/sci-fi, etc)
2. book, game or film reviews
3. technical or other documents

By completely editing the english.dat file, you can reformat the text of this mod to reflect your application.  Note that if you wish to upload this new application into something other than "/mods/class", then you must modify the class.cfg file accordingly.


########################################
Breakdown of files within this package
########################################

/class/class.cfg 			configuration file for this mod
/class/config.dat			configuration file for Floyd's Mod Manager
/class/index.cgi			main script for this mod
/class/index.html			temp page (redirects to index.cgi)
/class/readme.txt			this file
/class/admin/admin.cgi			admin script for this mod
/class/admin/config.dat			admin options
/class/admin/index.html			temp page (redirects to admin.cgi)
/class/db/cats.dat			ad categories
/class/db/newads.dat			storage for ads awaiting approval by admin
/class/images/_dot.gif			arrow graphic used in this mod
/class/images/_clear.gif		clear graphic used in this mod
/class/images/(remaining .gif files)	graphics use for categories
/class/language/english.dat		english language file for this mod

/class/smilie.pl                        java script for java smilie faces
# end

**********************************************************************
CHANGES TO ORIGINAL CLASSIFIEDS TO FOR COMPATABILITY WITH WEBAPPS .97
**********************************************************************
1. smilies.pl  now included in zip.  Note smilies.pl is no longer used in Webapps after ver .95.
2. index.cgi changes to the following lines

LINE#        ---ORIGINAL-----------------------              ---CHANGED------------------------------
88           { require "$datadir/smilies.pl"; }               { require "$classdir/smilies.pl"; }

140-146      src="$imagesurl/forum/xxxxx.gif"                 src="$imagesurl/forum/buttons/xxxxx.gif"

147          src="$imagesurl/forum/smilie.gif"                src="$imagesurl/forum/smilies/smile.gif"

353          $message = $item[5];                             $message = $item[5];
354	     doubbctopic();                                   doubbctopic();
355                                                           dosmilies(); 

3. Changed the zipped directories to reflect a typical webapps directory structure.
4. The file name class_v01.zip has been changed to class97_v01.zip

CREDITS:
DavidF---Provided all of the smilie.pl information and example where to edit index.cgi.
this info was covered in a thread with maddog, Topic: Classifieds Version 0.1 08/30/02.

Aynglfyre---who noticed the smile.gif file name misspelled smilie.gif.

Others who struggled through this much needed Script after ver.97 updated and posted in 
the Webapps forums. The fix information was gathered from posts in the Webapps forums.

All should thank  Brad (webmaster@indie-central.ca)" for writting this script and graciously
providing a intergrated Webapps script.
