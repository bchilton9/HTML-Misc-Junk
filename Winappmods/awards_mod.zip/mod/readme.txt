      WebAwards v.01
      
      WebAwards is a WebAPP module for version 0.9.8.  It is based on MidMart Awards.
      
      Be kind, this is my first attempt at a module :)
      
      WebAwards will allow the administrator to rate and grant up to three awards to 
      applicants and maintain a list of winners.  As set up, only the top two winners 
      (gold and silver) will be added to the winners list.
      
      WebAwards comes with an Admin Panel which can be accessed via ModMgr or directly 
      by linking to htt://yourdomain.com/cgi-bin/mods/awards/admin/admin.cgi (if you 
      are using the default setup).
      
      Applicants submit their site by filling out a form.  Some basic error checking is 
      	applied (missing email, site name, site url and description).  If their 
      	application is successful, they are shown a "thank you page" and a "thank 
      	you" email is sent.  The text of all messages is configurable.
      
      From the Admin Panel, you can 
      	Access the applicant site
      	Assign a rating from 1 to 10 to the site 
      	Discard the site if it doesn't conform to your criteria
      	Assign one of the three awards.
      	
      Admin Functions are: 
      	Review New Sites:  This brings up a list of all sites that have applied but have 
      			   not been rated by you.  This makes it very easy to determine 
      			   which sites still need to be visited.  
      			   You visit a site by clicking on the site's title.  You can then
      			   rate that site using the dropdown box.
      			   Once you have rated a site, it disappears from the "New Sites" 
      			   listing. and is sent to a temporary database.  
      			   To remove a site from contention, just click the "Send to Trash" 
      			   button.
      	Final Selection    This will allow you to select one of the sites you have rated to 
      			   receive one of your awards.  Select the award from the drop down.
      			   If you have awarded the gold or silver, the site information is 
      			   automatically copied to the winner's list.  Email notifications 
      			   are automatically sent to all award winners. 
        Empty Trash        This will clear the temporary database and send the "Loser" email 
                                 to all deleted sites.
                                 
      Installation;
      
      Installation should be fairly simple.
      
      1  Unzip the archive to your local drive.  You will have two folders, "Awards" and "Other".  
         The "Awards" directory contains the files for the Awards mod.  The "Other" directory 
         contains the optional "awards downloader" if you care to use it.
      
      2  Check the "shebang" line at the top of all "cgi" files.  By default it is set to !/user/bin/perl.
         If the path on your host if different, you will need to change this.
      
      3  Check the variables contained in "award.setup". The file is commented so you should have 
         no problems with it.  Don't forget to check the contents of your email letters and change 
         as needed.
         
      
      4. At the bottom of "award.cgi", at about line 1077 are two small routines that I use for 
      	 adding a small promotional message to the bottom of the email messages and pages that 
      	 the applicant sees.  Modify these as you see fit.
         
      5.  Index.cgi is essentially the application form that your applicant sites fill out.  Beginning
          at line 89, I have added a table row to explain something about my award.  If you don't 
          want this, just delete the first <tr><td colspan = 2> and the closing </td></tr>.  
          Otherwise, you can modify this for your purposes. 
       
      
      6.   Upload the entire content of the "Awards" folder into your "mods" folder.  Upload as "ascii" 
          You should have a structure that looks like this
         
         /mods/
             /awards   
             	index.cgi -     The signup page that your applicant sees. At line 89 - I have 
             	                entered
             	award.setup    The file containing your variables.
             	award.cgi       The main program.
             	config.dat      The configuration file needed by modmgr
             	/db  
             		rated.dat   db of sites that have been visited and rated
             		temp.dat    db of new applicants
             		trash.dat   db of your discards - these get loser emails.
             		winners.dat db of all your first and second place winners.
             	/language
             		english.dat    your language db
             	/admin
             		admin.cgi      administrators panel.
             		
      7.  Set permissions
          		
          All directories should be "world writeable" or chmod 777 (755 if you have SuExec enabled)
              		
          All files that end in .cgi should be execute enabled (chmod 755)
          All other files should be writeable (chmod 777 or 666). Whatever permissions acceptible to 
          your server.
          
      8.  Add a link to http://yourdomain.com/cgi-bin/mods/awards/index.cgi somewhere on your menu and 
          off you go. 
          
      Note:  The text color is "hard coded" to be "#000000" throughout tables.  You could easily 
          add a variable $textcolor to award.setup, then change all occurrance of "#000000" to 
          $textcolor.  I just didn't do it.  
          
      #############################################################################################
          
       Optional downloader.  As I was finishing this, it occurred to me that it might be nice
              to include the link to download the award graphic as part of the notification email.
              However, I didn't want anyone to leech the award, so I used a download script to hide 
              the location.  If you would like to do the same thing, then follow these instructions.
              
              1.  Create your graphic files for your awards and "zip" them.  I suggest that you 
                  upload these to a folder off your document root with a hard-to-guess name. 
                  eg:  /home/user/public_html/xxawards/
              
              2.  Check the perl location at the top of "download.cgi".  If it was ok in the other 
                  scripts, it will be ok here too.
                  There are five variables plainly marked at the top of "download.cgi". The first 
                  two should not need changing.
                   
                  my $downlog = "downlog.cgi";           #file to log downloads chmod 777 or 666
                  my $DLDB = "downdb.cgi";               #db to hold info on your downloadable files
                  my $siteURL = "http://yourdomain.com"; # Your base directory - no trailing slash.. :)
                  my $offSet = "-8";  			 # "-8" = 8 hours behind, "8" = 8 hours ahead
                  my $milTime = 0;		   	 # Use Military time "0" = no. "1" = yes
                  
                  The last two "offset" and "miltime" are used in the log file to stamp the 
                  download.  If you don't intend to look at the log file you really don't need to 
                  bother.
                  
                                   
              3.  Determine where you will put the download application.  I suggest you NOT put it 
                  in your WebApp tree, but in a separate directory in your CGI-BIN.
                  eg /cgi-bin/download/
                  Upload all three files (download.cgi,downdb.cgi, downlog.cgi)here.
                  Chmod 755 download.cgi
                  Chmod 777 downdb.cgi, downlog.cgi.
                  
              4.  Setting up for files for download.
                  I have left one line in downdb.cgi that will show you how to set up your files.
                  You can remove this line when you add your files.  The format is:
                  whatyoucallit.zip---http://yourdomain.com/yourdirectory/actualfilename.zip
                  
              5.  Using it in the awards mod.
                  Open "award.setup" and find the first, second and third place email notifications.
                  Include something like the following. 
                  You may pick up your award by clicking 
                  <http://yourdomain.com/cgi-bin/download/download.cgi?info=whatyoucallit.zip>
          
          
      ##############################################################################################    
          
     
          
      Try it out, I hope it works.
      
      ===============================================================================
      
      To Do in the future:
      
      	Make admin accessible by multiple administrators, so several people can rate the sites 
      	and the db will accumulate the total of ratings.
      	
      	Fix the button colors!!!
