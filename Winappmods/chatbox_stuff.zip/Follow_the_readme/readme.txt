Follow these steps and it should all work, just like mine! @nileo.com (I did not create this script),
I have simply edited for the webapp environment.

Step 1:
Open the '/cgi-bin/mods/tagbox/tagbox.cfg' file from the zip in your chosen editor and replace the
 URL/Paths with your own(sorry the webapp shortcuts aren't used!), save it!  



Step 2:
Upload both folders images,cgi-bin and the tagbox.html file directly to your route directory of your 
webapp installation (if using a standard webapp installation).  I have already created the file structure, 
so you shouldn't need to create anything.

..Alternatively, you could do this manually creating the following file structure:

/images/tagbox/smilies/bigsmile
/images/tagbox/smilies/frown.gif
/images/tagbox/smilies/smile.gif
/images/tagbox/smilies/wink.gif
/images/tagbox/smilies/mad.gif
/images/tagbox/smilies/tongue.gif
/tagbox.html
/cgi-bin/mods/tagbox/tagbox.cgi
/cgi-bin/mods/tagbox/tagbox.cfg



Step 3:
CHMOD
tagbox.cgi to 755
tagbox.html to 777


Step 4:
Open up the leftblock.txt and modify the YOURSITE.com to your own URL, save it!  N.B the reason the code is on
one line is to avoid mess-ups when copying and pasting, just select all and copy and paste into a left block.
To make it members only you should tick the members only in 'block adminstration''Left side block'


now cross your fingers, touch your nose, and say 'this ones for you jimmy!'