# common subs for the classifieds mod
# you can modify the header and footer here (via the navbars)

###########################
sub top_navbar {
###########################

# top "place an ad" graphic, hidden from Guests

print qq~
<table cellspacing="0" cellpadding="0" border="0" width="100%">
	<tr>
		<td align="center">~;
		unless ($username eq "$anonuser") {
			print qq~<a href="$classurl/index.cgi?action=postads"><img src="$decoimgs/classifieds.gif" border="0"><BR><small>$class_user{'004'}</a></small>~;
		}
		print qq~
		</td>
	</tr>
</table>
<P>
~;

}		

###########################
sub bottom_navbar {
###########################

# it would be nice if you leave my website link :)
$copyleft = qq~<a href="http://www.indie-central.ca/webapp/cgi-bin/index.cgi" target="_blank">Classifieds for WebAPP v2.0</a>~;

# build the category drop down list
jump_to();

open(CFILE, "$admindir/config.dat") || error("$class_error{'001'} $admindir/config.dat"); 
	lock(CFILE); 
	chomp(@config = <CFILE>); 
	unlock(CFILE); 
close(CFILE); 

# Are guests allowed to view ads?
if ($config[4] eq "on") { $guestok = 1; }
else { $guestok = 0; }	

print qq~<P>
<table cellspacing="0" cellpadding="5" border="0" align="center">
	<tr>
		<td align="left">~;
		searchbox();
		print qq~
		</td>
		<td align="right">~;
		if ($username ne "$anonuser" || $guestok == 1) {
			print qq~
			<form action="$classurl/index.cgi" method="get">
			<select name="viewcat">$selectoptions</select>
			<input type="submit" class="button" value="$btn{'014'}">
			<input type="hidden" name="action" value="ads">
			</form>~;
		}
		print qq~
		</td>
	</tr>
	<tr>
		<td align="center" colspan="2"><small>~;
		if ($username eq "admin") {
			print qq~<a href="$classurl/admin/admin.cgi"><b>$class_admin{'013'}</b></a>~;
		}
		print qq~
		<BR>$copyleft
		</small></td>
	</tr>
</table>
~;

}		

###########################
sub navbar_main {
###########################

# only used on front page

# it would be nice if you leave my website link :)
$copyleft = qq~<a href="http://www.indie-central.ca/webapp/cgi-bin/index.cgi" target="_blank">Classifieds for WebAPP v2.0</a>~;

print qq~
<BR><BR>
<table cellspacing="0" cellpadding="0" border="0" width="100%">
<tr>
	<td align="center">~;
		if ($username ne "$anonuser" || $guestok == 1) {
			searchbox();
		}
	print qq~
	</td>
</tr>
<tr>
	<td align="center"><small>~;
	if ($username eq "admin") {
		print qq~<a href="$classurl/admin/admin.cgi"><b>$class_admin{'013'}</b></a>~;
	}
	print qq~
	<BR>$copyleft
	</small></td>
</tr>
</table>
~;

}

##########################
sub the_date {
##########################

# version 2 implements it's own date format -- I figured that 
# the time of the ad wasn't all that necessary
# so we only deal with day, month and year
# the standard WebAPP getdate() is still called, just in case there is any weird compatibility issue

($sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdst) = localtime(time + 3600*$timeoffset);
$this_month = $mon+1;
$this_day = $mday;
$this_year = 1900 + $year;
$the_date = "$this_month/$this_day/$this_year";

} # end the_date sub

##########################
sub print_expiry {
##########################

# used to display the ad expiry date
# only seen by the Admin if they are editing the ad
# ad owner cannot change the expiry date

my $expiry_month =  shift;
my $expiry_day =  shift;
my $expiry_year =  shift;

# this gets ugly

if ($expiry_month == 1) { $txt_month = $class_user{'042'}; }
elsif ($expiry_month == 2) { $txt_month = $class_user{'043'}; }
elsif ($expiry_month == 3) { $txt_month = $class_user{'044'}; }
elsif ($expiry_month == 4) { $txt_month = $class_user{'045'}; }
elsif ($expiry_month == 5) { $txt_month = $class_user{'046'}; }
elsif ($expiry_month == 6) { $txt_month = $class_user{'047'}; }
elsif ($expiry_month == 7) { $txt_month = $class_user{'048'}; }
elsif ($expiry_month == 8) { $txt_month = $class_user{'049'}; }
elsif ($expiry_month == 9) { $txt_month = $class_user{'050'}; }
elsif ($expiry_month == 10) { $txt_month = $class_user{'051'}; }
elsif ($expiry_month == 11) { $txt_month = $class_user{'052'}; }
else { $txt_month = $class_user{'053'}; }

for ($z = 1; $z < 13; $z++) {
	if ($expiry_month eq $z) { $sel = "selected"; } 
	else { $sel = ""; } 
	if ($z == 1) { $z_month = $class_user{'042'}; }
	elsif ($z == 2) { $z_month = $class_user{'043'}; }
	elsif ($z == 3) { $z_month = $class_user{'044'}; }
	elsif ($z == 4) { $z_month = $class_user{'045'}; }
	elsif ($z == 5) { $z_month = $class_user{'046'}; }
	elsif ($z == 6) { $z_month = $class_user{'047'}; }
	elsif ($z == 7) { $z_month = $class_user{'048'}; }
	elsif ($z == 8) { $z_month = $class_user{'049'}; }
	elsif ($z == 9) { $z_month = $class_user{'050'}; }
	elsif ($z == 10) { $z_month = $class_user{'051'}; }
	elsif ($z == 11) { $z_month = $class_user{'052'}; }
	else { $z_month = $class_user{'053'}; }
	$monthdropdown = qq~$monthdropdown\n<option value="$z" $sel>$z_month</option>~; 
}
print qq~	
<select name="month" size="1">$monthdropdown</select>
&nbsp;
~;
for ($x = 1; $x < 32; $x++) {
	if ($expiry_day == $x) { $dsel = "selected"; } 
	else { $dsel = ""; } 
	$daydropdown = qq~$daydropdown\n<option value="$x" $dsel>$x</option>~; 
}	
print qq~	
<select name="day" size="1">$daydropdown</select>
&nbsp;

&nbsp;
<select name="year" size="1">~;
for ($a = 0; $a < 5; $a++) {
	$nextyr = $a+$this_year;
	if ($expiry_year == $nextyr) { $ysel = "selected"; } 
	else { $ysel = ""; } 
	print qq~<option value="$nextyr" $ysel>$nextyr</option>~;
}
print qq~
</select>
~;

} # end print_expiry sub		

##########################
sub new_expiry {
##########################

# seen by the Admin when they are adding or verifying 
# a submitted ad

# this gets ugly

if ($this_month == 1) { $txt_month = $class_user{'042'}; }
elsif ($this_month == 2) { $txt_month = $class_user{'043'}; }
elsif ($this_month == 3) { $txt_month = $class_user{'044'}; }
elsif ($this_month == 4) { $txt_month = $class_user{'045'}; }
elsif ($this_month == 5) { $txt_month = $class_user{'046'}; }
elsif ($this_month == 6) { $txt_month = $class_user{'047'}; }
elsif ($this_month == 7) { $txt_month = $class_user{'048'}; }
elsif ($this_month == 8) { $txt_month = $class_user{'049'}; }
elsif ($this_month == 9) { $txt_month = $class_user{'050'}; }
elsif ($this_month == 10) { $txt_month = $class_user{'051'}; }
elsif ($this_month == 11) { $txt_month = $class_user{'052'}; }
else { $txt_month = $class_user{'053'}; }

for ($z = 1; $z < 13; $z++) {
	if ($this_month eq $z) { $sel = "selected"; } 
	else { $sel = ""; } 
	if ($z == 1) { $z_month = $class_user{'042'}; }
	elsif ($z == 2) { $z_month = $class_user{'043'}; }
	elsif ($z == 3) { $z_month = $class_user{'044'}; }
	elsif ($z == 4) { $z_month = $class_user{'045'}; }
	elsif ($z == 5) { $z_month = $class_user{'046'}; }
	elsif ($z == 6) { $z_month = $class_user{'047'}; }
	elsif ($z == 7) { $z_month = $class_user{'048'}; }
	elsif ($z == 8) { $z_month = $class_user{'049'}; }
	elsif ($z == 9) { $z_month = $class_user{'050'}; }
	elsif ($z == 10) { $z_month = $class_user{'051'}; }
	elsif ($z == 11) { $z_month = $class_user{'052'}; }
	else { $z_month = $class_user{'053'}; }
	$monthdropdown = qq~$monthdropdown\n<option value="$z" $sel>$z_month</option>~; 
}
print qq~	
<select name="month" size="1">$monthdropdown</select>
&nbsp;
~;
for ($x = 1; $x < 32; $x++) {
	if ($this_day == $x) { $dsel = "selected"; } 
	else { $dsel = ""; } 
	$daydropdown = qq~$daydropdown\n<option value="$x" $dsel>$x</option>~; 
}	
print qq~	
<select name="day" size="1">$daydropdown</select>
&nbsp;

&nbsp;
<select name="year" size="1">~;
for ($a = 0; $a < 5; $a++) {
	$nextyr = $a+$this_year;
	print qq~<option value="$nextyr">$nextyr</option>~;
}
print qq~
</select>
~;

} # end new_expiry sub		

###########################
sub searchbox {
###########################

print qq~
<form action="$classurl/index.cgi\?action=search_ads" method="post">
	<input type="hidden" name="action" value="search_ads">
	<input type="text" name="pattern" size="16">
	&nbsp;<input type="submit" class="button" value="$class_user{'108'}">
</form>
~;

}		

####################
sub print_smilies {
####################

# v2.0 no longer relies on main WebAPP script for smilie code or graphics

print qq~
<table border="0" cellspacing="0" cellpadding="2">
<tr>
<td class="menutable" align="left" valign="middle">
&nbsp;<b>$class_user{'065'}</b></td>
</tr>
<tr><td class="menutable">
<table width="100%" cellpadding="2" cellspacing="1">
<tr>
<td class="menubackcolor" align="left" valign="middle">
<a href="javascript:addCode('[bones]')"><img src="$smilies/bones.gif" border="0" alt="$class_user{'073'}" align="absmiddle"></a>
<a href="javascript:addCode('[confused]')"><img src="$smilies/confused.gif" border="0" alt="$class_user{'074'}" align="absmiddle"></a>
<a href="javascript:addCode('[cool]')"><img src="$smilies/cool.gif" border="0" alt="$class_user{'075'}" align="absmiddle"></a>
<a href="javascript:addCode('[cry]')"><img src="$smilies/cry.gif" border="0" alt="$class_user{'076'}" align="absmiddle"></a>
<a href="javascript:addCode('[eek]')"><img src="$smilies/eek.gif" border="0" alt="$class_user{'077'}" align="absmiddle"></a>
<a href="javascript:addCode('[evil]')"><img src="$smilies/evil.gif" border="0" alt="$class_user{'078'}" align="absmiddle"></a>
<a href="javascript:addCode('[frown]')"><img src="$smilies/frown.gif" border="0" alt="$class_user{'079'}" align="absmiddle"></a>
<a href="javascript:addCode('[grin]')"><img src="$smilies/grin.gif" border="0" alt="$class_user{'080'}" align="absmiddle"></a>
<a href="javascript:addCode('[bounce]')"><img src="$smilies/bounce.gif" border="0" alt="$class_user{'081'}" align="absmiddle"></a>
<a href="javascript:addCode('[lol]')"><img src="$smilies/lol.gif" border="0" alt="$class_user{'082'}" align="absmiddle"></a>
<a href="javascript:addCode('[mad]')"><img src="$smilies/mad.gif" border="0" alt="$class_user{'083'}" align="absmiddle"></a>
<a href="javascript:addCode('[nonsense]')"><img src="$smilies/nonsense.gif" border="0" alt="$class_user{'084'}" align="absmiddle"></a>
<a href="javascript:addCode('[oops]')"><img src="$smilies/oops.gif" border="0" alt="$class_user{'085'}" align="absmiddle"></a>
<a href="javascript:addCode('[rolleyes]')"><img src="$smilies/rolleyes.gif" border="0" alt="$class_user{'086'}" align="absmiddle"></a>
<a href="javascript:addCode('[smile]')"><img src="$smilies/smile.gif" border="0" alt="$class_user{'087'}" align="absmiddle"></a>
<a href="javascript:addCode('[tongue]')"><img src="$smilies/tongue.gif" border="0" alt="$class_user{'088'}" align="absmiddle"></a>
<a href="javascript:addCode('[wink]')"><img src="$smilies/wink.gif" border="0" alt="$class_user{'089'}" align="absmiddle"></a>
<a href="javascript:addCode('[ninja]')"><img src="$smilies/ninja.gif" border="0" alt="$class_user{'090'}" align="absmiddle"></a>
</td>
</tr>
</table></td>
</tr>
</table>
~;

}

####################
sub print_ubbc {
####################

# v2.0 no longer relies on main WebAPP script for smilie code or graphics

# removed UBBC external linking methods (web, email, img)
# you can reinsert this code down below if you want to allow it
# <a href="javascript:addCode('[url][/url]')"><img src="$ubbcgfx/url.gif" align="absmiddle" width="23" height="22" alt="$class_user{'061'}" border="0"></a>
# <a href="javascript:addCode('[img][/img]')"><img src="$ubbcgfx/img.gif" align="absmiddle" width="23" height="22" alt="$class_user{'062'}" border="0"></a>
# <a href="javascript:addCode('[email][/email]')"><img src="$ubbcgfx/email2.gif" align="absmiddle" width="23" height="22" alt="$class_user{'063'}" border="0"></a>

print qq~
<table border="0" cellspacing="0" cellpadding="2">
<tr>
<td class="menutable" align="left" valign="middle">
&nbsp;<b>$class_user{'056'}</b></td>
</tr>
<tr><td class="menutable">
<table width="100%" cellpadding="2" cellspacing="1">
<tr>
<td class="menubackcolor" align="left" valign="middle">
<a href="javascript:addCode('[b][/b]')"><img src="$ubbcgfx/bold.gif" align="absmiddle" width="23" height="22" alt="$class_user{'057'}" border="0"></a>
<a href="javascript:addCode('[i][/i]')"><img src="$ubbcgfx/italicize.gif" align="absmiddle" width="23" height="22" alt="$class_user{'058'}" border="0"></a>
<a href="javascript:addCode('[u][/u]')"><img src="$ubbcgfx/underline.gif" align="absmiddle" width="23" height="22" alt="$class_user{'059'}" border="0"></a>
<a href="javascript:addCode('[sub][/sub]')"><img src="$ubbcgfx/sub.gif" align="absmiddle" width="23" height="22" alt="$class_user{'067'}" border="0"></a>
<a href="javascript:addCode('[sup][/sup]')"><img src="$ubbcgfx/sup.gif" align="absmiddle" width="23" height="22" alt="$class_user{'068'}" border="0"></a>
<a href="javascript:addCode('[strike][/strike]')"><img src="$ubbcgfx/strike.gif" align="absmiddle" width="23" height="22" alt="$class_user{'069'}" border="0"></a>
<a href="javascript:addCode('[left][/left]')"><img src="$ubbcgfx/left.gif" align="absmiddle" width="23" height="22" alt="$class_user{'071'}" border="0"></a>
<a href="javascript:addCode('[center][/center]')"><img src="$ubbcgfx/center.gif" align="absmiddle" width="23" height="22" alt="$class_user{'060'}" border="0"></a>
<a href="javascript:addCode('[right][/right]')"><img src="$ubbcgfx/right.gif" align="absmiddle" width="23" height="22" alt="$class_user{'072'}" border="0"></a>
<a href="javascript:addCode('[pre][/pre]')"><img src="$ubbcgfx/pre.gif" align="absmiddle" width="23" height="22" alt="$class_user{'070'}" border="0"></a>
<a href="javascript:addCode('[list][*][*][*][/list]')"><img src="$ubbcgfx/list.gif" align="absmiddle" width="23" height="22" alt="$class_user{'066'}" border="0"></a>&nbsp;
<select name="color" onChange="showColor(this.options[this.selectedIndex].value)">
<option value="Black" selected>$class_user{'026'}</option>
<option value="Red">$class_user{'027'}</option>
<option value="Yellow">$class_user{'028'}</option>
<option value="Pink">$class_user{'029'}</option>
<option value="Green">$class_user{'030'}</option>
<option value="Orange">$class_user{'031'}</option>
<option value="Purple">$class_user{'032'}</option>
<option value="Blue">$class_user{'033'}</option>
<option value="Beige">$class_user{'034'}</option>
<option value="Brown">$class_user{'035'}</option>
<option value="Teal">$class_user{'036'}</option>
<option value="Navy">$class_user{'037'}</option>
<option value="Maroon">$class_user{'038'}</option>
<option value="LimeGreen">$class_user{'039'}</option>
</select>
</td>
</tr>
</table></td>
</tr>
</table>
~;

} # end UBBC

############ 
sub jump_to { 
############ 

# generates the category drop-down list

open(FILE, "$adsdb/cats.dat") || error("$class_error{'001'} $adsdb/cats.dat"); 
	lock(FILE); 
	@jumptofiles = <FILE>; 
	unlock(FILE); 
close(FILE); 

@jumptofiles = (sort { $a cmp $b } @jumptofiles);

for ($a = 0; $a < @jumptofiles; $a++) {
	($longname, $shortname, $dummy, $dummy) = split(/\|/, $jumptofiles[$a]);
	$selectoptions .= qq~<option value="$shortname">$longname</option>~; 
}


} # end sub jump_to


############
sub do_ubbc {
############

# external linking methods disabled
# as well as some others (code, blockquote
	
	$message =~ s~\[\[~\{\{~g;
	$message =~ s~\]\]~\}\}~g;
	$message =~ s~\n\[~\[~g;
	$message =~ s~\]\n~\]~g;
	$message =~ s~\<br\>~ <br>~g;
	$message =~ s~\<pipe\>~\|~g;
	$message =~ s~\[hr\]\n~<hr size="1">~g;
	$message =~ s~\[hr\]~<hr size="1">~g;
	$message =~ s~\[b\]~<b>~isg;
	$message =~ s~\[\/b\]~</b>~isg;
	$message =~ s~\[i\]~<i>~isg;
	$message =~ s~\[\/i\]~</i>~isg;
	$message =~ s~\[u\]~<u>~isg;
	$message =~ s~\[\/u\]~</u>~isg;
#	$message =~ s~\[img\](.+?)\[\/img\]~<a href="$1" target="_blank"><img src="$1" width="50" height="50" alt="" border="0"></a>~isg;
	$message =~ s~\[color=(\S+?)\]~<font color="$1">~isg;
	$message =~ s~\[\/color\]~</font>~isg;
#	$message =~ s~\[quote\]<br>(.+?)<br>\[\/quote\]~<blockquote><hr align=left width=40%>$1<hr align=left width=40%></blockquote>~isg;
#	$message =~ s~\[quote\](.+?)\[\/quote\]~<blockquote><hr align=left width=40%><b>$1</b><hr align=left width=40%></blockquote>~isg;
	$message =~ s~\[fixed\]~<font face="Courier New">~isg;
	$message =~ s~\[\/fixed\]~</font>~isg;
	$message =~ s~\[sup\]~<sup>~isg;
	$message =~ s~\[\/sup\]~</sup>~isg;
	$message =~ s~\[strike\]~<strike>~isg;
	$message =~ s~\[\/strike\]~</strike>~isg;
	$message =~ s~\[sub\]~<sub>~isg;
	$message =~ s~\[\/sub\]~</sub>~isg;
	$message =~ s~\[left\]~<div align="left">~isg;
	$message =~ s~\[\/left\]~</div>~isg;
	$message =~ s~\[center\]~<center>~isg;
	$message =~ s~\[\/center\]~</center>~isg;
	$message =~ s~\[right\]~<div align="right">~isg;
	$message =~ s~\[\/right\]~</div>~isg;
	$message =~ s~\[list\]~<ul>~isg;
	$message =~ s~\[\*\]~<li>~isg;
	$message =~ s~\[\/list\]~</ul>~isg;
	$message =~ s~\[pre\]~<pre>~isg;
	$message =~ s~\[\/pre\]~</pre>~isg;
#	$message =~ s~\[code\](.+?)\[\/code\]~<blockquote><font face="Courier New">code:</font><hr align=left width=40%><font face="Courier New"><pre>$1</pre></font><hr align=left width=40%></blockquote>~isg;
#	$message =~ s~\[email\](.+?)\[\/email\]~<a href="mailto:$1">$1</a>~isg;
#	$message =~ s~\[url\]www\.\s*(.+?)\s*\[/url\]~<a href="http://www.$1" target="_blank">www.$1</a>~isg;
#	$message =~ s~\[url=\s*(\w+\://.+?)\](.+?)\s*\[/url\]~<a href="$1" target="_blank">$2</a>~isg;
#	$message =~ s~\[url=\s*(.+?)\]\s*(.+?)\s*\[/url\]~<a href="http://$1" target="_blank">$2</a>~isg;
#	$message =~ s~\[url\]\s*(.+?)\s*\[/url\]~<a href="$1" target="_blank">$1</a>~isg;
	$message =~ s~([^\w\"\=\[\]]|[\n\b]|\A)\\*(\w+://[\w\~\.\;\:\,\$\-\+\!\*\?/\=\&\@\#\%]+[\w\~\.\;\:\$\-\+\!\*\?/\=\&\@\#\%])~$1<a href="$2" target="_blank">$2</a>~isg;
	$message =~ s~([^\"\=\[\]/\:\.]|[\n\b]|\A)\\*(www\.[\w\~\.\;\:\,\$\-\+\!\*\?/\=\&\@\#\%]+[\w\~\.\;\:\$\-\+\!\*\?/\=\&\@\#\%])~$1<a href="http://$2" target="_blank">$2</a>~isg;
	$message =~ s~\{\{~\[~g;
	$message =~ s~\}\}~\]~g;
}

############
sub do_smilies {
############

$message =~ s~\[bones\]~<img src="$imagesurl/forum/smilies/bones.gif" alt="">~g;
$message =~ s~\[bounce\]~<img src="$imagesurl/forum/smilies/bounce.gif" alt="">~g;
$message =~ s~\:-\?~<img src="$imagesurl/forum/smilies/confused.gif" alt="">~g;
$message =~ s~\[confused\]~<img src="$imagesurl/forum/smilies/confused.gif" alt="">~g;
$message =~ s~\Q8)\E~<img src="$imagesurl/forum/smilies/cool.gif" alt="">~g;
$message =~ s~\Q8-)\E~<img src="$imagesurl/forum/smilies/cool.gif" alt="">~g;
$message =~ s~\[cool\]~<img src="$imagesurl/forum/smilies/cool.gif" alt="">~g;
$message =~ s~\[cry\]~<img src="$imagesurl/forum/smilies/cry.gif" alt="">~g;
$message =~ s~\:o~<img src="$imagesurl/forum/smilies/eek.gif" alt="">~g;
$message =~ s~\:\-o~<img src="$imagesurl/forum/smilies/eek.gif" alt="">~g;
$message =~ s~\[eek\]~<img src="$imagesurl/forum/smilies/eek.gif" alt="">~g;
$message =~ s~\[evil\]~<img src="$imagesurl/forum/smilies/evil.gif" alt="">~g;
$message =~ s~\:\(~<img src="$imagesurl/forum/smilies/frown.gif" alt="">~g;
$message =~ s~\:-\(~<img src="$imagesurl/forum/smilies/frown.gif" alt="">~g;
$message =~ s~\[frown\]~<img src="$imagesurl/forum/smilies/frown.gif" alt="">~g;
$message =~ s~\:D~<img src="$imagesurl/forum/smilies/grin.gif" alt="">~g;
$message =~ s~\:-D~<img src="$imagesurl/forum/smilies/grin.gif" alt="">~g;
$message =~ s~\[grin\]~<img src="$imagesurl/forum/smilies/grin.gif" alt="">~g;
$message =~ s~\[lol\]~<img src="$imagesurl/forum/smilies/lol.gif" alt="">~g;
$message =~ s~\:x~<img src="$imagesurl/forum/smilies/mad.gif" alt="">~g;
$message =~ s~\:-x~<img src="$imagesurl/forum/smilies/mad.gif" alt="">~g;
$message =~ s~\[mad\]~<img src="$imagesurl/forum/smilies/mad.gif" alt="">~g;
$message =~ s~\[ninja\]~<img src="$imagesurl/forum/smilies/ninja.gif" alt="">~g;
$message =~ s~\[nonsense\]~<img src="$imagesurl/forum/smilies/nonsense.gif" alt="">~g;
$message =~ s~\[oops\]~<img src="$imagesurl/forum/smilies/oops.gif" alt="">~g;
$message =~ s~\[razz\]~<img src="$imagesurl/forum/smilies/razz.gif" alt="">~g;
$message =~ s~\[rolleyes\]~<img src="$imagesurl/forum/smilies/rolleyes.gif" alt="">~g;
$message =~ s~\:\)~<img src="$imagesurl/forum/smilies/smile.gif" alt="">~g;
$message =~ s~\:-\)~<img src="$imagesurl/forum/smilies/smile.gif" alt="">~g;
$message =~ s~\[smile\]~<img src="$imagesurl/forum/smilies/smile.gif" alt="">~g;
$message =~ s~\:P~<img src="$imagesurl/forum/smilies/tongue.gif" alt="">~g;
$message =~ s~\:-P~<img src="$imagesurl/forum/smilies/tongue.gif" alt="">~g;
$message =~ s~\[tongue\]~<img src="$imagesurl/forum/smilies/tongue.gif" alt="">~g;
$message =~ s~\;-\)~<img src="$imagesurl/forum/smilies/wink.gif" alt="">~g;
$message =~ s~\[wink\]~<img src="$imagesurl/forum/smilies/wink.gif" alt="">~g;
$message =~ s~\[tarzan\]~<img src="$imagesurl/forum/smilies/tarzan.gif" alt="">~g;

}

###########################
sub mod_langsupp {
###########################

$modlangfail = "0";

if ($username ne $anonuser) {
		open(FILE, "$memberdir/$username.dat");
		lock(FILE);
		@settings = <FILE>;
		unlock(FILE);
		close(FILE);

		for( $i = 0; $i < @settings; $i++ ) {
			$settings[$i] =~ s~[\n\r]~~g;
		}
		
		if ($settings[0] ne $password && $action ne "logout") { error("$err{'002'}"); }
		else {
			$realname = $settings[1];
			$realemail = $settings[2];
			$userlang = $settings[15];
		}
		
}

		if ($userlang eq "") { $userlang = $language; }
						
			 if ($modlangfail ne "1") {
			 @modlanguage = $userlang;
			 foreach $rec (@modlanguage){
			 chomp($rec);
			 ($modlang,$dummy)=split(/\./,$rec);
			 }
			 } else {
			 @modlanguage = $language;
			 foreach $rec (@modlanguage){
			 chomp($rec);
			 ($modlang,$dummy)=split(/\./,$rec);
			 }
		}

eval {
	require "$classdir/language/$modlang.dat";
	
	if ($IIS != 2) {
		if ($IIS == 0) {
			if ($ENV{'SERVER_SOFTWARE'} =~ m!IIS!) { $IIS = 1; }
		}
		if (($IIS) && ($0 =~ m!(.*)(\\|\/)!)) { chdir($1); }
		if ($IIS == 1) { print "HTTP/1.0 200 OK\n"; }
	}
};

if ($@) {$modlangfail = "1"; mod_langsuppfail();}

} # end sub

########################
sub mod_langsuppfail {
########################

eval {
	require "$classdir/language/$mod_lang";
	
	if ($IIS != 2) {
		if ($IIS == 0) {
			if ($ENV{'SERVER_SOFTWARE'} =~ m!IIS!) { $IIS = 1; }
		}
		if (($IIS) && ($0 =~ m!(.*)(\\|\/)!)) { chdir($1); }
		if ($IIS == 1) { print "HTTP/1.0 200 OK\n"; }
	}
};
if ($@) {
print "Content-type: text/html\n\n";
print qq~<h1>Software Error:</h1>
Execution of <b>$scriptname</b> has been aborted due a compilation error:<br>
<pre>$@</pre>
<p>If this problem persits, please contact the webmaster and inform him about date and time you've recieved this error.</p>
~;
	exit;
}

} # end sub 

##########################################################
######### subs shared by admin and the ad owner ##########
##########################################################

################# 
sub modify { 
################# 

	# version 2: admin ad options
	
	open(AFILE, "$admindir/config.dat") || error("$class_error{'001'} $admindir/config.dat"); 
		lock(AFILE); 
		chomp(@config = <AFILE>); 
		unlock(AFILE); 
	close(AFILE); 

	if ($config[3] == "" || $config[3] == "0") { $ad_length = 450; }
	else { $ad_length = $config[3]; }
	
	if ($config[5] eq "on") { $images = 1; }
	else { $images = 0; }
	
	if ($config[6] eq "on") { $imagesupload = 1; }
	else { $imagesupload = 0; }
	
	if ($config[8] eq "on") { $smilies_ok = 1; } 
	else { $smilies_ok = 0; }

	if ($config[9] eq "on") { $ubbc_ok = 1; } 
	else { $ubbc_ok = 0; }
	
	open(FILE, "$adsrc/$info{'id'}.txt") || error("$class_error{'001'} $adsrc/$info{'id'}.txt"); 
		lock(FILE); 
		chomp(@articles = <FILE>); 
		unlock(FILE); 
	close(FILE); 
 
	$navbar = "$class_user{'010'} <a href=\"$classurl/index.cgi\" class=\"nav\">$class_user{'001'}</a> $class_user{'010'} $class_admin{'012'}"; 
	print_top(); 
	print qq~
	<table width="100%"> 
~; 
 
	for ($a = 0; $a < @articles; $a++) { 
		($msub, $mname, $musername, $memail, $mdate, $mmessage, $price, $phone, $adimg, $expiremonth, $expireday, $expireyear) = split(/\|/, $articles[$a]); 
 
		$mmessage = htmltotext($mmessage); 
 
		print qq~
		<form action="$classurl/index.cgi?action=modify2" method="post" name="creator"> 
		<input type="hidden" name="cat" value="$info{'cat'}"> 
		<input type="hidden" name="id" value="$info{'id'}"> 
		<input type="hidden" name="owner" value="$mname"> 
		<input type="hidden" name="viewnum" value="$a"> 
		<tr> 
			<td><b>$class_user{'007'}:</b></td>
			<td valign="top"><a href="mailto:$memail">$mname</a></td>
		</tr>
		<tr>
			<td><b>$class_admin{'018'}:</b></td>
			<td>$mdate</td>
		</tr>
		<tr>
			<td><b>$class_admin{'008'}:</b></td>
			<td><input type="text" name="subject" value="$msub" size="30"></td>
		</tr>
		<tr>
			<td><b>$class_admin{'009'}:</b></td>
			<td>
			<script language="javascript" type="text/javascript">
		<!--
		function addCode(anystr) { 
		document.creator.message.value+=anystr;
		} 
		function showColor(color) { 
		document.creator.message.value+="[color="+color+"][/color]";
		}
		// -->
		</script>
			<textarea name="message" rows="15" cols="35">$mmessage</textarea></td>
		</tr>
		<tr>
		<td>&nbsp;</td>
		<td align="left">~;
		
		if ($ubbc_ok == 1) { 
			print_ubbc();
		}
		if ($smilies_ok == 1) { 
			print "<br>";
			print_smilies(); 
		}
		
	print qq~
	</td></tr>
		<tr>
			<td><b>$class_user{'095'}</b></td>
			<td class="newstextsmall">
		~;
		# version 2
		# some image figuring out gobbledygook
		
		if ($adimg ne "") { # the adimg field includes some info
			if ($adimg =~ /^http/) { 
				print qq~
				<input type="text" name="adimg" size="40" maxlength="175" value="$adimg">&nbsp;
				<a href="$adimg" target="_blank"><img src="$decoimgs/photo.gif" alt="$class_admin{'039'}" border="0"></a>
				<BR>$class_user{'096'}
				~;		 
			}
			else { # it's a local file
				print qq~
				<script language="javascript">
				<!--
				function popIT(url){
				remote = window.open(url,"remotewin","width=500,height=400,scrollbars=1,status=1");
				remote.location.href = url;
				if (remote.opener == null) remote.opener = window;
				}
				-->
				</script>
				<input type="text" name="adimg" size="40" maxlength="175" value="$adimg">&nbsp;
				<a href="$userimgs/$adimg" target="_blank"><img src="$decoimgs/photo.gif" alt="$class_admin{'038'}" border="0"></a>
				<BR><img src="$decoimgs/dot.gif">&nbsp;<a href="javascript:popIT('$classurl/upload.cgi')">$class_user{'097'}</a>
				~;
			}	
		}
		elsif ($images == 1) { # no img associated with ad, but images are allowed
			if ($imagesupload == 0) { # admin wants linked images
				print qq~
				<input type="text" name="adimg" size="40" maxlength="175">
				<BR>$class_user{'096'}
				~;		 
			}
			else { # admin allows for local files
				print qq~
				<script language="javascript">
				<!--
				function popIT(url){
				remote = window.open(url,"remotewin","width=500,height=400,scrollbars=1,status=1");
				remote.location.href = url;
				if (remote.opener == null) remote.opener = window;
				}
				-->
				</script>
				<input type="text" name="adimg" size="40" maxlength="175">
				<BR><a href="javascript:popIT('$classurl/upload.cgi')">$class_user{'097'}</a>
				~;
			}
		}
		else { # there is no img associated with ad, and the admin doesn't allow them 
			print qq~$class_admin{'056'}~;
		}

		print qq~
			</td>
		</tr>
		<tr>
			<td><b>$class_user{'092'}</b></td>
			<td class="newstextsmall">$config[11]&nbsp;<input type="text" name="price" size="8" maxlength="8" value="$price">&nbsp;($config[10])</td>
		</tr>
		<tr>
			<td><b>$class_user{'094'}</b></td>
			<td class="newstextsmall"><input type="text" name="phone" size="14" maxlength="14" value="$phone">&nbsp;($class_user{'091'})</td>
		</tr>
		<tr>
		~;
		if ($username eq "admin") {	
			print qq~
			<td><b>$class_user{'054'}</b></td>
			<td>~;
			print_expiry($expiremonth,$expireday,$expireyear);
#			print qq~&nbsp;$class_admin{'040'}&nbsp;$info{'exp'}
			print qq~</td>~;
		}
		else {
			print qq~
			<td colspan="2">
			<input type="hidden" name="month" value="$expiremonth"> 
			<input type="hidden" name="day" value="$expireday"> 
			<input type="hidden" name="year" value="$expireyear">
			</td>
			~;
		}			
		print qq~
		</tr>
		<tr><td>&nbsp;</td>
		<td><BR><BR><input type="submit" name="moda" value="$class_admin{'006'}" class="button">&nbsp;~;
		if ($username eq "admin") {
		print qq~
		<input type="submit" name="moda" value="$class_admin{'005'}" class="button">~;
		}
		print qq~
		</td></tr> 
		<tr> 
			<td colspan="3"><hr size="1"></td> 
		</tr> 
		</form> 
~; 
	} 
	open(FILE, "$adsdb/cats.dat"); 
		lock(FILE); 
		chomp(@cats = <FILE>); 
		unlock(FILE); 
	close(FILE); 
	
	@cats = (sort { $a cmp $b } @cats);
 
	foreach $catslist (@cats) { 
		chomp($catslist); 
		($name, $link) = split(/\|/, $catslist); 
		if ($info{'cat'} eq $link) { $sel = "selected"; } 
		else { $sel = ""; } 
		$catsdropdown = qq~$catsdropdown\n<option value="$link" $sel>$name~; 
	} 
	
	if ($username eq "admin") {
	print qq~
	<form action="$adminurl/$admin_cgi?op=moveads" method="post"> 
	<tr> 
		<td colspan="3">Move to: <select name="tocat">$catsdropdown</select> 
		<input type="hidden" name="topic" value="$info{'id'}"> 
		<input type="hidden" name="oldcat" value="$info{'cat'}">
		<input type="submit" value="Move" class="button"></td> 
	</tr> 
	</form> 
	</table> 
	~; 
	}
	
	print_bottom(); 
	exit; 
}  # end sub

################# 
sub modify2 { 
################# 

	# only the ad owner or Admin can modify the ad
	if ($username ne "$input{'owner'}" && $username ne "admin") { error("$class_error{'005'}"); } 

	open(FILE, "$adsrc/$input{'id'}.txt") || error("$class_error{'001'} $adsrc/$input{'id'}.txt"); 
		lock(FILE); 
		@data = <FILE>; 
		unlock(FILE); 
	close(FILE); 
	
	open(AFILE, "$admindir/config.dat") || error("$class_error{'001'} $admindir/config.dat"); 
		lock(AFILE); 
		chomp(@config = <AFILE>); 
		unlock(AFILE); 
	close(AFILE); 
	
	if ($config[5] eq "on") { $images = 1; }
	else { $images = 0; }
	
	if ($config[6] eq "on") { $imagesupload = 1; }
	else { $imagesupload = 0; }
	
 
	for ($a = 0; $a < @data; $a++) {  
		($msub[$a], $mname[$a], $musername[$a], $museremail[$a], $mdate[$a], $mmessage[$a], $mprice[$a], $mphone[$a], $madimg[$a], $mexpm[$a], $mexpd[$a], $mexpy[$a]) = split(/\|/, $data[$a]); 
	} 
 
	$count = $a; 
 
	open(FILE, ">$adsrc/$input{'id'}.txt") || error("$class_error{'002'} $adsrc/$input{'id'}.txt"); 
	lock(FILE); 
	for ($b = 0; $b < @data; $b++) { 
		if ($input{'viewnum'} eq $b) { 
			if ($input{'moda'} eq $class_admin{'006'}) { # do I want to modify the ad?
				chomp($input{'subject'}); 
				chomp($input{'message'}); 
 
				$subj = htmlescape($input{'subject'}); 
				$mesg = htmlescape($input{'message'}); 
				
				$exp_month = $input{'month'};
				$exp_day = $input{'day'};
				$exp_year = $input{'year'};
				
				$ad_image = $input{'adimg'};	
				$theprice = $input{'price'};
				$thephone = $input{'phone'};
				
				if ($ad_image ne "") {
					if ($ad_image =~ /^http/) { 
						$cleanpath = $ad_image;
						$has_pic = 1;
					}
					else {
						$ad_image =~ s/.*[\/\\](.*)/$1/; 
						$case_it =  lc($ad_image);
						($name, $ext) = split(/\./, $case_it); 
						$cleanpath = "$input{'id'}.$ext";
						`mv $userimgsdir/temp/$ad_image $userimgsdir/$cleanpath`;
						$has_pic = 1;
					}
				}
				else { $cleanpath = $ad_image; }
 
				if ($input{'viewnum'} == 0) { 
					open(FILE2, "$adsdb/$input{'cat'}.cat") || error("$class_error{'001'} $adsdb/$input{'cat'}.cat"); 
						lock(FILE2); 
						@data2 = <FILE2>; 
						unlock(FILE2); 
					close(FILE2); 
 
					open(FILE2, ">$adsdb/$input{'cat'}.cat") || error("$class_error{'002'} $adsdb/$input{'cat'}.cat"); 
						lock(FILE2); 
						for ($c = 0; $c < @data2; $c++) { 
							($oldnum, $subject, $posternick, $postername, $posteremail, $postdate, $expmonth, $expday, $expyear, $haspic) = split(/\|/, $data2[$c]); 
							$haspic =~ s/[\n\r]//g; 
							if ($oldnum eq $input{'id'}) {  
								print FILE2 "$oldnum|$subj|$posternick|$postername|$posteremail|$postdate|$exp_month|$exp_day|$exp_year|$has_pic\n";  
							} 
							else { print FILE2 "$data2[$c]"; } 
						} 
						unlock(FILE2); 
					close(FILE2); 
				} 
				
				print FILE "$subj|$mname[$b]|$musername[$b]|$museremail[$b]|$mdate[$b]|$mesg|$theprice|$thephone|$cleanpath|$exp_month|$exp_day|$exp_year\n"; 

				# send IM to admin indicating that the user modified their ad
				
				unless ($username eq "admin") {
				
				$msgid = time;
	
				$imsubj = "$class_user{'093'} $the_date ($input{'id'})";
				$expires = "$expmonth-$expday-$expyear";
				$verifylink = "<BR><BR><a href=\"$classurl/index.cgi?action=viewads&amp;id=$input{'id'}&amp;exp=$expires\">$class_admin{'055'}</a>";
				$formatmsg = "$class_user{'040'} $realname $class_user{'055'}:<P>$mesg<P>$verifylink";		
	
				open (AFILE, "$memberdir/admin.msg") || error("$class_error{'001'} $memberdir/admin.msg");
					lock(AFILE);
					@imessages = <AFILE>;
					unlock(AFILE);
				close (AFILE);

				open (AFILE, ">$memberdir/admin.msg") || error("$class_error{'001'} $memberdir/admin.msg");
					lock(AFILE);
					print AFILE "$realname|$imsubj|$the_date|$formatmsg|$msgid\n";
					foreach $curm (@imessages) { print AFILE "$curm"; }
					unlock(AFILE);
				close(AFILE);
				
				}
			
				# end alert
			} 
			else { # nope, I want to delete the ad (admin only)
			
			if ($username eq "admin") {
				open (FILE2, "$adsdb/$input{'cat'}.cat") || error("$class_error{'001'} $adsdb/$input{'cat'}.cat"); 
					lock(FILE2); 
					@data2 = <FILE2>; 
					unlock(FILE2); 
				close (FILE2); 
 
				open (FILE2, ">$adsdb/$input{'cat'}.cat") || error("$class_error{'002'} $adsdb/$input{'cat'}.cat"); 
					lock(FILE2); 
					for ($a = 0; $a < @data2; $a++) { 
						($oldnum, $subject, $posternick, $postername, $posteremail, $postdate, $exp_month, $exp_day, $exp_year, $haspic) = split(/\|/, $data2[$a]); 
						$haspic =~ s/[\n\r]//g; 
 
						if ($oldnum == $input{'id'}) { 
							print FILE2 "$oldnum|$subject|$posternick|$postername|$posteremail|$postdate|$exp_month|$exp_day|$exp_year|$haspic\n"; 
						} 
						else { print FILE2 "$data2[$a]"; } 
					} 
					unlock(FILE2); 
				close(FILE2); 
 
				if ($input{'viewnum'} == 0) { 
					open(FILE2, "$adsdb/$input{'cat'}.cat") || error("$class_error{'001'} $adsdb/$input{'cat'}.cat"); 
						lock(FILE2); 
						@data2 = <FILE2>; 
						unlock(FILE2); 
					close(FILE2); 
 
					open(FILE2, ">$adsdb/$input{'cat'}.cat") || error("$class_error{'002'} $adsdb/$input{'cat'}.cat"); 
						lock(FILE2); 
						for ($a = 0; $a < @data2; $a++) { 
							($oldnum, $subject, $posternick, $postername, $posteremail, $postdate, $exp_month, $exp_day, $exp_year, $haspic) = split(/\|/, $data2[$a]); 
							$haspic =~ s/[\n\r]//g; 
							if ($oldnum eq $input{'id'}) {	} 
							else { print FILE2 "$data2[$a]"; } 
						} 
						unlock(FILE2); 
					close(FILE2); 
					
					# remove associated image if applicable
					opendir (DIR, "$userimgsdir");
						@picz = readdir(DIR); 
					closedir (DIR);
					
					foreach $pic (@picz) {
						($fname, $fext) = split (/\./, $pic); 
						if (grep (/^\b$input{'id'}\b/i, $fname)) { 
							unlink("$userimgsdir/$pic");
						}
					}
					
					# remove the ad text file and its count file
					unlink("$adsrc/$input{'id'}.txt");
					unlink("$adsrc/$input{'id'}.cnt");
							
					# update count file for category
					
					$a = 0;
					while ($data2[$a] ne '') { $a++; }
					$num = $a -1;
					open(COUNT, ">$adsdb/$input{'cat'}.cnt");
						lock(COUNT);
						print COUNT "$num";
						unlock(COUNT);
					close(COUNT);
					
					# end update

				} 
			} 
			}
		} 
		else { print FILE "$data[$b]"; } 
	} 
	unlock(FILE); 
	close(FILE); 
 
	print "Location: $classurl/index.cgi?action=ads&viewcat=$input{'cat'}\n\n"; 
	exit; 
} 

############### 
sub moveads { 
############### 

# only Admin can move an ad

	if ($username ne "admin") { error("$class_error{'005'}"); } 
 
	open (FILE, "$adsdb/$input{'oldcat'}.cat") || error("$class_error{'001'} $adsdb/$input{'oldcat'}.cat"); 
		lock(FILE); 
		@topics = <FILE>; 
		unlock(FILE); 
	close (FILE); 
 
	open (FILE, ">$adsdb/$input{'oldcat'}.cat") || error("$class_error{'002'} $adsdb/$input{'oldcat'}.cat"); 
		lock(FILE); 
		for ($a = 0; $a < @topics; $a++) { 
			($num, $subject, $posternick, $postername, $posteremail, $postdate, $expmonth, $expday, $expyear, $haspic) = split(/\|/,$topics[$a]); 
			$comments  =~ s~[\n\r]~~g; 
			if ($num ne $input{'topic'}) { print FILE "$topics[$a]"; } 
			else { $linetowrite = "$topics[$a]"; } 
		} 
		unlock(FILE); 
	close(FILE); 

	# update count file of 'from' category
		
	$a = 0;
	while ($topics[$a] ne '') { $a++; }
	$num = $a -1;
	open(OCOUNT, ">$adsdb/$input{'oldcat'}.cnt");
		lock(OCOUNT);
		print OCOUNT "$num";
		unlock(OCOUNT);
	close(OCOUNT);
	
	# end update
	 
	open (FILE, "$adsdb/$input{'tocat'}.cat"); 
		lock(FILE); 
		@topics = <FILE>; 
		unlock(FILE); 
	close (FILE); 
	
	open (FILE, ">$adsdb/$input{'tocat'}.cat"); 
		lock(FILE); 
		print FILE "$linetowrite"; 
		foreach $line (@topics) { 
			print FILE "$line"; 
		} 
		unlock(FILE); 
	close(FILE); 
	 
	# update count file of 'to' category
		
	$a = 0;
	while ($topics[$a] ne '') { $a++; }
	$num = $a +1;
	open(NCOUNT, ">$adsdb/$input{'tocat'}.cnt");
		lock(NCOUNT);
		print NCOUNT "$num";
		unlock(NCOUNT);
	close(NCOUNT);
	
	# end update
	
	print "Location: $adminurl/$admin_cgi?op=modifyads\n\n"; 
	exit; 
} 


1; # return true

