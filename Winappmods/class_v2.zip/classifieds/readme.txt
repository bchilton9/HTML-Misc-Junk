Classifieds Version 2.0 Release
Installation Instructions

Written by Brad (middleton@myprivacy.ca)
Based on code supplied with the WebApp 0.9.4 distribution.
Version 0.1 updated by mrmax in order to work with WebAPP v097

This MOD may be freely distributed or modified under the terms of the GNU General Public License.  
However, if you improve and/or redistribute it, please notify me so I know how the script is being used and improved! :)

OVERVIEW
This modification will add a "Classified Ads" area to your WebApp-powered website.  
(short but sweet, I know ;-)

IMPORTANT NOTE:
When naming your classified sections, the "short title" will be used to create the database file in which the info 
for the section will be stored.  It is vital that this short name does not include any special characters 
(such as /  -  *  ^  #  <  >  [  ]  {  } or spaces); just use regular characters, underscores, etc.  If you do not do this, 
this Mod will not work correctly! [thanks to David Rolen for this info!]

IMPORTANT NOTE 2:
Netscape 7.0 does not like javascript (at least as we know it).  So most javascript stuff will not work if this browser 
is used.  Maybe it's actually doing something right, and we've just been coding it wrong so IE will understand it. ;-) 

REGARDING CURRENCIES:
Within the admin area, you can set the default currency used in the ads (the script comes with four currencies, the Euro, 
Canadian and American dollars, and Yen).  If you wish to add another currency, use a text editor to open up "currencies.dat", found 
within the admin directory.  Each additional currency should be placed on a new line, in the format "name==symbol", for 
example, "UK==&pound" (without the quotes).  

For more information on currencies, visit http://pacific.commerce.ubc.ca/xr/currency_table.html


INSTRUCTIONS
Following the detailed instructions is a detailed breakdown of all files within this package.

If you are familiar with perl, then follow these simple instructions:

1. modify perl paths in index.cgi, upload.cgi and admin.cgi
2. upload files into your mods directory, based on the subdirectories in the .zip file
3. chmod all .cgi (755), and all .dat (666)
4. chmod these directories to 777: /db, /db/ads, /images/classifieds/ads
5. create a "classifieds" directory within your main WebAPP images directory
6. upload the graphics in the images directory (along with any new images you wish to use) based on the paths in the script
7. add a link to the main classifieds script (index.cgi)

That's it!

The following are detailed instructions for implementing the Classifieds Mod at your site:

########################################
Step 1 - Configuration
########################################

Within the mod package there are a few files which must be modified before it can be used.

PERL PATHS
Modify both index.cgi, upload.cgi and admin.cgi to reflect the path to perl on your server. 
The default path (#!/usr/local/bin/perl -w) may need to be modified to match your site.

CLASS.CFG
This should not have to be modified unless you change a path or wish to adjust settings pertaining to file uploading.

########################################
Step 2 - Create Directories
########################################

Note: if you do not follow the directory structures as outlined in this section, you will have to modify the class.cfg 
file to a greater extent.  Therefore it is recommended that you follow these instructions to the letter.

You must first create a "mods" directory within your site's cgi-bin directory.
If you already have other mods installed, then this first step is not necessary.

The resulting directory chain should look like this:
/cgi-bin/mods

Next, create a subdirectory called "classifieds" within the "mods" directory:
/cgi-bin/mods/classifieds

Now create the following subdirectories within this "classifieds" directory:
/cgi-bin/mods/classifieds/admin
/cgi-bin/mods/classifieds/db
/cgi-bin/mods/classifieds/db/ads
/cgi-bin/mods/classifieds/language

Finally, create the following directories within your main WebAPP images directory:
/images/classifieds
/images/classifieds/ads
/images/classifieds/categories
/images/classifieds/deco
/images/classifieds/smilies
/images/classifieds/ubbc

########################################
Step 3 - Upload Files
########################################

Upload the graphics from the archive (/classifieds/images) in BINARY mode into their corresponding directories:
/images/classifieds
/images/classifieds/ads
/images/classifieds/categories
/images/classifieds/deco
/images/classifieds/smilies
/images/classifieds/ubbc

If you wish to use your own graphics for the categories, simply add them to the /categories directory. 

Next, upload the remaining files in ASCII mode, into the following directories:
/cgi-bin/mods/classifieds/class.cfg
/cgi-bin/mods/classifieds/classifieds.pl
/cgi-bin/mods/classifieds/config.dat
/cgi-bin/mods/classifieds/index.cgi
/cgi-bin/mods/classifieds/upload.cgi
/cgi-bin/mods/classifieds/admin/admin.cgi
/cgi-bin/mods/classifieds/admin/config.dat
/cgi-bin/mods/classifieds/admin/currencies.dat
/cgi-bin/mods/classifieds/admin/index.html
/cgi-bin/mods/classifieds/db/cats.dat
/cgi-bin/mods/classifieds/db/newads.dat
/cgi-bin/mods/classifieds/language/english.dat


########################################
Step 3 - Chmod Files and Directories
########################################

Change the permissions as follows:

class.cfg					666
classifieds.pl				755
config.dat					666
index.cgi					755
upload.cgi					755
admin.cgi					755
config.dat					666
currencies.dat				666
cats.dat					666
newads.dat					666
english.dat					666

/classifieds/db				777
/classifieds/db/ads			777
/images/classifieds/ads		777

########################################
Step 4 - Accessing the script
########################################

You will need to include a link somewhere within your main site to the classifieds area.  
The link will be: <a href="$pageurl/mods/classifieds/index.cgi">Classified Ads</a>

There is an admin switch for disabling the ability for guests to view the ads.

There are methods in place within the script to prevent guest posting, should a more devious visitor try to manually access 
the posting area.

Note: there is no need to add a link to the admin script.  If you are logged in as admin, a link to this area will appear at the 
bottom of most ad pages.

Make sure you create a category before you allow members to access this mod! :)

Questions or comments may be directed to Brad (middleton@myprivacy.ca).


########################################
Breakdown of files within this package
########################################

/classifieds/class.cfg 					configuration file for this mod
/classifieds/classifieds.pl				some common subroutines
/classifieds/config.dat					configuration file for Floyd's Mod Manager
/classifieds/index.cgi					main script for this mod
/classifieds/history.txt				brief history of this script, changes, etc.
/classifieds/readme.txt					this file
/classifieds/upload.cgi					script for image uploading
/classifieds/admin/admin.cgi			admin script for this mod
/classifieds/admin/config.dat			admin options
/classifieds/admin/currencies.dat		some common currencies and their symbols
/classifieds/admin/index.html			temp page (redirects to admin.cgi)
/classifieds/db/cats.dat				ad categories
/classifieds/db/newads.dat				storage for ads awaiting approval by admin
/classifieds/images/ads					where the uploaded ad images will be stored (if applicable)
/classifieds/images/categories			graphics used for categories
/classifieds/images/deco				a couple of graphics used by the script for decoration, links, etc.
/classifieds/images/smilies				smilie graphics
/classifieds/images/ubbc				ubbc graphics
/classifieds/language/english.dat		english language file for this mod


# end

