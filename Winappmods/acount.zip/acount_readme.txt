Read Me - Acount Plugin

ACount is a simple tool to keep track of your web-app page views.

ACount is part of the ABonus Scripts Collection.

ABonus Scripts are an ongoing collection of short scripts that are too small to deserve their own directories.  Hopefully new ABonus Scripts will be released regularly to enhance your web-app sites. 

Install Instructions:

1.  Unzip.

2.  Set the perl path in your account.cgi file (should not need changing).

3.  Upload all folders and files appropriately.

4.  Set Permissions
	mods/abonus dir 755 (or 777 depending on your server).
	mods/abonus/data dir 777
	mods/abonus/data/account dir 777
	.log file(s) 777
	.dat file(s) 777
	.cgi file(s) 755
	.htaccess file(s) 644
	
5.  Make sure you add the "add_to_plugins.pl" file to your user-lib plugins.pl file and it might be good to read the instructions in that file too.

6.  Enjoy.

7.  Edit your abonus/data/account.dat file to customize the wording and look.

8.  Write a message on on the appropriate web-app/modapp board stating your thoughts or just letting the author know it worked for you.


God bless,
Weston Lemos
