# If you already have the logvisitors sub in your user-lib/subs.pl file then just add the marked lined inside your existing logvisitors sub.

################# 
sub logvisitors { 
################# 
      open(LOG, "$datadir/log.dat"); 
      lock(LOG); 
      chomp(@entries = <LOG>); 
      unlock(LOG); 
      close(LOG); 

      open(LOG, ">$datadir/log.dat"); 
      lock(LOG); 
      $field = $username; 
      if ($field eq $anonuser) { $field = "$ENV{'REMOTE_ADDR'}"; } 
      print LOG "$field  $date\n"; 
      foreach $curentry (@entries) { 
            ($name, $value) = split(/\  /, $curentry); 
            $date1 = "$value"; 
            $date2 = "$date"; 
            calctime(); 
            if ($name ne $field && $result <= 15 && $result >= 0)  { print LOG "$curentry\n"; }   
      } 
      unlock(LOG); 
      close(LOG); 
      
	#######################################
	############# ACount Plug #############
	######## By Weston May 14, 2003 #######
	#######################################
      require "$scriptdir/mods/abonus/acount.cgi"; 
      countACount();
        #######################################
        ########## End of ACount Plug ######### 
        #######################################
} 

