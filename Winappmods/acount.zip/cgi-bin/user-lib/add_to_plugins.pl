# Add the below sub to your plugins.pl file.
# Replace the names "kancer!" and "weston!" for whom ever you wish to see the plugin.
# To allow all to see the plugin have it say --> if ($username ne "crazyhorse") {

# If you don't have a plugins.pl file in your user-lib folder then COPY the one in your cgi-lib to your user-lib folder first.


#######################################
############# ACount Plug #############
######## By Weston May 14, 2003 #######
#######################################
if ($username eq "admin" || $username eq "kancer!" || $username eq "weston!") {
	boxheader("Site Page Views");
	print qq~<tr><td class="newstextsmall">~;
	require "$scriptdir/mods/abonus/acount.cgi"; 
	displayACount();
	print qq~</td></tr>~;
	boxfooter();
}

